agate_validation_ui <- function() {
  inline_info <- function(text) {
    tags$span(
      class = "validation-inline-info",
      tabindex = "0",
      `data-tooltip` = text,
      `aria-label` = text,
      "i"
    )
  }
  
  label_with_info <- function(label, info_text) {
    tags$span(
      class = "validation-label-with-info",
      span(label),
      inline_info(info_text)
    )
  }
  
  section_title_with_info <- function(title, info_text) {
    div(
      class = "validation-section-head",
      div(class = "validation-section-title", title),
      inline_info(info_text)
    )
  }
  
  tagList(
    tags$head(
      tags$style(HTML("
body.theme-dark div.dt-button-collection,
.theme-dark div.dt-button-collection {
  background: #111827 !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  box-shadow: 0 18px 45px rgba(0, 0, 0, 0.45) !important;
  padding: 6px !important;
}

body.theme-dark div.dt-button-collection button.dt-button,
body.theme-dark div.dt-button-collection a.dt-button,
.theme-dark div.dt-button-collection button.dt-button,
.theme-dark div.dt-button-collection a.dt-button {
  background: transparent !important;
  color: #e5e7eb !important;
  border: 0 !important;
  box-shadow: none !important;
  text-align: left !important;
  padding: 8px 14px !important;
  width: 100% !important;
}

body.theme-dark div.dt-button-collection button.dt-button:hover,
body.theme-dark div.dt-button-collection a.dt-button:hover,
.theme-dark div.dt-button-collection button.dt-button:hover,
.theme-dark div.dt-button-collection a.dt-button:hover {
  background: #1f2937 !important;
  color: #ffffff !important;
}

body.theme-dark div.dt-button-collection button.dt-button.active,
body.theme-dark div.dt-button-collection a.dt-button.active,
.theme-dark div.dt-button-collection button.dt-button.active,
.theme-dark div.dt-button-collection a.dt-button.active {
  background: #172554 !important;
  color: #ffffff !important;
}

body.theme-dark div.dt-button-collection button.dt-button.active:after,
body.theme-dark div.dt-button-collection a.dt-button.active:after,
.theme-dark div.dt-button-collection button.dt-button.active:after,
.theme-dark div.dt-button-collection a.dt-button.active:after {
  color: #93c5fd !important;
}

body.theme-dark div.dt-button-background,
.theme-dark div.dt-button-background {
  background: rgba(2, 6, 23, 0.45) !important;
}
")),
      tags$style(HTML("
/* =========================================================
   AGATE VALIDATION - THEME LIGHT, ALIGNE SUR SUPERVISION
   ========================================================= */

.agate-validation-page {
  min-height: calc(100vh - 48px);
  padding: 18px 18px 28px;
  background:
    radial-gradient(circle at top left, rgba(37, 99, 235, 0.08), transparent 34%),
    linear-gradient(180deg, #f8fbff 0%, #eef4fb 100%);
  color: #0f2438;
}

.agate-validation-page .validation-grid {
  display: grid;
  grid-template-columns: 380px minmax(0, 1fr);
  gap: 18px;
  align-items: start;
}

.agate-validation-page .validation-card {
  background: rgba(255, 255, 255, 0.96);
  border: 1px solid #d3deec;
  border-radius: 20px;
  padding: 18px;
  box-shadow:
    0 18px 42px rgba(15, 35, 65, 0.10),
    0 1px 0 rgba(255, 255, 255, 0.9) inset;
  margin-bottom: 18px;
  overflow: visible;
}

.agate-validation-page .validation-card:hover {
  border-color: #bfd0e6;
}

.agate-validation-page .validation-kpis {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
  gap: 12px;
  margin-bottom: 18px;
}

.agate-validation-page .validation-kpi {
  position: relative;
  overflow: hidden;
  background:
    linear-gradient(145deg, #ffffff 0%, #f4f8ff 72%, #eef5ff 100%);
  border: 1px solid #d3deec;
  border-radius: 18px;
  padding: 16px 16px 15px;
  box-shadow:
    0 12px 26px rgba(15, 35, 65, 0.08),
    0 1px 0 rgba(255, 255, 255, 0.9) inset;
}

.agate-validation-page .validation-kpi::before {
  content: '';
  position: absolute;
  inset: 0 auto 0 0;
  width: 5px;
  background: linear-gradient(180deg, #2563eb, #22c55e);
  opacity: 0.95;
}

.agate-validation-page .validation-kpi::after {
  content: '';
  position: absolute;
  width: 120px;
  height: 120px;
  right: -48px;
  top: -48px;
  border-radius: 999px;
  background: rgba(37, 99, 235, 0.08);
}

.agate-validation-page .validation-kpi-label {
  position: relative;
  z-index: 1;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.095em;
  color: #486581;
  font-weight: 800;
  margin-bottom: 8px;
}

.agate-validation-page .validation-kpi-value {
  position: relative;
  z-index: 1;
  font-size: 31px;
  font-weight: 850;
  color: #0b2f5b;
  line-height: 1;
  margin-bottom: 8px;
}

.agate-validation-page .validation-kpi-help {
  position: relative;
  z-index: 1;
  font-size: 12px;
  color: #506783;
  line-height: 1.35;
}

.agate-validation-page .validation-section-head {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.agate-validation-page .validation-section-title {
  font-size: 17px;
  font-weight: 850;
  color: #0b2f5b;
  margin-bottom: 10px;
  letter-spacing: -0.01em;
}

.agate-validation-page .validation-section-head .validation-section-title {
  margin-bottom: 0;
}

.agate-validation-page .validation-note,
.agate-validation-page .validation-tab-intro,
.agate-validation-page .validation-impact,
.agate-validation-page .validation-edit-help {
  font-size: 12.5px;
  color: #5c728d;
  line-height: 1.55;
}

.agate-validation-page .validation-label-with-info {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.agate-validation-page .validation-inline-info {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  border-radius: 999px;
  background: linear-gradient(145deg, #0b2f5b, #174f8f);
  color: #ffffff;
  font-size: 11px;
  font-weight: 800;
  line-height: 1;
  cursor: help;
  flex: 0 0 auto;
  box-shadow: 0 4px 10px rgba(11, 47, 91, 0.22);
}

.agate-validation-page .validation-inline-info::after {
  content: attr(data-tooltip);
  position: absolute;
  left: 50%;
  top: calc(100% + 10px);
  transform: translateX(-50%) translateY(-2px);
  min-width: 230px;
  max-width: 300px;
  padding: 10px 12px;
  border-radius: 13px;
  background: #0b2f5b;
  color: #ffffff;
  font-size: 12px;
  font-weight: 500;
  line-height: 1.45;
  white-space: normal;
  box-shadow: 0 18px 34px rgba(11, 47, 91, 0.28);
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  transition: opacity 0.14s ease, transform 0.14s ease;
  z-index: 2000;
}

.agate-validation-page .validation-inline-info::before {
  content: '';
  position: absolute;
  left: 50%;
  top: calc(100% + 4px);
  transform: translateX(-50%);
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  border-bottom: 6px solid #0b2f5b;
  opacity: 0;
  visibility: hidden;
  transition: opacity 0.14s ease;
  z-index: 2001;
}

.agate-validation-page .validation-inline-info:hover::after,
.agate-validation-page .validation-inline-info:hover::before,
.agate-validation-page .validation-inline-info:focus::after,
.agate-validation-page .validation-inline-info:focus::before {
  opacity: 1;
  visibility: visible;
  transform: translateX(-50%) translateY(0);
}

.agate-validation-page .validation-inline-info:focus {
  outline: 2px solid #93c5fd;
  outline-offset: 2px;
}

.agate-validation-page .validation-status-banner {
  position: relative;
  overflow: hidden;
  border-radius: 18px;
  padding: 16px;
  margin-bottom: 16px;
  border: 1px solid #d3deec;
  background: linear-gradient(145deg, #ffffff 0%, #f4f8ff 100%);
}

.agate-validation-page .validation-status-banner::before {
  content: '';
  position: absolute;
  inset: 0 auto 0 0;
  width: 5px;
  background: #2563eb;
}

.agate-validation-page .validation-status-banner.is-progress::before { background: #22c55e; }
.agate-validation-page .validation-status-banner.is-waiting::before { background: #f59e0b; }
.agate-validation-page .validation-status-banner.is-rejected::before { background: #ef4444; }
.agate-validation-page .validation-status-banner.is-published::before { background: #8b5cf6; }

.agate-validation-page .validation-status-kicker {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.095em;
  color: #486581;
  font-weight: 800;
  margin-bottom: 8px;
}

.agate-validation-page .validation-status-title {
  font-size: 18px;
  font-weight: 850;
  color: #0b2f5b;
  margin-bottom: 8px;
}

.agate-validation-page .validation-status-copy {
  font-size: 12.5px;
  color: #526a86;
  line-height: 1.55;
}

.agate-validation-page .validation-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 14px;
}

.agate-validation-page .validation-detail-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.agate-validation-page .validation-detail-box {
  position: relative;
  overflow: hidden;
  background: linear-gradient(145deg, #ffffff 0%, #f6f9fe 100%);
  border: 1px solid #d3deec;
  border-radius: 16px;
  padding: 13px;
}

.agate-validation-page .validation-detail-box.is-current {
  background: linear-gradient(145deg, rgba(22, 163, 74, 0.08), rgba(255,255,255,0.96));
  border-color: #22c55e;
}

.agate-validation-page .validation-detail-box.is-warning {
  background: linear-gradient(145deg, rgba(245, 158, 11, 0.12), rgba(255,255,255,0.96));
  border-color: #f59e0b;
}

.agate-validation-page .validation-detail-label {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.095em;
  color: #486581;
  font-weight: 800;
  margin-bottom: 7px;
}

.agate-validation-page .validation-detail-value {
  font-size: 14px;
  color: #0f2438;
  line-height: 1.45;
  word-break: break-word;
}

.agate-validation-page .validation-subpanel-tabs > .nav,
.agate-validation-page .validation-modification-tabs > .nav {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  border-bottom: 1px solid #d3deec;
  margin: 4px 0 14px;
  padding-bottom: 8px;
}

.agate-validation-page .validation-subpanel-tabs > .nav > li,
.agate-validation-page .validation-modification-tabs > .nav > li {
  float: none;
  margin: 0;
}

.agate-validation-page .validation-subpanel-tabs > .nav > li > a,
.agate-validation-page .validation-modification-tabs > .nav > li > a {
  border: 1px solid #d3deec;
  border-radius: 999px;
  background: #f7faff;
  color: #25476a;
  font-size: 12px;
  font-weight: 800;
  padding: 8px 14px;
}

.agate-validation-page .validation-subpanel-tabs > .nav > li.active > a,
.agate-validation-page .validation-subpanel-tabs > .nav > li.active > a:hover,
.agate-validation-page .validation-subpanel-tabs > .nav > li.active > a:focus,
.agate-validation-page .validation-modification-tabs > .nav > li.active > a,
.agate-validation-page .validation-modification-tabs > .nav > li.active > a:hover,
.agate-validation-page .validation-modification-tabs > .nav > li.active > a:focus {
  background: linear-gradient(140deg, #2563eb 0%, #1d4ed8 100%);
  border-color: #2563eb;
  color: #ffffff;
}

.agate-validation-page .validation-dt .dt-buttons { margin-bottom: 10px; }
.agate-validation-page .validation-dt .dt-button {
  border: 1px solid #d3deec !important;
  border-radius: 999px !important;
  background: #f7faff !important;
  color: #25476a !important;
  font-size: 12px !important;
  font-weight: 800 !important;
  padding: 7px 12px !important;
}

.agate-validation-page .validation-modification-card {
  border-color: #7aa7ff;
  background:
    radial-gradient(circle at top left, rgba(37, 99, 235, 0.10), transparent 34%),
    rgba(255, 255, 255, 0.96);
}

.agate-validation-page .validation-modification-warning {
  border-left: 4px solid #2563eb;
  background: rgba(37, 99, 235, 0.08);
  color: #234469;
  border-radius: 14px;
  padding: 12px 14px;
  margin-bottom: 14px;
  font-size: 13px;
  line-height: 1.45;
}

.agate-validation-page .validation-modification-layout {
  display: grid;
  grid-template-columns: minmax(360px, 0.42fr) minmax(0, 0.58fr);
  gap: 16px;
  align-items: start;
}

.agate-validation-page .validation-modification-side,
.agate-validation-page .validation-modification-reference {
  background: rgba(255, 255, 255, 0.86);
  border: 1px solid #d3deec;
  border-radius: 18px;
  padding: 14px;
}

.agate-validation-page .validation-mode-help {
  border-radius: 14px;
  padding: 11px 13px;
  margin-bottom: 12px;
  font-size: 13px;
  line-height: 1.45;
}

.agate-validation-page .validation-mode-help.is-quick {
  background: #ecfdf5;
  border: 1px solid #bbf7d0;
  color: #166534;
}

.agate-validation-page .validation-mode-help.is-complete {
  background: #fff7ed;
  border: 1px solid #fed7aa;
  color: #9a3412;
}

.agate-validation-page .validation-current-parent {
  background: #ecfdf5;
  border: 1px solid #bbf7d0;
  color: #14532d;
  border-radius: 14px;
  padding: 11px 13px;
  margin-bottom: 12px;
}

.agate-validation-page .validation-current-parent.is-empty {
  background: #fff7ed;
  border-color: #fed7aa;
  color: #9a3412;
}

.agate-validation-page .validation-reference-actions,
.agate-validation-page .validation-modification-actions {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  margin: 12px 0;
}

.agate-validation-page .validation-modification-submit {
  margin-top: 16px;
  padding-top: 14px;
  border-top: 1px solid #d3deec;
}

.agate-validation-page .validation-edit-preview {
  margin-top: 12px;
  border: 1px dashed #9bb6d4;
  background: #f8fbff;
  border-radius: 14px;
  padding: 12px;
}

.agate-validation-page .validation-edit-preview-row {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  font-size: 13px;
  padding: 5px 0;
}

.agate-validation-page .table-striped > tbody > tr:nth-of-type(odd) {
  background-color: rgba(37, 99, 235, 0.04);
}

@media (max-width: 1240px) {
  .agate-validation-page .validation-grid,
  .agate-validation-page .validation-modification-layout {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 760px) {
  .agate-validation-page .validation-kpis,
  .agate-validation-page .validation-detail-grid {
    grid-template-columns: 1fr;
  }
}

/* =========================================================
   THEME DARK
   ========================================================= */

body.theme-dark .agate-validation-page {
  background:
    radial-gradient(circle at top left, rgba(37, 99, 235, 0.12), transparent 34%),
    linear-gradient(180deg, #111827 0%, #0b1220 100%);
  color: #e5e7eb;
}

body.theme-dark .agate-validation-page .validation-card,
body.theme-dark .agate-validation-page .validation-kpi,
body.theme-dark .agate-validation-page .validation-detail-box,
body.theme-dark .agate-validation-page .validation-status-banner,
body.theme-dark .agate-validation-page .validation-modification-side,
body.theme-dark .agate-validation-page .validation-modification-reference,
body.theme-dark .agate-validation-page .validation-edit-preview {
  background: rgba(17, 24, 39, 0.88);
  border-color: #334155;
  color: #e5e7eb;
  box-shadow: 0 18px 42px rgba(0, 0, 0, 0.28);
}

body.theme-dark .agate-validation-page .validation-kpi::after {
  background: rgba(37, 99, 235, 0.12);
}

body.theme-dark .agate-validation-page .validation-section-title,
body.theme-dark .agate-validation-page .validation-kpi-value,
body.theme-dark .agate-validation-page .validation-status-title,
body.theme-dark .agate-validation-page .validation-detail-value {
  color: #f8fafc;
}

body.theme-dark .agate-validation-page .validation-note,
body.theme-dark .agate-validation-page .validation-tab-intro,
body.theme-dark .agate-validation-page .validation-impact,
body.theme-dark .agate-validation-page .validation-edit-help,
body.theme-dark .agate-validation-page .validation-kpi-help,
body.theme-dark .agate-validation-page .validation-kpi-label,
body.theme-dark .agate-validation-page .validation-status-kicker,
body.theme-dark .agate-validation-page .validation-status-copy,
body.theme-dark .agate-validation-page .validation-detail-label {
  color: #cbd5e1;
}

body.theme-dark .agate-validation-page .validation-subpanel-tabs > .nav,
body.theme-dark .agate-validation-page .validation-modification-tabs > .nav,
body.theme-dark .agate-validation-page .validation-modification-submit {
  border-color: #334155;
}

body.theme-dark .agate-validation-page .validation-subpanel-tabs > .nav > li > a,
body.theme-dark .agate-validation-page .validation-modification-tabs > .nav > li > a {
  background: #111827;
  border-color: #334155;
  color: #e5e7eb;
}

body.theme-dark .agate-validation-page .validation-modification-warning {
  background: rgba(37, 99, 235, 0.14);
  color: #dbeafe;
  border-left-color: #60a5fa;
}

body.theme-dark .agate-validation-page .validation-current-parent {
  background: rgba(34, 197, 94, 0.12);
  border-color: #22c55e;
  color: #dcfce7;
}

body.theme-dark .agate-validation-page .validation-current-parent.is-empty,
body.theme-dark .agate-validation-page .validation-mode-help.is-complete {
  background: rgba(245, 158, 11, 0.12);
  border-color: #f59e0b;
  color: #fde68a;
}

body.theme-dark .agate-validation-page .validation-mode-help.is-quick {
  background: rgba(34, 197, 94, 0.12);
  border-color: #22c55e;
  color: #dcfce7;
}

body.theme-dark .agate-validation-page .form-control,
body.theme-dark .agate-validation-page .selectize-input,
body.theme-dark .agate-validation-page .selectize-dropdown,
body.theme-dark .agate-validation-page .selectize-dropdown-content {
  background: #0b1220 !important;
  color: #e5e7eb !important;
  border-color: #334155 !important;
}

body.theme-dark .agate-validation-page table.dataTable tbody tr,
body.theme-dark .agate-validation-page table.dataTable thead th,
body.theme-dark .agate-validation-page table.dataTable tbody td {
  background: #0b1220 !important;
  color: #e5e7eb !important;
  border-color: #334155 !important;
}

body.theme-dark .agate-validation-page .table,
body.theme-dark .agate-validation-page .table-striped,
body.theme-dark .agate-validation-page .table-bordered {
  background: #0b1220 !important;
  color: #e5e7eb !important;
  border-color: #334155 !important;
}

body.theme-dark .agate-validation-page .table > thead > tr > th,
body.theme-dark .agate-validation-page .table > tbody > tr > td,
body.theme-dark .agate-validation-page .table-striped > tbody > tr:nth-of-type(odd),
body.theme-dark .agate-validation-page .table-striped > tbody > tr:nth-of-type(even) {
  background: #0b1220 !important;
  color: #e5e7eb !important;
  border-color: #334155 !important;
}
      "))
    ),
    div(
      class = "agate-validation-page",
      div(
        class = "validation-card",
        div(class = "validation-section-title", "Validation AGATE — l'essentiel"),
        p(
          class = "validation-note",
          "Pour traiter un dossier, utilisez les trois premiers onglets : À valider, En cours et En attente. Les onglets marqués Consultation servent uniquement à relire le stock et l'historique."
        ),
        tags$details(
          class = "validation-advanced-details",
          tags$summary("Voir les indicateurs de pilotage"),
          uiOutput("agate_validation_kpi_panel")
        )
      ),
      div(
        class = "validation-grid",
        div(
          class = "validation-card",
          section_title_with_info("Décision MOA", "Cette zone gère la prise en charge, la mise en attente, la publication en l'état ou le rejet."),
          uiOutput("agate_validation_action_context"),
          textInput(
            "agate_validation_agent",
            label_with_info("IDEP validation", "Cet identifiant trace le valideur MOA qui prend la décision sur le dossier."),
            value = if (exists("user_idep", inherits = TRUE) && nzchar(user_idep)) user_idep else ""
          ),
          textAreaInput(
            "agate_validation_comment",
            label_with_info("Commentaire validation", "Utile pour expliquer une mise en attente, un rejet, une publication ou un arbitrage avant publication."),
            rows = 4,
            placeholder = "Motiver la mise en attente, le rejet, la publication ou l'arbitrage."
          ),
          textInput(
            "agate_validation_reprise_idep_agent",
            label_with_info("IDEP reprise édition", "Utilise cet identifiant quand la MOA recrée une reprise d'édition à partir d'un rejet."),
            value = if (exists("user_idep", inherits = TRUE) && nzchar(user_idep)) user_idep else ""
          ),
          div(class = "validation-note", "La publication en l'état et le rejet restent dans ce panneau. Si la proposition doit être ajustée avant publication, utilise le bloc Modification de publication affiché sous le détail du dossier."),
          uiOutput("agate_validation_action_panel")
        ),
        div(
          div(
            class = "validation-card",
            tabsetPanel(
              id = "agate_validation_status_tab",
              type = "tabs",
              tabPanel(
                title = "1. À valider",
                value = "A valider",
                div(
                  class = "validation-tab-intro",
                  span("Propositions transmises par la supervision, en attente de prise en charge MOA."),
                  inline_info("Prendre en charge le dossier le bascule dans En cours, où la décision et l'éventuelle modification de publication sont possibles.")
                ),
                div(class = "validation-dt", DTOutput("agate_table_validation_queue"))
              ),
              tabPanel(
                title = "2. En cours",
                value = "En cours",
                div(
                  class = "validation-tab-intro",
                  span("Dossiers ouverts côté MOA. Le détail apparaît sous le tableau, puis le bloc Modification de publication si besoin."),
                  inline_info("La MOA peut publier en l'état depuis le panneau de gauche, ou préparer une version modifiée dans le bloc inférieur.")
                ),
                div(class = "validation-dt", DTOutput("agate_table_validation_in_progress"))
              ),
              tabPanel(
                title = "3. En attente",
                value = "En attente",
                div(
                  class = "validation-tab-intro",
                  span("Dossiers temporisés par la MOA."),
                  inline_info("Reprendre le dossier le replace en instruction active.")
                ),
                div(class = "validation-dt", DTOutput("agate_table_validation_waiting"))
              ),
              tabPanel(
                title = "Rejetés",
                value = "Rejetes",
                div(
                  class = "validation-tab-intro",
                  span("Rejets MOA disponibles pour audit ou création d'une reprise d'édition."),
                  inline_info("Une reprise recrée un dossier côté supervision à partir du rejet.")
                ),
                div(class = "validation-dt", DTOutput("agate_table_validation_rejected"))
              ),
              tabPanel(
                title = "Consultation · Validées",
                value = "Validees",
                div(
                  class = "validation-tab-intro",
                  span("Propositions déjà publiées."),
                  inline_info("Cette file permet de relire les décisions finales.")
                ),
                div(class = "validation-dt", DTOutput("agate_table_validation_validated"))
              ),
              tabPanel(
                title = "Consultation · Stock",
                value = "Stock familles",
                div(
                  class = "validation-tab-intro",
                  span("Stock des familles déjà publiées."),
                  inline_info("Vue consultative du stock final alimenté par la MOA.")
                ),
                div(class = "validation-dt", DTOutput("agate_table_validation_stock"))
              ),
              tabPanel(
                title = "Consultation · Référentiel",
                value = "Référentiel EDEP",
                div(
                  class = "validation-tab-intro",
                  span("Référentiel aval publié par la MOA."),
                  inline_info("Cette table montre les codes et rôles EDEP après publication.")
                ),
                div(class = "validation-dt", DTOutput("agate_table_validation_edep"))
              ),
              tabPanel(
                title = "Consultation · Liens",
                value = "Liens EDEP",
                div(
                  class = "validation-tab-intro",
                  span("Liens parent -> enfant publiés."),
                  inline_info("Cette vue complète le référentiel EDEP avec le détail des liens.")
                ),
                div(class = "validation-dt", DTOutput("agate_table_validation_edep_links"))
              )
            )
          ),
          div(
            class = "validation-card",
            section_title_with_info("Détail validation", "Ce bloc résume le dossier, la version courante transmise à la MOA et le contenu publiable."),
            uiOutput("agate_validation_detail")
          ),
          uiOutput("agate_validation_modification_workspace"),
          uiOutput("agate_validation_publish_workspace")
        )
      )
    )
  )
}
