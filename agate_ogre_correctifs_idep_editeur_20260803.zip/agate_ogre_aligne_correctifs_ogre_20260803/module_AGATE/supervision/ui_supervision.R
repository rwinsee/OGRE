agate_supervision_ui <- function() {
  inline_info <- function(text) {
    tags$span(
      class = "supervision-inline-info",
      tabindex = "0",
      `data-tooltip` = text,
      `aria-label` = text,
      "i"
    )
  }
  
  label_with_info <- function(label, info_text) {
    tags$span(
      class = "supervision-label-with-info",
      span(label),
      inline_info(info_text)
    )
  }
  
  section_title_with_info <- function(title, info_text) {
    div(
      class = "supervision-section-head",
      div(class = "supervision-section-title", title),
      inline_info(info_text)
    )
  }
  
  tagList(
    tags$head(
      tags$style(HTML("
body.theme-dark div.dt-button-collection,
.theme-dark div.dt-button-collection {
  background: #111827 !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  box-shadow: 0 18px 45px rgba(0, 0, 0, 0.45) !important;
  padding: 6px !important;
}

body.theme-dark div.dt-button-collection button.dt-button,
body.theme-dark div.dt-button-collection a.dt-button,
.theme-dark div.dt-button-collection button.dt-button,
.theme-dark div.dt-button-collection a.dt-button {
  background: transparent !important;
  color: #e5e7eb !important;
  border: 0 !important;
  box-shadow: none !important;
  text-align: left !important;
  padding: 8px 14px !important;
  width: 100% !important;
}

body.theme-dark div.dt-button-collection button.dt-button:hover,
body.theme-dark div.dt-button-collection a.dt-button:hover,
.theme-dark div.dt-button-collection button.dt-button:hover,
.theme-dark div.dt-button-collection a.dt-button:hover {
  background: #1f2937 !important;
  color: #ffffff !important;
}

body.theme-dark div.dt-button-collection button.dt-button.active,
body.theme-dark div.dt-button-collection a.dt-button.active,
.theme-dark div.dt-button-collection button.dt-button.active,
.theme-dark div.dt-button-collection a.dt-button.active {
  background: #172554 !important;
  color: #ffffff !important;
}

body.theme-dark div.dt-button-collection button.dt-button.active:after,
body.theme-dark div.dt-button-collection a.dt-button.active:after,
.theme-dark div.dt-button-collection button.dt-button.active:after,
.theme-dark div.dt-button-collection a.dt-button.active:after {
  color: #93c5fd !important;
}

body.theme-dark div.dt-button-background,
.theme-dark div.dt-button-background {
  background: rgba(2, 6, 23, 0.45) !important;
}
")),
      tags$style(HTML("
       /* =========================================================
   AGATE SUPERVISION - THEME LIGHT
   ========================================================= */

.agate-supervision-page {
  min-height: calc(100vh - 48px);
  padding: 18px 18px 28px;
  background:
    radial-gradient(circle at top left, rgba(37, 99, 235, 0.08), transparent 34%),
    linear-gradient(180deg, #f8fbff 0%, #eef4fb 100%);
  color: #0f2438;
}

/* =========================================================
   LAYOUT
   ========================================================= */

.agate-supervision-page .supervision-grid {
  display: grid;
  grid-template-columns: 380px minmax(0, 1fr);
  gap: 18px;
  align-items: start;
}

.agate-supervision-page .supervision-card {
  background: rgba(255, 255, 255, 0.96);
  border: 1px solid #d3deec;
  border-radius: 20px;
  padding: 18px;
  box-shadow:
    0 18px 42px rgba(15, 35, 65, 0.10),
    0 1px 0 rgba(255, 255, 255, 0.9) inset;
  margin-bottom: 18px;
  overflow: visible;
}

.agate-supervision-page .supervision-card:hover {
  border-color: #bfd0e6;
}

/* =========================================================
   KPI
   ========================================================= */

.agate-supervision-page .supervision-kpis {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
  gap: 12px;
  margin-bottom: 18px;
}

.agate-supervision-page .supervision-kpi {
  position: relative;
  overflow: hidden;
  background:
    linear-gradient(145deg, #ffffff 0%, #f4f8ff 72%, #eef5ff 100%);
  border: 1px solid #d3deec;
  border-radius: 18px;
  padding: 16px 16px 15px;
  box-shadow:
    0 12px 26px rgba(15, 35, 65, 0.08),
    0 1px 0 rgba(255, 255, 255, 0.9) inset;
}

.agate-supervision-page .supervision-kpi::before {
  content: '';
  position: absolute;
  inset: 0 auto 0 0;
  width: 5px;
  background: linear-gradient(180deg, #2563eb, #22c55e);
  opacity: 0.95;
}

.agate-supervision-page .supervision-kpi::after {
  content: '';
  position: absolute;
  width: 120px;
  height: 120px;
  right: -48px;
  top: -48px;
  border-radius: 999px;
  background: rgba(37, 99, 235, 0.08);
}

.agate-supervision-page .supervision-kpi-label {
  position: relative;
  z-index: 1;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.095em;
  color: #486581;
  font-weight: 800;
  margin-bottom: 8px;
}

.agate-supervision-page .supervision-kpi-value {
  position: relative;
  z-index: 1;
  font-size: 31px;
  font-weight: 850;
  color: #0b2f5b;
  line-height: 1;
  margin-bottom: 8px;
}

.agate-supervision-page .supervision-kpi-help {
  position: relative;
  z-index: 1;
  font-size: 12px;
  color: #506783;
  line-height: 1.35;
}

/* =========================================================
   TITRES / INFOS / NOTES
   ========================================================= */

.agate-supervision-page .supervision-section-head {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.agate-supervision-page .supervision-section-title {
  font-size: 17px;
  font-weight: 850;
  color: #0b2f5b;
  margin-bottom: 10px;
  letter-spacing: -0.01em;
}

.agate-supervision-page .supervision-section-head .supervision-section-title {
  margin-bottom: 0;
}

.agate-supervision-page .supervision-note {
  font-size: 12.5px;
  color: #5c728d;
  line-height: 1.55;
}

.agate-supervision-page .supervision-edit-help {
  font-size: 13px;
  color: #526a86;
  line-height: 1.55;
  margin-bottom: 12px;
}

/* =========================================================
   TOOLTIPS INFO
   ========================================================= */

.agate-supervision-page .supervision-label-with-info {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.agate-supervision-page .supervision-inline-info {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  border-radius: 999px;
  background: linear-gradient(145deg, #0b2f5b, #174f8f);
  color: #ffffff;
  font-size: 11px;
  font-weight: 800;
  line-height: 1;
  cursor: help;
  flex: 0 0 auto;
  box-shadow: 0 4px 10px rgba(11, 47, 91, 0.22);
}

.agate-supervision-page .supervision-inline-info::after {
  content: attr(data-tooltip);
  position: absolute;
  left: 50%;
  top: calc(100% + 10px);
  transform: translateX(-50%) translateY(-2px);
  min-width: 230px;
  max-width: 300px;
  padding: 10px 12px;
  border-radius: 13px;
  background: #0b2f5b;
  color: #ffffff;
  font-size: 12px;
  font-weight: 500;
  line-height: 1.45;
  white-space: normal;
  box-shadow: 0 18px 34px rgba(11, 47, 91, 0.28);
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  transition: opacity 0.14s ease, transform 0.14s ease;
  z-index: 2000;
}

.agate-supervision-page .supervision-inline-info::before {
  content: '';
  position: absolute;
  left: 50%;
  top: calc(100% + 4px);
  transform: translateX(-50%);
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  border-bottom: 6px solid #0b2f5b;
  opacity: 0;
  visibility: hidden;
  transition: opacity 0.14s ease;
  z-index: 2001;
}

.agate-supervision-page .supervision-inline-info:hover::after,
.agate-supervision-page .supervision-inline-info:hover::before,
.agate-supervision-page .supervision-inline-info:focus::after,
.agate-supervision-page .supervision-inline-info:focus::before {
  opacity: 1;
  visibility: visible;
  transform: translateX(-50%) translateY(0);
}

.agate-supervision-page .supervision-inline-info:focus {
  outline: 2px solid #93c5fd;
  outline-offset: 2px;
}

/* =========================================================
   BANNIERES DE CONTEXTE
   ========================================================= */

.agate-supervision-page .supervision-status-banner {
  position: relative;
  overflow: hidden;
  border-radius: 18px;
  padding: 16px;
  margin-bottom: 14px;
  border: 1px solid #d3deec;
  background: linear-gradient(145deg, #f8fbff 0%, #edf4fc 100%);
}

.agate-supervision-page .supervision-status-banner::before {
  content: '';
  position: absolute;
  inset: 0 auto 0 0;
  width: 5px;
  background: #2563eb;
}

.agate-supervision-page .supervision-status-banner.is-queue {
  background: linear-gradient(145deg, #fff5f8 0%, #ffe9f0 100%);
  border-color: #f5bfd0;
}

.agate-supervision-page .supervision-status-banner.is-queue::before {
  background: #db2777;
}

.agate-supervision-page .supervision-status-banner.is-progress {
  background: linear-gradient(145deg, #eff8ff 0%, #dfeeff 100%);
  border-color: #bcd8f7;
}

.agate-supervision-page .supervision-status-banner.is-progress::before {
  background: #2563eb;
}

.agate-supervision-page .supervision-status-banner.is-rejected {
  background: linear-gradient(145deg, #fff8eb 0%, #ffefd4 100%);
  border-color: #f1d29b;
}

.agate-supervision-page .supervision-status-banner.is-rejected::before {
  background: #d97706;
}

.agate-supervision-page .supervision-status-kicker {
  position: relative;
  z-index: 1;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.09em;
  color: #62748c;
  font-weight: 800;
  margin-bottom: 6px;
}

.agate-supervision-page .supervision-status-title {
  position: relative;
  z-index: 1;
  font-size: 19px;
  font-weight: 850;
  color: #0b2f5b;
  margin-bottom: 7px;
  letter-spacing: -0.015em;
}

.agate-supervision-page .supervision-status-copy {
  position: relative;
  z-index: 1;
  font-size: 13px;
  color: #506783;
  line-height: 1.6;
}

/* =========================================================
   INPUTS
   ========================================================= */

.agate-supervision-page label,
.agate-supervision-page .control-label {
  color: #102a43;
  font-weight: 800;
  font-size: 13px;
}

.agate-supervision-page .form-control {
  border-radius: 9px;
  border: 1px solid #c8d5e6;
  background: #ffffff;
  color: #102a43;
  box-shadow: none;
}

.agate-supervision-page .form-control:focus {
  border-color: #3b82f6;
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.16);
}

.agate-supervision-page textarea.form-control {
  resize: vertical;
  min-height: 96px;
}

.agate-supervision-page .selectize-input,
.agate-supervision-page .selectize-dropdown {
  border-radius: 10px !important;
  border-color: #c8d5e6 !important;
  box-shadow: none !important;
}

.agate-supervision-page .selectize-input.focus {
  border-color: #3b82f6 !important;
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.16) !important;
}

/* =========================================================
   ONGLET GAUCHE + ONGLET STATUT
   ========================================================= */

.agate-supervision-page .supervision-subpanel-tabs > .nav,
.agate-supervision-page .nav-tabs {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  border-bottom: 1px solid #d8e2f0;
  margin: 0 0 14px;
}

.agate-supervision-page .supervision-subpanel-tabs > .nav > li,
.agate-supervision-page .nav-tabs > li {
  float: none;
  margin: 0;
}

.agate-supervision-page .supervision-subpanel-tabs > .nav > li > a,
.agate-supervision-page .nav-tabs > li > a {
  border: 1px solid transparent;
  border-radius: 12px 12px 0 0;
  background: transparent;
  color: #244766;
  font-size: 13px;
  font-weight: 750;
  padding: 11px 16px;
  margin: 0;
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}

.agate-supervision-page .supervision-subpanel-tabs > .nav > li > a:hover,
.agate-supervision-page .nav-tabs > li > a:hover {
  background: #eef5ff;
  border-color: #d3e3f8;
  color: #0b2f5b;
}

.agate-supervision-page .supervision-subpanel-tabs > .nav > li.active > a,
.agate-supervision-page .supervision-subpanel-tabs > .nav > li.active > a:hover,
.agate-supervision-page .supervision-subpanel-tabs > .nav > li.active > a:focus,
.agate-supervision-page .nav-tabs > li.active > a,
.agate-supervision-page .nav-tabs > li.active > a:hover,
.agate-supervision-page .nav-tabs > li.active > a:focus {
  background: linear-gradient(145deg, #2563eb 0%, #174f8f 100%);
  border-color: #2563eb;
  color: #ffffff;
  box-shadow: 0 10px 22px rgba(37, 99, 235, 0.20);
}

.agate-supervision-page .supervision-subpanel-content {
  min-height: 220px;
}

.agate-supervision-page .supervision-tab-intro {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: 8px;
  flex-wrap: wrap;
  margin: 12px 0 14px;
  color: #536b86;
  font-size: 12.5px;
  line-height: 1.5;
}
/* =========================================================
   BLOC ACTION CONTEXTUEL
   ========================================================= */

.agate-supervision-page .supervision-action-block {
  margin-top: 12px;
  padding: 14px;
  border-radius: 16px;
  border: 1px solid #d3deec;
  background: linear-gradient(145deg, #ffffff 0%, #f5f9ff 100%);
}

.agate-supervision-page .supervision-action-block.is-primary-step {
  border-color: #bbf7d0;
  background: linear-gradient(145deg, #f0fdf4 0%, #dcfce7 100%);
}

.agate-supervision-page .supervision-action-block.is-decision-step {
  border-color: #bfdbfe;
  background: linear-gradient(145deg, #eff6ff 0%, #dbeafe 100%);
}

.agate-supervision-page .supervision-action-block.is-reprise-step {
  border-color: #fed7aa;
  background: linear-gradient(145deg, #fff7ed 0%, #ffedd5 100%);
}

.agate-supervision-page .supervision-action-title {
  font-size: 13px;
  font-weight: 850;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: #0b2f5b;
  margin-bottom: 8px;
}

body.theme-dark .agate-supervision-page .supervision-action-block {
  background: linear-gradient(145deg, #111827 0%, #020617 100%);
  border-color: #334155;
}

body.theme-dark .agate-supervision-page .supervision-action-block.is-primary-step {
  border-color: #22c55e;
  background: linear-gradient(145deg, #052e16 0%, #022c22 100%);
}

body.theme-dark .agate-supervision-page .supervision-action-block.is-decision-step {
  border-color: #3b82f6;
  background: linear-gradient(145deg, #172554 0%, #020617 100%);
}

body.theme-dark .agate-supervision-page .supervision-action-block.is-reprise-step {
  border-color: #f59e0b;
  background: linear-gradient(145deg, #3b2f13 0%, #020617 100%);
}

body.theme-dark .agate-supervision-page .supervision-action-title {
  color: #ffffff;
}
/* =========================================================
   BOUTONS
   ========================================================= */

.agate-supervision-page .supervision-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 12px;
}

.agate-supervision-page .btn {
  border-radius: 999px;
  font-weight: 800;
  font-size: 13px;
  padding: 8px 15px;
  border-width: 1px;
  box-shadow: 0 8px 18px rgba(15, 35, 65, 0.08);
  transition: transform 0.10s ease, box-shadow 0.10s ease, background 0.10s ease;
}

.agate-supervision-page .btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 12px 24px rgba(15, 35, 65, 0.13);
}

.agate-supervision-page .btn-default {
  background: #ffffff;
  border-color: #c8d5e6;
  color: #174f8f;
}

.agate-supervision-page .btn-primary {
  background: linear-gradient(145deg, #2563eb 0%, #1d4ed8 100%);
  border-color: #1d4ed8;
  color: #ffffff;
}

.agate-supervision-page .btn-success {
  background: linear-gradient(145deg, #22c55e 0%, #15803d 100%);
  border-color: #15803d;
  color: #ffffff;
}

.agate-supervision-page .btn-warning {
  background: linear-gradient(145deg, #f59e0b 0%, #d97706 100%);
  border-color: #d97706;
  color: #ffffff;
}

.agate-supervision-page .btn-info {
  background: linear-gradient(145deg, #06b6d4 0%, #0284c7 100%);
  border-color: #0284c7;
  color: #ffffff;
}

/* =========================================================
   DATATABLES
   ========================================================= */

.agate-supervision-page .supervision-dt {
  width: 100%;
}

.agate-supervision-page .supervision-dt .dt-buttons {
  margin-bottom: 10px;
}

.agate-supervision-page .supervision-dt .dt-button {
  border: 1px solid #c9d8ea !important;
  border-radius: 999px !important;
  background: #ffffff !important;
  color: #174f8f !important;
  font-size: 12px !important;
  font-weight: 800 !important;
  padding: 7px 13px !important;
  box-shadow: 0 6px 14px rgba(15, 35, 65, 0.07) !important;
}

.agate-supervision-page .supervision-dt .dt-button:hover {
  background: #eef5ff !important;
  border-color: #9dbbe5 !important;
}

.agate-supervision-page .dataTables_wrapper {
  color: #102a43;
}

.agate-supervision-page .dataTables_wrapper .dataTables_filter label,
.agate-supervision-page .dataTables_wrapper .dataTables_length label,
.agate-supervision-page .dataTables_wrapper .dataTables_info,
.agate-supervision-page .dataTables_wrapper .dataTables_paginate {
  color: #415a77;
  font-size: 12.5px;
}

.agate-supervision-page .dataTables_wrapper .dataTables_filter input,
.agate-supervision-page .dataTables_wrapper .dataTables_length select {
  border: 1px solid #c8d5e6;
  border-radius: 8px;
  padding: 6px 8px;
  background: #ffffff;
  color: #102a43;
}

.agate-supervision-page table.dataTable {
  border-collapse: separate !important;
  border-spacing: 0;
  width: 100% !important;
  border-bottom: 1px solid #d8e2f0 !important;
}

.agate-supervision-page table.dataTable thead th,
.agate-supervision-page table.dataTable thead td {
  background: #f1f6fd !important;
  color: #0b2f5b !important;
  border-bottom: 1px solid #cbd8e8 !important;
  font-weight: 850;
  font-size: 13px;
  padding: 11px 10px !important;
}

.agate-supervision-page table.dataTable tbody td {
  color: #102a43;
  border-top: 1px solid #e3ebf5;
  font-size: 13px;
  padding: 11px 10px !important;
  vertical-align: middle;
}

.agate-supervision-page table.dataTable tbody tr:nth-child(odd) td:not([style]) {
  background: #ffffff;
}

.agate-supervision-page table.dataTable tbody tr:nth-child(even) td:not([style]) {
  background: #f7faff;
}

.agate-supervision-page table.dataTable tbody tr:hover td:not([style]) {
  background: #eaf3ff;
}

.agate-supervision-page table.dataTable tbody tr.selected td,
.agate-supervision-page table.dataTable tbody tr.selected:hover td {
  background: #2563eb !important;
  color: #ffffff !important;
}

.agate-supervision-page .paginate_button,
.agate-supervision-page .paginate_button a {
  border-radius: 8px !important;
}

.agate-supervision-page .dataTables_wrapper .dataTables_paginate .paginate_button.current,
.agate-supervision-page .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
  background: #2563eb !important;
  border-color: #2563eb !important;
  color: #ffffff !important;
}

/* =========================================================
   DETAIL PROPOSITION
   ========================================================= */

.agate-supervision-page .supervision-detail-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.agate-supervision-page .supervision-detail-box {
  background: linear-gradient(145deg, #ffffff 0%, #f3f8ff 100%);
  border: 1px solid #d4e0ef;
  border-radius: 16px;
  padding: 13px;
  box-shadow: 0 8px 18px rgba(15, 35, 65, 0.05);
}

.agate-supervision-page .supervision-detail-label {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.085em;
  color: #60748d;
  font-weight: 850;
  margin-bottom: 6px;
}

.agate-supervision-page .supervision-detail-value {
  font-size: 14px;
  color: #102a43;
  line-height: 1.5;
  word-break: break-word;
}

/* =========================================================
   MODALE SUPERVISION
   ========================================================= */

.supervision-edit-modal .modal-content {
  border-radius: 20px;
  border: 1px solid #d3deec;
  box-shadow: 0 24px 70px rgba(15, 23, 42, 0.24);
  overflow: hidden;
}

.supervision-edit-modal .modal-header {
  background: linear-gradient(145deg, #0b2f5b 0%, #174f8f 100%);
  color: #ffffff;
  border-bottom: none;
}

.supervision-edit-modal .modal-title {
  color: #ffffff;
  font-weight: 850;
}

.supervision-edit-modal .modal-body {
  background: #f8fbff;
}

.supervision-edit-modal .modal-footer {
  background: #ffffff;
  border-top: 1px solid #d8e2f0;
}

.supervision-edit-modal-grid {
  display: grid;
  grid-template-columns: 380px minmax(0, 1fr);
  gap: 18px;
}

.supervision-edit-modal-side,
.supervision-edit-modal-main {
  background: #ffffff;
  border: 1px solid #d8e2f0;
  border-radius: 16px;
  padding: 14px;
}

/* =========================================================
   RESPONSIVE
   ========================================================= */

@media (max-width: 1240px) {
  .agate-supervision-page .supervision-grid {
    grid-template-columns: 1fr;
  }

  .supervision-edit-modal-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 760px) {
  .agate-supervision-page {
    padding: 12px;
  }

  .agate-supervision-page .supervision-kpis {
    grid-template-columns: 1fr;
  }

  .agate-supervision-page .supervision-detail-grid {
    grid-template-columns: 1fr;
  }

  .agate-supervision-page .supervision-card {
    padding: 14px;
  }
}

/* =========================================================
   AGATE SUPERVISION - DARK MODE
   ========================================================= */

body.theme-dark .agate-supervision-page {
  background:
    radial-gradient(circle at top left, rgba(59, 130, 246, 0.18), transparent 34%),
    linear-gradient(180deg, #111827 0%, #020617 100%);
  color: #f8fafc;
}

body.theme-dark .agate-supervision-page .supervision-card {
  background: rgba(15, 23, 42, 0.94);
  border-color: #334155;
  box-shadow:
    0 18px 42px rgba(0, 0, 0, 0.38),
    0 1px 0 rgba(255, 255, 255, 0.05) inset;
}

body.theme-dark .agate-supervision-page .supervision-kpi {
  background:
    linear-gradient(145deg, #1e293b 0%, #111827 72%, #0f172a 100%);
  border-color: #334155;
  box-shadow: 0 14px 30px rgba(0, 0, 0, 0.34);
}

body.theme-dark .agate-supervision-page .supervision-kpi::before {
  background: linear-gradient(180deg, #60a5fa, #22c55e);
}

body.theme-dark .agate-supervision-page .supervision-kpi::after {
  background: rgba(96, 165, 250, 0.12);
}

body.theme-dark .agate-supervision-page .supervision-section-title,
body.theme-dark .agate-supervision-page .supervision-status-title,
body.theme-dark .agate-supervision-page .supervision-kpi-value,
body.theme-dark .agate-supervision-page .supervision-detail-value,
body.theme-dark .agate-supervision-page label,
body.theme-dark .agate-supervision-page .control-label {
  color: #ffffff;
}

body.theme-dark .agate-supervision-page .supervision-status-copy,
body.theme-dark .agate-supervision-page .supervision-note,
body.theme-dark .agate-supervision-page .supervision-kpi-help,
body.theme-dark .agate-supervision-page .supervision-kpi-label,
body.theme-dark .agate-supervision-page .supervision-status-kicker,
body.theme-dark .agate-supervision-page .supervision-tab-intro,
body.theme-dark .agate-supervision-page .supervision-detail-label,
body.theme-dark .agate-supervision-page .supervision-edit-help {
  color: #dbeafe;
}

body.theme-dark .agate-supervision-page .supervision-status-banner,
body.theme-dark .agate-supervision-page .supervision-detail-box {
  background: linear-gradient(145deg, #1e293b 0%, #111827 100%);
  border-color: #334155;
  color: #f8fafc;
}

body.theme-dark .agate-supervision-page .supervision-status-banner.is-queue {
  background: linear-gradient(145deg, #3b1223 0%, #1f1020 100%);
  border-color: #9f4069;
}

body.theme-dark .agate-supervision-page .supervision-status-banner.is-progress {
  background: linear-gradient(145deg, #172554 0%, #0f172a 100%);
  border-color: #315faa;
}

body.theme-dark .agate-supervision-page .supervision-status-banner.is-rejected {
  background: linear-gradient(145deg, #3b2f13 0%, #1f1a10 100%);
  border-color: #a16207;
}

body.theme-dark .agate-supervision-page .supervision-inline-info {
  background: linear-gradient(145deg, #3b82f6, #1d4ed8);
  color: #ffffff;
}

body.theme-dark .agate-supervision-page .supervision-inline-info::after {
  background: #020617;
  color: #ffffff;
  border: 1px solid #60a5fa;
}

body.theme-dark .agate-supervision-page .supervision-inline-info::before {
  border-bottom-color: #60a5fa;
}

/* Onglets dark */

body.theme-dark .agate-supervision-page .supervision-subpanel-tabs > .nav,
body.theme-dark .agate-supervision-page .nav-tabs {
  border-bottom-color: #334155;
}

body.theme-dark .agate-supervision-page .supervision-subpanel-tabs > .nav > li > a,
body.theme-dark .agate-supervision-page .nav-tabs > li > a {
  background: transparent;
  border-color: transparent;
  color: #e2e8f0;
}

body.theme-dark .agate-supervision-page .supervision-subpanel-tabs > .nav > li > a:hover,
body.theme-dark .agate-supervision-page .nav-tabs > li > a:hover {
  background: #1e293b;
  border-color: #475569;
  color: #ffffff;
}

body.theme-dark .agate-supervision-page .supervision-subpanel-tabs > .nav > li.active > a,
body.theme-dark .agate-supervision-page .supervision-subpanel-tabs > .nav > li.active > a:hover,
body.theme-dark .agate-supervision-page .supervision-subpanel-tabs > .nav > li.active > a:focus,
body.theme-dark .agate-supervision-page .nav-tabs > li.active > a,
body.theme-dark .agate-supervision-page .nav-tabs > li.active > a:hover,
body.theme-dark .agate-supervision-page .nav-tabs > li.active > a:focus {
  background: linear-gradient(145deg, #3b82f6 0%, #1d4ed8 100%);
  border-color: #60a5fa;
  color: #ffffff;
}

/* Inputs dark */

body.theme-dark .agate-supervision-page .form-control,
body.theme-dark .agate-supervision-page .selectize-input,
body.theme-dark .agate-supervision-page .selectize-dropdown,
body.theme-dark .agate-supervision-page .selectize-dropdown-content {
  background: #020617 !important;
  color: #ffffff !important;
  border-color: #475569 !important;
  box-shadow: none !important;
}

body.theme-dark .agate-supervision-page .form-control::placeholder,
body.theme-dark .agate-supervision-page .selectize-input input::placeholder {
  color: #94a3b8 !important;
}

body.theme-dark .agate-supervision-page .selectize-input input {
  color: #ffffff !important;
}

body.theme-dark .agate-supervision-page .selectize-dropdown .option {
  background: #020617 !important;
  color: #ffffff !important;
}

body.theme-dark .agate-supervision-page .selectize-dropdown .option.active,
body.theme-dark .agate-supervision-page .selectize-dropdown .option:hover {
  background: #2563eb !important;
  color: #ffffff !important;
}

body.theme-dark .agate-supervision-page .selectize-control.multi .selectize-input > div,
body.theme-dark .agate-supervision-page .selectize-control.multi .selectize-input .item {
  background: #1d4ed8 !important;
  border: 1px solid #60a5fa !important;
  color: #ffffff !important;
  border-radius: 8px !important;
}

/* Boutons dark */

body.theme-dark .agate-supervision-page .btn-default {
  background: #1e293b;
  border-color: #475569;
  color: #e2e8f0;
}

body.theme-dark .agate-supervision-page .btn-default:hover {
  background: #334155;
  border-color: #64748b;
  color: #ffffff;
}

/* DT dark */

body.theme-dark .agate-supervision-page .dataTables_wrapper,
body.theme-dark .agate-supervision-page .dataTables_wrapper .dataTables_filter label,
body.theme-dark .agate-supervision-page .dataTables_wrapper .dataTables_length label,
body.theme-dark .agate-supervision-page .dataTables_wrapper .dataTables_info,
body.theme-dark .agate-supervision-page .dataTables_wrapper .dataTables_paginate {
  color: #e2e8f0 !important;
}

body.theme-dark .agate-supervision-page .dataTables_wrapper .dataTables_filter input,
body.theme-dark .agate-supervision-page .dataTables_wrapper .dataTables_length select {
  background: #020617 !important;
  color: #ffffff !important;
  border-color: #475569 !important;
}

body.theme-dark .agate-supervision-page .supervision-dt .dt-button {
  background: #020617 !important;
  border-color: #475569 !important;
  color: #e2e8f0 !important;
}

body.theme-dark .agate-supervision-page .supervision-dt .dt-button:hover {
  background: #1e293b !important;
  border-color: #60a5fa !important;
  color: #ffffff !important;
}

body.theme-dark .agate-supervision-page table.dataTable {
  border-bottom-color: #334155 !important;
}

body.theme-dark .agate-supervision-page table.dataTable thead th,
body.theme-dark .agate-supervision-page table.dataTable thead td {
  background: #020617 !important;
  color: #ffffff !important;
  border-color: #334155 !important;
}

/* Important : ne pas casser DT::formatStyle() */
body.theme-dark .agate-supervision-page table.dataTable tbody td {
  color: #ffffff;
  border-color: #1e293b !important;
}

body.theme-dark .agate-supervision-page table.dataTable tbody tr:nth-child(odd) td:not([style]) {
  background: #111827;
}

body.theme-dark .agate-supervision-page table.dataTable tbody tr:nth-child(even) td:not([style]) {
  background: #020617;
}

body.theme-dark .agate-supervision-page table.dataTable tbody tr:hover td:not([style]) {
  background: #1e293b;
  color: #ffffff;
}

body.theme-dark .agate-supervision-page table.dataTable tbody tr.selected td,
body.theme-dark .agate-supervision-page table.dataTable tbody tr.selected:hover td {
  background: #2563eb !important;
  color: #ffffff !important;
}

body.theme-dark .agate-supervision-page .dataTables_wrapper .dataTables_paginate .paginate_button.current,
body.theme-dark .agate-supervision-page .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
  background: #2563eb !important;
  border-color: #60a5fa !important;
  color: #ffffff !important;
}

/* Modale dark */

body.theme-dark .supervision-edit-modal .modal-content {
  background: #0f172a;
  border-color: #334155;
  color: #f8fafc;
}

body.theme-dark .supervision-edit-modal .modal-header {
  background: linear-gradient(145deg, #1e3a8a 0%, #0f172a 100%);
  border-bottom: 1px solid #334155;
}

body.theme-dark .supervision-edit-modal .modal-body {
  background: #020617;
  color: #f8fafc;
}

body.theme-dark .supervision-edit-modal .modal-footer {
  background: #0f172a;
  border-top-color: #334155;
}

body.theme-dark .supervision-edit-modal-side,
body.theme-dark .supervision-edit-modal-main {
  background: #111827;
  border-color: #334155;
  color: #f8fafc;
}

/* =========================================================
   CHAMPS LECTURE SEULE METIER
   ========================================================= */

.agate-supervision-page .supervision-readonly-field {
  margin-bottom: 15px;
}

.agate-supervision-page .supervision-readonly-value {
  min-height: 34px;
  display: flex;
  align-items: center;
  width: 100%;
  padding: 7px 12px;
  border-radius: 10px;
  border: 1px solid #c8d5e6;
  background:
    linear-gradient(145deg, #f8fbff 0%, #eef5ff 100%);
  color: #0b2f5b;
  font-weight: 800;
  letter-spacing: 0.02em;
  box-shadow:
    0 1px 0 rgba(255, 255, 255, 0.9) inset,
    0 8px 18px rgba(15, 35, 65, 0.05);
}

.agate-supervision-page .supervision-readonly-value::before {
  content: '🔒';
  margin-right: 8px;
  font-size: 13px;
  opacity: 0.75;
}

body.theme-dark .agate-supervision-page .supervision-readonly-value {
  background: linear-gradient(145deg, #020617 0%, #111827 100%);
  border-color: #475569;
  color: #ffffff;
  box-shadow: none;
}

/* =========================================================
   DETAIL PROPOSITION - ORGANISATION METIER
   ========================================================= */

.agate-supervision-page .supervision-detail-section {
  margin-top: 18px;
}

.agate-supervision-page .supervision-detail-section:first-child {
  margin-top: 0;
}

.agate-supervision-page .supervision-detail-section-head {
  margin-bottom: 10px;
}

.agate-supervision-page .supervision-detail-section-title {
  font-size: 15px;
  font-weight: 900;
  color: #0b2f5b;
  letter-spacing: -0.01em;
}

.agate-supervision-page .supervision-detail-section-subtitle {
  margin-top: 3px;
  font-size: 12px;
  color: #60748d;
  line-height: 1.45;
}

.agate-supervision-page .supervision-detail-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.agate-supervision-page .supervision-detail-box {
  width: 100%;
  text-align: left;
  background: linear-gradient(145deg, #ffffff 0%, #f3f8ff 100%);
  border: 1px solid #d4e0ef;
  border-radius: 16px;
  padding: 13px;
  box-shadow: 0 8px 18px rgba(15, 35, 65, 0.05);
  color: inherit;
}

.agate-supervision-page .supervision-detail-clickable {
  cursor: pointer;
  transition: transform 0.12s ease, border-color 0.12s ease, box-shadow 0.12s ease;
}

.agate-supervision-page .supervision-detail-clickable:hover {
  transform: translateY(-1px);
  border-color: #3b82f6;
  box-shadow: 0 14px 28px rgba(37, 99, 235, 0.16);
}

.agate-supervision-page .supervision-detail-label {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.085em;
  color: #60748d;
  font-weight: 900;
  margin-bottom: 6px;
}

.agate-supervision-page .supervision-detail-value {
  font-size: 14px;
  color: #102a43;
  line-height: 1.5;
  word-break: break-word;
}

.agate-supervision-page .supervision-detail-box.is-identity {
  border-color: #bfdbfe;
  background: linear-gradient(145deg, #eff6ff 0%, #dbeafe 100%);
}

.agate-supervision-page .supervision-detail-box.is-status {
  border-color: #c7d2fe;
  background: linear-gradient(145deg, #eef2ff 0%, #e0e7ff 100%);
}

.agate-supervision-page .supervision-detail-box.is-edition,
.agate-supervision-page .supervision-detail-box.is-edition-wide {
  border-color: #fed7aa;
  background: linear-gradient(145deg, #fff7ed 0%, #ffedd5 100%);
}

.agate-supervision-page .supervision-detail-box.is-current {
  border-color: #bbf7d0;
  background: linear-gradient(145deg, #f0fdf4 0%, #dcfce7 100%);
}

.agate-supervision-page .supervision-detail-box.is-supervision,
.agate-supervision-page .supervision-detail-box.is-supervision-wide {
  border-color: #bfdbfe;
  background: linear-gradient(145deg, #eff6ff 0%, #dbeafe 100%);
}

.agate-supervision-page .supervision-detail-box.is-graph {
  border-color: #93c5fd;
  background: linear-gradient(145deg, #dbeafe 0%, #bfdbfe 100%);
}

.agate-supervision-page .supervision-detail-box.is-muted {
  border-color: #e2e8f0;
  background: linear-gradient(145deg, #f8fafc 0%, #f1f5f9 100%);
}

.agate-supervision-page .supervision-detail-box.is-before {
  border-color: #e2e8f0;
  background: linear-gradient(145deg, #f8fafc 0%, #f1f5f9 100%);
}

.agate-supervision-page .supervision-detail-box.is-after {
  border-color: #bbf7d0;
  background: linear-gradient(145deg, #f0fdf4 0%, #dcfce7 100%);
}

/* Dark mode */

body.theme-dark .agate-supervision-page .supervision-detail-section-title {
  color: #ffffff;
}

body.theme-dark .agate-supervision-page .supervision-detail-section-subtitle {
  color: #bfdbfe;
}

body.theme-dark .agate-supervision-page .supervision-detail-box {
  background: linear-gradient(145deg, #1e293b 0%, #111827 100%);
  border-color: #334155;
  color: #ffffff;
  box-shadow: 0 10px 22px rgba(0, 0, 0, 0.28);
}

body.theme-dark .agate-supervision-page .supervision-detail-label {
  color: #bfdbfe;
}

body.theme-dark .agate-supervision-page .supervision-detail-value {
  color: #ffffff;
}

body.theme-dark .agate-supervision-page .supervision-detail-box.is-identity {
  border-color: #3b82f6;
  background: linear-gradient(145deg, #172554 0%, #0f172a 100%);
}

body.theme-dark .agate-supervision-page .supervision-detail-box.is-status {
  border-color: #6366f1;
  background: linear-gradient(145deg, #312e81 0%, #111827 100%);
}

body.theme-dark .agate-supervision-page .supervision-detail-box.is-edition,
body.theme-dark .agate-supervision-page .supervision-detail-box.is-edition-wide {
  border-color: #f59e0b;
  background: linear-gradient(145deg, #3b2f13 0%, #111827 100%);
}

body.theme-dark .agate-supervision-page .supervision-detail-box.is-current {
  border-color: #22c55e;
  background: linear-gradient(145deg, #052e16 0%, #111827 100%);
}

body.theme-dark .agate-supervision-page .supervision-detail-box.is-supervision,
body.theme-dark .agate-supervision-page .supervision-detail-box.is-supervision-wide {
  border-color: #60a5fa;
  background: linear-gradient(145deg, #172554 0%, #111827 100%);
}

body.theme-dark .agate-supervision-page .supervision-detail-box.is-graph {
  border-color: #38bdf8;
  background: linear-gradient(145deg, #075985 0%, #0f172a 100%);
}

body.theme-dark .agate-supervision-page .supervision-detail-box.is-muted {
  border-color: #475569;
  background: linear-gradient(145deg, #111827 0%, #020617 100%);
}

@media (max-width: 760px) {
  .agate-supervision-page .supervision-detail-grid {
    grid-template-columns: 1fr;
  }
}
.agate-supervision-page .supervision-detail-action,
.agate-supervision-page .supervision-detail-action.btn,
.agate-supervision-page .supervision-detail-action.btn-default {
  display: block;
  width: 100%;
  text-align: left;
  white-space: normal;
  padding: 13px;
  border-radius: 16px;
  box-shadow: 0 8px 18px rgba(15, 35, 65, 0.05);
}

.agate-supervision-page .supervision-detail-action:hover,
.agate-supervision-page .supervision-detail-action:focus {
  text-decoration: none;
  outline: none;
}

.agate-supervision-page .supervision-detail-action .supervision-detail-label,
.agate-supervision-page .supervision-detail-action .supervision-detail-value {
  pointer-events: none;
}

/* =========================================================
   MODALE SUPERVISION - FORMAT LARGE 22 POUCES / SHINYPROXY
   ========================================================= */

/* Largeur réelle de la modale */
.supervision-edit-modal.modal-dialog,
.modal-dialog.supervision-edit-modal {
  width: min(1780px, calc(100vw - 20px)) !important;
  max-width: min(1780px, calc(100vw - 20px)) !important;
  margin: 18px auto 12px !important;
}

/* Conteneur principal */
.supervision-edit-modal .modal-content {
  max-height: calc(100vh - 80px);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* Header/footer compacts */
.supervision-edit-modal .modal-header {
  padding: 14px 18px;
  flex: 0 0 auto;
}

.supervision-edit-modal .modal-title {
  font-size: 17px;
  font-weight: 850;
}

.supervision-edit-modal .modal-footer {
  padding: 10px 14px;
  flex: 0 0 auto;
}

/* Le body ne fait pas scroller toute la page */
.supervision-edit-modal .modal-body {
  flex: 1 1 auto;
  overflow: hidden;
  padding: 14px 16px;
}

/* Colonne gauche fixe, tableau très large */
.supervision-edit-modal-grid {
  height: calc(100vh - 185px);
  max-height: calc(100vh - 185px);
  display: grid;
  grid-template-columns: 380px minmax(0, 1fr);
  gap: 18px;
  align-items: stretch;
}

/* Empêche les colonnes d'élargir/casser la modale */
.supervision-edit-modal-side,
.supervision-edit-modal-main {
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  padding: 14px;
}

/* Colonne gauche scrollable */
.supervision-edit-modal-side {
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

/* Colonne droite dédiée au DT */
.supervision-edit-modal-main {
  display: flex;
  flex-direction: column;
}

/* Textes compacts */
.supervision-edit-modal .supervision-edit-help,
.supervision-edit-modal .supervision-note {
  font-size: 12px;
  line-height: 1.45;
  margin-bottom: 10px;
}

.supervision-edit-modal .supervision-section-title {
  font-size: 15px;
  margin-bottom: 6px;
}

/* Selectize parent */
.supervision-edit-modal-side .selectize-control.single {
  margin-bottom: 10px;
}

/* Selectize enfants */
.supervision-edit-modal-side .selectize-control.multi {
  margin-bottom: 10px;
}

.supervision-edit-modal-side .selectize-control.multi .selectize-input {
  max-height: 150px;
  overflow-y: auto;
}

/* Items du selectize enfants plus denses */
.supervision-edit-modal-side .selectize-control.multi .selectize-input > div,
.supervision-edit-modal-side .selectize-control.multi .selectize-input .item {
  display: block;
  max-width: 100%;
  white-space: normal;
  line-height: 1.25;
  padding: 4px 7px !important;
  margin: 2px 0 !important;
}

/* Aperçu gauche compact */
.supervision-edit-modal-side hr {
  margin: 10px 0;
}

.supervision-edit-modal-side p {
  margin-bottom: 7px;
}

/* Zone DT */
.supervision-edit-modal-main .supervision-dt {
  flex: 1 1 auto;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
}

/* Wrapper DataTables */
.supervision-edit-modal-main .dataTables_wrapper {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
}

/* Barre length/search compacte */
.supervision-edit-modal-main .dataTables_length,
.supervision-edit-modal-main .dataTables_filter {
  margin-bottom: 8px;
}

.supervision-edit-modal-main .dataTables_length label,
.supervision-edit-modal-main .dataTables_filter label {
  font-size: 12px;
}

.supervision-edit-modal-main .dataTables_filter input,
.supervision-edit-modal-main .dataTables_length select {
  height: 30px;
  padding: 4px 8px;
}

/* Scroll DataTables horizontal + vertical */
.supervision-edit-modal-main .dataTables_scroll {
  flex: 1 1 auto;
  min-width: 0;
  min-height: 0;
  width: 100%;
}

.supervision-edit-modal-main .dataTables_scrollHead,
.supervision-edit-modal-main .dataTables_scrollBody {
  width: 100% !important;
}

.supervision-edit-modal-main .dataTables_scrollBody {
  max-height: calc(100vh - 320px) !important;
  overflow: auto !important;
}

/* Cellules plus tassées */
.supervision-edit-modal-main table.dataTable thead th,
.supervision-edit-modal-main table.dataTable thead td,
.supervision-edit-modal-main table.dataTable tbody td {
  padding: 8px 10px !important;
  font-size: 12.5px;
  line-height: 1.3;
  white-space: nowrap;
}

/* Filtres de colonnes compacts */
.supervision-edit-modal-main table.dataTable thead input,
.supervision-edit-modal-main table.dataTable thead select {
  height: 30px;
  padding: 4px 7px;
  font-size: 12px;
}

/* Footer DataTable compact */
.supervision-edit-modal-main .dataTables_info,
.supervision-edit-modal-main .dataTables_paginate {
  font-size: 12px;
  padding-top: 8px !important;
}

/* Boutons footer */
.supervision-edit-modal .modal-footer .btn {
  padding: 7px 13px;
  font-size: 12.5px;
}

/* Responsive */
@media (max-width: 1050px) {
  .supervision-edit-modal.modal-dialog,
  .modal-dialog.supervision-edit-modal {
    width: calc(100vw - 18px) !important;
    max-width: calc(100vw - 18px) !important;
    margin: 24px auto 12px !important;
  }

  .supervision-edit-modal-grid {
    height: auto;
    max-height: none;
    grid-template-columns: 1fr;
  }

  .supervision-edit-modal .modal-body {
    overflow-y: auto;
  }

  .supervision-edit-modal-side,
  .supervision-edit-modal-main {
    overflow: visible;
  }

  .supervision-edit-modal-main .dataTables_scrollBody {
    max-height: 420px !important;
  }
}
/* =========================================================
   AGATE SUPERVISION - OVERLAY CHARGEMENT SIMPLE
   ========================================================= */

.agate-supervision-loading-overlay {
  position: fixed;
  inset: 0;
  z-index: 999999;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(2, 6, 23, 0.62);
  backdrop-filter: blur(3px);
}

.agate-supervision-loading-card {
  width: min(520px, calc(100vw - 48px));
  border-radius: 22px;
  border: 1px solid rgba(96, 165, 250, 0.45);
  background: linear-gradient(145deg, #0f172a 0%, #020617 100%);
  color: #ffffff;
  box-shadow: 0 24px 70px rgba(0, 0, 0, 0.48);
  padding: 28px;
  text-align: center;
}

.agate-supervision-loading-spinner {
  width: 46px;
  height: 46px;
  margin: 0 auto 16px;
  border-radius: 999px;
  border: 4px solid rgba(148, 163, 184, 0.35);
  border-top-color: #60a5fa;
  animation: agate-supervision-spin 0.85s linear infinite;
}

.agate-supervision-loading-title {
  font-size: 16px;
  font-weight: 850;
  color: #ffffff;
  margin-bottom: 8px;
}

.agate-supervision-loading-copy {
  font-size: 13px;
  line-height: 1.45;
  color: #bfdbfe;
}

@keyframes agate-supervision-spin {
  to {
    transform: rotate(360deg);
  }
}

/* =========================================================
   AGATE SUPERVISION - MODIFICATION EN COURS PLEINE LARGEUR
   ========================================================= */

.agate-supervision-page .supervision-modification-card {
  border-left: 5px solid #2563eb;
}

.agate-supervision-page .supervision-modification-layout {
  display: grid;
  grid-template-columns: minmax(320px, 430px) minmax(0, 1fr);
  gap: 16px;
  align-items: start;
}

.agate-supervision-page .supervision-modification-side,
.agate-supervision-page .supervision-modification-reference {
  min-width: 0;
}

.agate-supervision-page .supervision-modification-side {
  padding: 14px;
  border-radius: 16px;
  background: #f8fbff;
  border: 1px solid #dbe7f5;
}

.agate-supervision-page .supervision-modification-reference {
  padding: 14px;
  border-radius: 16px;
  background: #ffffff;
  border: 1px solid #dbe7f5;
}

.agate-supervision-page .supervision-modification-actions {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  margin-top: 12px;
}

.agate-supervision-page .supervision-modification-warning {
  padding: 11px 13px;
  border-radius: 13px;
  border: 1px solid #f59e0b;
  background: #fff7ed;
  color: #92400e;
  font-size: 13px;
  line-height: 1.45;
  margin-bottom: 12px;
}

.agate-supervision-page .supervision-children-count {
  margin: 0 0 10px;
  padding: 9px 11px;
  border-radius: 12px;
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  color: #1e3a8a;
  font-size: 13px;
  font-weight: 700;
}

body.theme-dark .agate-supervision-page .supervision-modification-side,
body.theme-dark .agate-supervision-page .supervision-modification-reference {
  background: #111827;
  border-color: #334155;
  color: #e5e7eb;
}

body.theme-dark .agate-supervision-page .supervision-modification-card {
  border-left-color: #60a5fa;
}

body.theme-dark .agate-supervision-page .supervision-modification-warning {
  background: #422006;
  border-color: #f59e0b;
  color: #fde68a;
}

body.theme-dark .agate-supervision-page .supervision-children-count {
  background: #172554;
  border-color: #1d4ed8;
  color: #dbeafe;
}


.agate-supervision-page .supervision-mode-help {
  padding: 10px 12px;
  border-radius: 12px;
  font-size: 13px;
  line-height: 1.45;
  margin: 8px 0 12px;
}

.agate-supervision-page .supervision-mode-help.is-quick {
  background: #ecfdf5;
  border: 1px solid #86efac;
  color: #166534;
}

.agate-supervision-page .supervision-mode-help.is-complete {
  background: #fff7ed;
  border: 1px solid #fdba74;
  color: #9a3412;
}

.agate-supervision-page .supervision-current-parent {
  padding: 10px 12px;
  border-radius: 12px;
  background: #ffffff;
  border: 1px solid #dbe7f5;
  color: #0f172a;
  margin: 8px 0 12px;
  font-size: 13px;
  line-height: 1.45;
}

.agate-supervision-page .supervision-current-parent.is-empty {
  background: #f8fafc;
  color: #64748b;
  border-style: dashed;
}

.agate-supervision-page .supervision-children-work-header {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  align-items: baseline;
  margin: 10px 0 6px;
  font-size: 13px;
}

.agate-supervision-page .supervision-children-work-header span {
  color: #64748b;
  font-size: 12px;
}

.agate-supervision-page .supervision-children-work-dt {
  margin-bottom: 10px;
}

.agate-supervision-page .supervision-reference-actions,
.agate-supervision-page .supervision-recomposition-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin: 10px 0 12px;
}

.agate-supervision-page .supervision-recomposition-actions {
  padding: 10px 12px;
  border-radius: 12px;
  background: #fff1f2;
  border: 1px solid #fecdd3;
}

.agate-supervision-page .supervision-edit-preview {
  padding: 10px 12px;
  border-radius: 12px;
  border: 1px solid #bfdbfe;
  background: #eff6ff;
  color: #1e3a8a;
  margin-top: 12px;
}

.agate-supervision-page .supervision-edit-preview-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  padding: 3px 0;
  font-size: 13px;
}

.agate-supervision-page .supervision-modification-submit {
  padding-top: 12px;
  border-top: 1px solid #dbe7f5;
}

body.theme-dark .agate-supervision-page .supervision-mode-help.is-quick {
  background: #052e16;
  border-color: #15803d;
  color: #bbf7d0;
}

body.theme-dark .agate-supervision-page .supervision-mode-help.is-complete {
  background: #431407;
  border-color: #c2410c;
  color: #fed7aa;
}

body.theme-dark .agate-supervision-page .supervision-current-parent {
  background: #0f172a;
  border-color: #334155;
  color: #e5e7eb;
}

body.theme-dark .agate-supervision-page .supervision-current-parent.is-empty,
body.theme-dark .agate-supervision-page .supervision-children-work-header span {
  color: #94a3b8;
}

body.theme-dark .agate-supervision-page .supervision-recomposition-actions {
  background: #450a0a;
  border-color: #991b1b;
}

body.theme-dark .agate-supervision-page .supervision-edit-preview {
  background: #172554;
  border-color: #1d4ed8;
  color: #dbeafe;
}

body.theme-dark .agate-supervision-page .supervision-modification-submit {
  border-top-color: #334155;
}

@media (max-width: 1180px) {
  .agate-supervision-page .supervision-modification-layout {
    grid-template-columns: 1fr;
  }
}

      "))
    ),
    div(
      class = "agate-supervision-page",
      div(
        class = "supervision-card",
        div(class = "supervision-section-title", "Supervision AGATE — parcours guidé"),
        p(
          class = "supervision-note",
          "Sélectionnez d'abord un dossier À superviser, prenez-le en charge, puis décidez de le transmettre, de l'ajuster ou de le rejeter. Les outils de recomposition n'apparaissent que lorsqu'ils sont utiles."
        ),
        tags$details(
          class = "supervision-advanced-details",
          tags$summary("Voir les indicateurs de pilotage"),
          uiOutput("agate_supervision_kpi_panel")
        )
      ),
      div(
        class = "supervision-grid",
        div(
          div(
            class = "supervision-card",
            section_title_with_info(
              "Prise en charge / décision",
              "Cette zone affiche l'action utile selon l'état du dossier : prise en charge, décision supervision ou reprise d'édition."
            ),
            uiOutput("agate_supervision_action_context"),
            uiOutput("agate_supervision_action_panel")
          )
        ),
        div(
          div(
            class = "supervision-card",
            tabsetPanel(
              id = "agate_supervision_status_tab",
              type = "tabs",
              tabPanel(
                title = "1. À superviser",
                value = "A superviser",
                div(
                  class = "supervision-tab-intro",
                  span("Vue compacte par defaut pour faciliter la prise en main."),
                  inline_info("Les colonnes supervision sont masquees tant que le dossier est juste en attente. Utilise le bouton Choisir les colonnes pour afficher plus de details.")
                ),
                div(class = "supervision-dt", DTOutput("agate_table_supervision_queue"))
              ),
              tabPanel(
                title = "2. En cours",
                value = "En cours",
                div(
                  class = "supervision-tab-intro",
                  span("Ici, le dossier est deja pris en charge. Le detail apparait sous le tableau, puis le bloc Modification de la proposition permet d'ajuster la version supervision en pleine largeur."),
                  inline_info("Le superviseur lit d'abord la proposition, puis modifie si besoin dans le bloc dedie sous le detail. Le referentiel source n'est plus enferme dans une modale.")
                ),
                div(class = "supervision-dt", DTOutput("agate_table_supervision_in_progress"))
              ),
              tabPanel(
                title = "Historique · Rejetés",
                value = "Rejetes",
                div(
                  class = "supervision-tab-intro",
                  span("Les rejets restent consultables pour comprendre la decision."),
                  inline_info("Le bouton Choisir les colonnes permet aussi de reafficher certains champs si tu veux analyser un cas plus finement.")
                ),
                div(class = "supervision-dt", DTOutput("agate_table_supervision_rejected"))
              )
            )
          ),
          div(
            class = "supervision-card",
            section_title_with_info("Detail de la proposition", "Ce bloc resume l'etat courant du dossier et ce qui a deja ete decide ou modifie."),
            uiOutput("agate_supervision_detail")
          ),
          uiOutput("agate_supervision_modification_workspace")
        )
      )
    )
  )
}
