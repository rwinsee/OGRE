agate_supervision_server <- function(input, output, session) {
  source_agate_workflow(environment())
  
  # helpers robustes pour eviter les `if (NA)` quand un selectizeInput
  # n'a pas encore de valeur au moment de l'initialisation reactive
  scalar_chr <- function(x, default = "") {
    if (is.null(x) || length(x) == 0) {
      return(default)
    }
    
    x <- as.character(x[[1]])
    
    if (is.na(x)) {
      return(default)
    }
    
    trimws(x)
  }
  
  vec_chr <- function(x) {
    if (is.null(x) || length(x) == 0) {
      return(character(0))
    }
    
    x <- trimws(as.character(x))
    x[!is.na(x) & nzchar(x)]
  }
  
  first_non_empty_vec <- function(x) {
    if (is.null(x) || length(x) == 0) {
      return(character(0))
    }
    
    x <- as.character(x)
    x[is.na(x)] <- ""
    trimws(x)
  }
  
  is_filled <- function(x) {
    nzchar(scalar_chr(x, default = ""))
  }
  
  get_detected_idep <- function() {
    candidates <- c(
      if (!is.null(session$userData$user_idep)) session$userData$user_idep else "",
      if (!is.null(session$userData$idep)) session$userData$idep else "",
      if (exists("user_idep", inherits = TRUE)) get("user_idep", inherits = TRUE) else "",
      Sys.getenv("USER_IDEP", unset = ""),
      Sys.getenv("IDEP", unset = "")
    )
    
    candidates <- trimws(as.character(candidates))
    candidates <- candidates[nzchar(candidates)]
    
    if (length(candidates) == 0) {
      return("")
    }
    
    candidates[1]
  }
  show_supervision_children_modal <- function(children_df, title = "Enfants") {
    if (is.null(children_df) || nrow(children_df) == 0) {
      showModal(modalDialog(
        title = title,
        tags$p("Aucun enfant à afficher pour cette version."),
        easyClose = TRUE,
        footer = modalButton("Fermer")
      ))
      return(invisible(NULL))
    }
    
    children_df <- children_df %>%
      dplyr::mutate(
        code_ogr = ifelse(is.na(code_ogr) | !nzchar(code_ogr), "—", code_ogr),
        libelle = ifelse(is.na(libelle) | !nzchar(libelle), "—", libelle)
      ) %>%
      dplyr::transmute(
        `Code APET` = code_ogr,
        `Libellé enfant` = libelle
      )
    
    children_count <- nrow(children_df)
    
    showModal(modalDialog(
      title = paste0(title, " — ", children_count, " enfant(s)"),
      size = "l",
      easyClose = TRUE,
      tags$div(
        class = "supervision-children-count",
        paste0(children_count, " enfant(s) dans cette version. Utilise le sélecteur 'Show entries' pour afficher 10, 25, 50, 100 lignes ou tout le contenu.")
      ),
      DT::DTOutput("agate_supervision_children_modal_table"),
      footer = modalButton("Fermer")
    ))
    
    output$agate_supervision_children_modal_table <- DT::renderDT({
      DT::datatable(
        children_df,
        rownames = FALSE,
        selection = "none",
        class = "compact stripe hover",
        options = agate_dt_options(
          page_length = min(25L, max(10L, children_count)),
          length_menu = list(c(10, 25, 50, 100, -1), c("10", "25", "50", "100", "Tous")),
          scroll_y = "45vh",
          dom = "lfrtip",
          language = list(
            url = "//cdn.datatables.net/plug-ins/1.13.6/i18n/fr-FR.json"
          )
        )
      )
    })
    
    invisible(NULL)
  }
  detected_idep <- reactive({
    get_detected_idep()
  })
  
  supervision_agent_value <- reactive({
    detected_idep()
  })
  
  reprise_idep_agent_value <- reactive({
    detected_idep()
  })
  
  output$agate_supervision_agent_readonly <- renderText({
    value <- supervision_agent_value()
    
    if (!nzchar(value)) {
      return("IDEP non détecté")
    }
    
    value
  })
  
  output$agate_reprise_idep_agent_readonly <- renderText({
    value <- reprise_idep_agent_value()
    
    if (!nzchar(value)) {
      return("IDEP non détecté")
    }
    
    value
  })
  if (is.null(session$userData$agate_workflow_refresh)) {
    session$userData$agate_workflow_refresh <- reactiveVal(0)
  }
  
  refresh_token <- session$userData$agate_workflow_refresh
  validation_pending_states <- data.frame(
    phase = "validation",
    statut = "a_valider",
    stringsAsFactors = FALSE
  )
  
  bump_agate_workflow_refresh <- function() {
    refresh_token(as.numeric(Sys.time()) + stats::runif(1, min = 0, max = 1e-06))
  }
  
  refresh_supervision_views <- function(extra_rereads = 2L, delay_sec = 0.45) {
    bump_agate_workflow_refresh()
    
    # Rejoue la lecture quelques instants apres l'action pour absorber le
    # delai de visibilite du fichier deplace dans le workflow AGATE.
    if (extra_rereads <= 0L || !requireNamespace("later", quietly = TRUE)) {
      return(invisible(NULL))
    }
    
    for (attempt in seq_len(extra_rereads)) {
      later::later(
        function() {
          try(bump_agate_workflow_refresh(), silent = TRUE)
        },
        delay = attempt * delay_sec
      )
    }
    
    invisible(NULL)
  }
  
  supervision_kpi_state <- reactive({
    refresh_token()
    
    list(
      supervision = load_proposals("supervision") %>%
        arrange(desc(horodatage_edition), id_proposition),
      validation_pending = load_proposals(states = validation_pending_states) %>%
        arrange(desc(horodatage_decision_supervision), desc(horodatage_edition), id_proposition),
      stock_families = load_families()
    )
  })
  
  supervision_states <- reactive({
    supervision_kpi_state()$supervision
  })
  
  supervision_queue <- reactive({
    supervision_states() %>%
      filter(statut_proposition == "a_superviser")
  })
  
  supervision_in_progress <- reactive({
    supervision_states() %>%
      filter(statut_proposition == "en_cours")
  })
  
  supervision_rejected <- reactive({
    supervision_states() %>%
      filter(statut_proposition == "rejetes")
  })
  
  validation_pending <- reactive({
    supervision_kpi_state()$validation_pending
  })
  
  stock_families <- reactive({
    supervision_kpi_state()$stock_families
  })
  
  proposal_family_revision_key <- function(df) {
    if (is.null(df) || nrow(df) == 0) {
      return(character(0))
    }
    
    key <- rep("", nrow(df))
    
    if ("id_famille_rejouee" %in% names(df)) {
      key <- first_non_empty_vec(df$id_famille_rejouee)
    }
    
    if ("base_famille_id" %in% names(df)) {
      missing_key <- !nzchar(key)
      key[missing_key] <- first_non_empty_vec(df$base_famille_id[missing_key])
    }
    
    if ("id_proposition_source" %in% names(df)) {
      missing_key <- !nzchar(key)
      key[missing_key] <- first_non_empty_vec(df$id_proposition_source[missing_key])
    }
    
    if ("fichier_famille_rejouee" %in% names(df)) {
      missing_key <- !nzchar(key)
      key[missing_key] <- first_non_empty_vec(df$fichier_famille_rejouee[missing_key])
    }
    
    missing_key <- !nzchar(key)
    key[missing_key] <- paste0("parent:", first_non_empty_vec(df$code_ogr_parent[missing_key]))
    
    key
  }
  
  active_family_revision_counts <- reactive({
    active <- workflow_active_proposals()
    
    if (is.null(active) || nrow(active) == 0) {
      return(data.frame(revision_key = character(), nb_revisions_actives = integer(), stringsAsFactors = FALSE))
    }
    
    active <- active %>%
      dplyr::filter(type_operation == "modification")
    
    if (nrow(active) == 0) {
      return(data.frame(revision_key = character(), nb_revisions_actives = integer(), stringsAsFactors = FALSE))
    }
    
    active$revision_key <- proposal_family_revision_key(active)
    active %>%
      dplyr::filter(nzchar(revision_key)) %>%
      dplyr::count(revision_key, name = "nb_revisions_actives")
  })
  
  available_supervision_reference <- reactive({
    idx <- input$agate_table_supervision_reference_source_rows_selected
    
    if (length(idx) == 0) {
      return(ref_agate)
    }
    
    ref_agate[idx, , drop = FALSE]
  })
  
  workflow_active_proposals <- reactive({
    refresh_token()
    load_active_workflow_proposals() %>%
      arrange(desc(horodatage_edition), id_proposition)
  })
  
  selected_supervision <- reactive({
    active_tab <- input$agate_supervision_status_tab
    
    if (is.null(active_tab) || identical(active_tab, "A superviser")) {
      idx <- input$agate_table_supervision_queue_rows_selected
      df <- supervision_queue()
    } else if (identical(active_tab, "En cours")) {
      idx <- input$agate_table_supervision_in_progress_rows_selected
      df <- supervision_in_progress()
    } else {
      idx <- input$agate_table_supervision_rejected_rows_selected
      df <- supervision_rejected()
    }
    
    if (length(idx) != 1 || nrow(df) < idx) {
      return(NULL)
    }
    
    df[idx, , drop = FALSE]
  })
  
  supervision_seed_values <- function(proposal) {
    if (is.null(proposal)) {
      return(list(
        parent_code = character(0),
        child_codes = character(0)
      ))
    }
    
    list(
      parent_code = first_non_empty(
        proposal$code_ogr_parent_edition[1],
        proposal$code_ogr_parent[1]
      ),
      child_codes = split_pipe_values(
        first_non_empty(
          proposal$codes_ogr_enfants_edition[1],
          proposal$codes_ogr_enfants[1]
        )
      )
    )
  }
  
  build_supervision_edit_modal <- function(proposal) {
    ref_df <- ref_agate %>%
      distinct(code_ogr, .keep_all = TRUE)
    ref_choices <- build_reference_choices(ref_df)
    seed <- supervision_seed_values(proposal)
    
    parent_code <- scalar_chr(seed$parent_code)
    if (!is_filled(parent_code) || !(parent_code %in% unname(ref_choices))) {
      parent_code <- ""
    }
    
    child_choices <- ref_choices[unname(ref_choices) != parent_code]
    child_codes <- seed$child_codes[seed$child_codes %in% unname(child_choices)]
    
    modalDialog(
      title = "Modifier la version supervision",
      class = "supervision-edit-modal",
      size = "l",
      easyClose = TRUE,
      tags$div(
        class = "supervision-edit-help",
        tags$strong("Mode d'emploi : "),
        "ajustez le parent et les enfants dans le panneau de gauche. Le tableau de droite sert uniquement a retrouver des codes du referentiel et a restreindre les choix proposes. Le bouton d'envoi valide directement la version modifiee vers la MOA."
      ),
      div(
        class = "supervision-edit-modal-grid",
        div(
          class = "supervision-edit-modal-side",
          uiOutput("agate_supervision_edit_state"),
          selectizeInput(
            "supervision_parent_code",
            "Parent supervision",
            choices = ref_choices,
            selected = parent_code,
            options = list(placeholder = "Choisir le parent pour la supervision")
          ),
          selectizeInput(
            "supervision_child_codes",
            "Enfants supervision",
            choices = child_choices,
            selected = child_codes,
            multiple = TRUE,
            options = list(placeholder = "Choisir les enfants pour la supervision")
          ),
          uiOutput("agate_supervision_edit_preview")
        ),
        div(
          class = "supervision-edit-modal-main",
          tags$div(
            class = "supervision-section-title",
            "Referentiel source"
          ),
          tags$div(
            class = "supervision-note",
            "Selectionne des lignes pour limiter le choix du parent et des enfants a ce sous-ensemble, avec le meme niveau de detail referentiel qu'en edition."
          ),
          div(class = "supervision-dt", DTOutput("agate_table_supervision_reference_source"))
        )
      ),
      footer = tagList(
        modalButton("Fermer"),
        actionButton(
          "agate_validate_supervision_with_changes",
          "Envoyer la version modifiee a la validation MOA",
          class = "btn-primary"
        )
      )
    )
  }
  
  show_family_conflict_modal <- function(title, checks, closing_copy) {
    showModal(modalDialog(
      title = title,
      build_family_conflict_modal_content(checks),
      tags$p(closing_copy),
      easyClose = TRUE,
      footer = modalButton("Fermer")
    ))
  }
  
  run_supervision_transition <- function(action_fun, failure_prefix) {
    tryCatch(
      {
        action_fun()
        TRUE
      },
      error = function(e) {
        showNotification(
          paste(failure_prefix, conditionMessage(e)),
          type = "error",
          duration = 8
        )
        FALSE
      },
      finally = {
        refresh_supervision_views()
      }
    )
  }
  
  supervision_modification_compare <- reactive({
    proposal <- selected_supervision()
    
    if (is.null(proposal)) {
      return(NULL)
    }
    
    build_modification_compare(proposal, stock_families())
  })
  
  normalize_supervision_draft <- function(parent_code = "", child_codes = character(0)) {
    ref_df <- ref_agate %>%
      distinct(code_ogr, .keep_all = TRUE)
    
    ref_codes <- vec_chr(ref_df$code_ogr)
    parent_code <- scalar_chr(parent_code)
    
    if (!is_filled(parent_code) || !(parent_code %in% ref_codes)) {
      parent_code <- ""
    }
    
    child_codes <- unique(vec_chr(child_codes))
    child_codes <- child_codes[child_codes %in% ref_codes]
    child_codes <- setdiff(child_codes, parent_code)
    
    parent_row <- ref_df[match(parent_code, ref_df$code_ogr), , drop = FALSE]
    if (!is_filled(parent_code) || nrow(parent_row) == 0 || is.na(parent_row$code_ogr[1])) {
      parent_row <- ref_df[0, , drop = FALSE]
    }
    
    child_idx <- match(child_codes, ref_df$code_ogr)
    child_idx <- child_idx[!is.na(child_idx)]
    child_rows <- ref_df[child_idx, , drop = FALSE]
    
    list(
      code_ogr_parent = parent_code,
      code_rome_parent = if (nrow(parent_row) == 0) "" else first_non_empty(parent_row$code_rome[1], ""),
      libelle_parent = if (nrow(parent_row) == 0) "" else first_non_empty(parent_row$libelle_appellation_metier[1], ""),
      child_codes = vec_chr(child_rows$code_ogr),
      child_labels = vec_chr(child_rows$libelle_appellation_metier)
    )
  }
  
  build_supervision_draft_from_proposal <- function(proposal, clear = FALSE) {
    if (is.null(proposal) || isTRUE(clear)) {
      return(normalize_supervision_draft("", character(0)))
    }
    
    seed <- supervision_seed_values(proposal)
    normalize_supervision_draft(seed$parent_code, seed$child_codes)
  }
  
  supervision_draft_state <- reactiveVal(NULL)
  supervision_draft_key <- reactiveVal("")
  
  observe({
    proposal <- selected_supervision()
    key <- if (is.null(proposal)) {
      ""
    } else {
      paste0(first_non_empty(proposal$id_proposition[1], ""), "::", first_non_empty(proposal$statut_proposition[1], ""))
    }
    
    if (!identical(key, supervision_draft_key())) {
      supervision_draft_key(key)
      supervision_draft_state(build_supervision_draft_from_proposal(proposal))
    }
  })
  
  supervision_draft <- reactive({
    state <- supervision_draft_state()
    
    if (!is.null(state)) {
      return(state)
    }
    
    build_supervision_draft_from_proposal(selected_supervision())
  })
  
  selected_reference_codes <- reactive({
    idx <- input$agate_table_supervision_reference_source_rows_selected
    ref_df <- ref_agate %>%
      distinct(code_ogr, .keep_all = TRUE)
    
    if (is.null(idx) || length(idx) == 0 || nrow(ref_df) == 0) {
      return(character(0))
    }
    
    idx <- idx[!is.na(idx) & idx >= 1 & idx <= nrow(ref_df)]
    if (length(idx) == 0) {
      return(character(0))
    }
    
    unique(vec_chr(ref_df$code_ogr[idx]))
  })
  
  set_supervision_draft <- function(parent_code, child_codes) {
    supervision_draft_state(normalize_supervision_draft(parent_code, child_codes))
  }
  
  reset_supervision_draft_from_edition <- function() {
    supervision_draft_state(build_supervision_draft_from_proposal(selected_supervision()))
  }
  
  observeEvent(input$agate_supervision_add_reference_children, {
    state <- supervision_draft()
    codes <- selected_reference_codes()
    
    if (length(codes) == 0) {
      showNotification("Selectionne une ou plusieurs lignes dans le referentiel source avant d'ajouter des enfants.", type = "warning")
      return()
    }
    
    codes <- setdiff(codes, state$code_ogr_parent)
    if (length(codes) == 0) {
      showNotification("La selection ne contient aucun enfant ajoutable : le parent courant est automatiquement exclu.", type = "warning")
      return()
    }
    
    set_supervision_draft(
      parent_code = state$code_ogr_parent,
      child_codes = unique(c(state$child_codes, codes))
    )
  }, ignoreInit = TRUE)
  
  observeEvent(input$agate_supervision_set_reference_parent, {
    state <- supervision_draft()
    codes <- selected_reference_codes()
    
    if (length(codes) != 1) {
      showNotification("Selectionne exactement une ligne du referentiel source pour definir le parent.", type = "warning")
      return()
    }
    
    set_supervision_draft(
      parent_code = codes[1],
      child_codes = setdiff(state$child_codes, codes[1])
    )
  }, ignoreInit = TRUE)
  
  observeEvent(input$agate_supervision_remove_selected_children, {
    state <- supervision_draft()
    idx <- input$agate_table_supervision_children_work_rows_selected
    
    if (is.null(state) || length(state$child_codes) == 0) {
      showNotification("Aucun enfant a retirer dans la version supervision.", type = "warning")
      return()
    }
    
    if (is.null(idx) || length(idx) == 0) {
      showNotification("Selectionne un ou plusieurs enfants dans la table avant de les retirer.", type = "warning")
      return()
    }
    
    idx <- idx[!is.na(idx) & idx >= 1 & idx <= length(state$child_codes)]
    if (length(idx) == 0) {
      showNotification("Selection d'enfants invalide.", type = "warning")
      return()
    }
    
    set_supervision_draft(
      parent_code = state$code_ogr_parent,
      child_codes = state$child_codes[-idx]
    )
  }, ignoreInit = TRUE)
  
  observeEvent(input$agate_supervision_reset_from_edition, {
    reset_supervision_draft_from_edition()
    showNotification("Version supervision reinitialisee depuis la version edition.", type = "message", duration = 4)
  }, ignoreInit = TRUE)
  
  observeEvent(input$agate_supervision_clear_recomposition, {
    showModal(modalDialog(
      title = "Recomposition complete",
      tags$p("Cette action vide la version supervision courante : parent et enfants seront remis a zero."),
      tags$p(tags$strong("La version edition reste conservee en lecture seule dans le detail de la proposition.")),
      easyClose = TRUE,
      footer = tagList(
        modalButton("Annuler"),
        actionButton("agate_confirm_supervision_clear_recomposition", "Vider la version supervision", class = "btn-danger")
      )
    ))
  }, ignoreInit = TRUE)
  
  observeEvent(input$agate_confirm_supervision_clear_recomposition, {
    removeModal()
    set_supervision_draft("", character(0))
    showNotification("Version supervision videe. Reconstruis-la depuis le referentiel source.", type = "message", duration = 5)
  }, ignoreInit = TRUE)
  
  output$agate_supervision_current_parent_ui <- renderUI({
    state <- supervision_draft()
    
    if (is.null(state) || !is_filled(state$code_ogr_parent)) {
      return(tags$div(
        class = "supervision-current-parent is-empty",
        tags$strong("Parent supervision : "),
        "aucun parent defini"
      ))
    }
    
    tags$div(
      class = "supervision-current-parent",
      tags$strong("Parent supervision : "),
      paste0(first_non_empty(state$libelle_parent, "Libelle non disponible"), " [", state$code_ogr_parent, "]")
    )
  })
  
  output$agate_table_supervision_children_work <- DT::renderDT({
    state <- supervision_draft()
    
    if (is.null(state) || length(state$child_codes) == 0) {
      empty <- data.frame(
        `Code APET` = character(0),
        `Libelle enfant` = character(0),
        check.names = FALSE
      )
      return(DT::datatable(
        empty,
        rownames = FALSE,
        selection = "multiple",
        class = "compact stripe hover",
        options = agate_dt_options(
          page_length = 10,
          length_menu = list(c(10, 25, 50, 100, -1), c("10", "25", "50", "100", "Tous")),
          scroll_y = "36vh",
          dom = "lfrtip",
          language = list(url = "//cdn.datatables.net/plug-ins/1.13.6/i18n/fr-FR.json")
        )
      ))
    }
    
    children_df <- data.frame(
      `Code APET` = state$child_codes,
      `Libelle enfant` = state$child_labels,
      check.names = FALSE,
      stringsAsFactors = FALSE
    )
    
    DT::datatable(
      children_df,
      rownames = FALSE,
      selection = "multiple",
      class = "compact stripe hover",
      options = agate_dt_options(
        page_length = min(10L, nrow(children_df)),
        length_menu = list(c(10, 25, 50, 100, -1), c("10", "25", "50", "100", "Tous")),
        scroll_y = "36vh",
        dom = "lfrtip",
        language = list(url = "//cdn.datatables.net/plug-ins/1.13.6/i18n/fr-FR.json")
      )
    )
  })
  
  output$agate_supervision_edit_preview <- renderUI({
    state <- supervision_draft()
    
    if (is.null(state)) {
      return(tags$p(class = "supervision-note", "Selectionne une proposition pour preparer une version supervision."))
    }
    
    tags$div(
      class = "supervision-edit-preview",
      tags$div(
        class = "supervision-edit-preview-row",
        tags$span("Parent :"),
        tags$strong(if (is_filled(state$code_ogr_parent)) paste0(first_non_empty(state$libelle_parent, "Libelle non disponible"), " [", state$code_ogr_parent, "]") else "non defini")
      ),
      tags$div(
        class = "supervision-edit-preview-row",
        tags$span("Enfants :"),
        tags$strong(length(state$child_codes))
      )
    )
  })
  
  output$agate_supervision_action_context <- renderUI({
    proposal <- selected_supervision()
    
    if (is.null(proposal)) {
      return(tags$div(
        class = "supervision-status-banner",
        tags$div(class = "supervision-status-kicker", "Selection"),
        tags$div(class = "supervision-status-title", "Choisis une proposition dans une file"),
        tags$div(class = "supervision-status-copy", "L'action disponible s'adaptera automatiquement a l'etat du fichier : prise en charge, decision de supervision ou reprise.")
      ))
    }
    
    status <- proposal$statut_proposition[1]
    owner <- first_non_empty(proposal$idep_agent_supervision[1], "Aucun superviseur")
    
    if (identical(status, "a_superviser")) {
      return(tags$div(
        class = "supervision-status-banner is-queue",
        tags$div(class = "supervision-status-kicker", "Etape 1"),
        tags$div(class = "supervision-status-title", "Proposition en attente de prise en charge"),
        tags$div(class = "supervision-status-copy", paste0("Cette proposition est encore en file d'attente. Prochaine action : la prendre en charge pour ouvrir les decisions supervision."))
      ))
    }
    
    if (identical(status, "en_cours")) {
      return(tags$div(
        class = "supervision-status-banner is-progress",
        tags$div(class = "supervision-status-kicker", "Etape 2"),
        tags$div(class = "supervision-status-title", paste("Dossier ouvert par", owner)),
        tags$div(class = "supervision-status-copy", "Tu peux maintenant valider en l'etat, ajuster la proposition dans le bloc Modification de la proposition, ou rejeter avec commentaire.")
      ))
    }
    
    tags$div(
      class = "supervision-status-banner is-rejected",
      tags$div(class = "supervision-status-kicker", "Etape 3"),
      tags$div(class = "supervision-status-title", "Proposition rejetee"),
      tags$div(class = "supervision-status-copy", "Le rejet reste consultable. Tu peux recreer une reprise d'edition sans perdre la trace du fichier source.")
    )
  })
  server_inline_info <- function(text) {
    tags$span(
      class = "supervision-inline-info",
      tabindex = "0",
      `data-tooltip` = text,
      `aria-label` = text,
      "i"
    )
  }
  
  server_label_with_info <- function(label, info_text) {
    tags$span(
      class = "supervision-label-with-info",
      tags$span(label),
      server_inline_info(info_text)
    )
  }
  
  section_title_with_info <- function(title, info_text) {
    tags$div(
      class = "supervision-section-head",
      tags$div(class = "supervision-section-title", title),
      server_inline_info(info_text)
    )
  }
  output$agate_supervision_action_panel <- renderUI({
    proposal <- selected_supervision()
    
    readonly_field <- function(label, info_text, output_id) {
      div(
        class = "supervision-readonly-field",
        tags$label(
          class = "control-label",
          server_label_with_info(label, info_text)
        ),
        div(
          class = "supervision-readonly-value",
          textOutput(output_id, inline = TRUE)
        )
      )
    }
    
    if (is.null(proposal)) {
      return(tags$p(
        class = "supervision-note",
        "Selectionne une ligne pour faire apparaitre l'action utile."
      ))
    }
    
    status <- proposal$statut_proposition[1]
    
    if (identical(status, "a_superviser")) {
      return(tagList(
        tags$div(
          class = "supervision-action-block is-primary-step",
          tags$div(
            class = "supervision-action-title",
            "Action disponible"
          ),
          tags$div(
            class = "supervision-note",
            "Prends en charge la proposition pour ouvrir les actions de décision supervision."
          ),
          tags$div(
            class = "supervision-actions",
            actionButton(
              "agate_take_in_charge_supervision",
              "Prendre en charge",
              class = "btn-success"
            )
          )
        )
      ))
    }
    
    if (identical(status, "en_cours")) {
      return(tagList(
        tags$div(
          class = "supervision-action-block is-decision-step",
          tags$div(
            class = "supervision-action-title",
            "Decision supervision"
          ),
          readonly_field(
            label = "IDEP supervision",
            info_text = "Cet identifiant est détecté automatiquement et trace le superviseur qui prend en charge ou tranche le dossier.",
            output_id = "agate_supervision_agent_readonly"
          ),
          textAreaInput(
            "agate_supervision_comment",
            server_label_with_info(
              "Commentaire supervision",
              "Utile pour motiver une modification, un rejet ou une consigne transmise a la MOA."
            ),
            rows = 4,
            placeholder = "Motiver la decision, la modification ou le rejet."
          ),
          tags$div(
            class = "supervision-note",
            "Tu peux valider en l'état ou rejeter depuis ce bloc. Si une correction est nécessaire, utilise le bloc Modification de la proposition affiché sous le détail du dossier."
          ),
          tags$div(
            class = "supervision-actions",
            actionButton(
              "agate_validate_supervision_as_is",
              "Envoyer en validation MOA",
              class = "btn-success"
            ),
            actionButton(
              "agate_reject_supervision",
              "Rejeter",
              class = "btn-warning"
            )
          )
        )
      ))
    }
    
    if (identical(status, "rejetes")) {
      return(tagList(
        tags$div(
          class = "supervision-action-block is-reprise-step",
          tags$div(
            class = "supervision-action-title",
            "Reprise edition"
          ),
          readonly_field(
            label = "IDEP reprise edition",
            info_text = "Cet identifiant est détecté automatiquement et sera utilisé si tu recrées une reprise vers l'édition après rejet.",
            output_id = "agate_reprise_idep_agent_readonly"
          ),
          tags$div(
            class = "supervision-note",
            "La reprise recrée une proposition côté édition sans effacer le fichier source rejeté."
          ),
          tags$div(
            class = "supervision-actions",
            actionButton(
              "agate_reintegrate_supervision",
              "Creer une reprise d'edition",
              class = "btn-info"
            )
          )
        )
      ))
    }
    
    tags$p(
      class = "supervision-note",
      "Aucune action disponible pour cet etat de proposition."
    )
  })
  
  output$agate_supervision_edit_state <- renderUI({
    proposal <- selected_supervision()
    
    if (is.null(proposal)) {
      return(tags$div(class = "supervision-edit-help", "Selectionne une proposition pour preparer une version supervision."))
    }
    
    if (identical(proposal$statut_proposition[1], "en_cours")) {
      return(tags$div(class = "supervision-edit-help", "La version edition est prechargee par defaut. Utilise l'ajustement rapide ou la recomposition complete avant l'envoi de la version modifiee vers la validation MOA."))
    }
    
    if (identical(proposal$statut_proposition[1], "a_superviser")) {
      return(tags$div(class = "supervision-edit-help", "La proposition est encore en attente. Prends-la d'abord en charge pour ouvrir le bloc Modification de la proposition."))
    }
    
    tags$div(class = "supervision-edit-help", "Ce fichier est rejete. La modification supervision n'est plus disponible ; la bonne action est de creer une reprise d'edition.")
  })
  
  output$agate_supervision_kpi_panel <- renderUI({
    queue_n <- nrow(supervision_queue())
    in_progress_n <- nrow(supervision_in_progress())
    rejected_n <- nrow(supervision_rejected())
    validation_n <- nrow(validation_pending())
    stock_n <- nrow(stock_families())
    
    oldest_pending_days <- if (queue_n == 0) {
      "0"
    } else {
      pending_times <- suppressWarnings(as.POSIXct(supervision_queue()$horodatage_edition, format = "%Y-%m-%d %H:%M:%S", tz = agate_workflow_tz()))
      pending_times <- pending_times[!is.na(pending_times)]
      if (length(pending_times) == 0) "0" else sprintf("%.1f", as.numeric(difftime(Sys.time(), min(pending_times), units = "days")))
    }
    
    card <- function(label, value, help) {
      tags$div(
        class = "supervision-kpi",
        tags$div(class = "supervision-kpi-label", label),
        tags$div(class = "supervision-kpi-value", value),
        tags$div(class = "supervision-kpi-help", help)
      )
    }
    
    tags$div(
      class = "supervision-kpis",
      card("A superviser", queue_n, "Propositions en attente de prise en charge"),
      card("En cours", in_progress_n, "Propositions ouvertes par les superviseurs"),
      card("Rejetes", rejected_n, "Fichiers a suivre ou a relancer"),
      card("A valider", validation_n, "Propositions parties en validation"),
      card("Stock familles", stock_n, paste("Anciennete max file supervision :", oldest_pending_days, "jours"))
    )
  })
  
  make_supervision_table <- function(df, mode = c("queue", "progress", "rejected")) {
    mode <- match.arg(mode)
    
    revision_counts <- active_family_revision_counts()
    
    df_with_revisions <- df
    if (nrow(df_with_revisions) > 0) {
      df_with_revisions$revision_key <- proposal_family_revision_key(df_with_revisions)
      df_with_revisions <- df_with_revisions %>%
        dplyr::left_join(revision_counts, by = "revision_key")
      df_with_revisions$nb_revisions_actives[is.na(df_with_revisions$nb_revisions_actives)] <- 0L
      df_with_revisions$marqueur_revisions <- ifelse(
        df_with_revisions$nb_revisions_actives > 1,
        paste0("⚠ ", df_with_revisions$nb_revisions_actives, " revisions actives"),
        ifelse(df_with_revisions$nb_revisions_actives == 1, "1 revision active", "")
      )
    } else {
      df_with_revisions$marqueur_revisions <- character(0)
    }
    
    displayed <- df_with_revisions %>%
      transmute(
        `ID proposition` = id_proposition,
        Operation = type_operation,
        `Révisions famille` = marqueur_revisions,
        `IDEP edition` = idep_agent_edition,
        `IDEP supervision` = idep_agent_supervision,
        `Code parent` = code_ogr_parent,
        Parent = libelle_parent,
        `Nb enfants` = nb_enfants,
        `Decision supervision` = decision_supervision,
        `Horodatage edition` = horodatage_edition,
        `Prise en charge supervision` = horodatage_prise_en_charge_supervision,
        `Decision supervision le` = horodatage_decision_supervision
      )
    
    hidden_targets <- switch(
      mode,
      queue = c(4, 8, 10, 11),
      progress = c(8, 11),
      rejected = integer(0)
    )
    column_defs <- if (length(hidden_targets) == 0) {
      list()
    } else {
      list(list(visible = FALSE, targets = hidden_targets))
    }
    
    datatable(
      displayed,
      extensions = "Buttons",
      selection = "single",
      rownames = FALSE,
      options = agate_dt_options(
        page_length = 8,
        scroll_y = "50vh",
        dom = "Bfrtip",
        buttons = TRUE,
        column_defs = column_defs
      )
    ) %>%
      formatStyle(
        "Operation",
        backgroundColor = styleEqual(c("creation", "modification"), c("#eef7ff", "#fff1d6")),
        color = styleEqual(c("creation", "modification"), c("#1f5f8b", "#a75f00")),
        fontWeight = styleEqual(c("creation", "modification"), c("700", "700"))
      ) %>%
      formatStyle(
        "Révisions famille",
        color = DT::styleInterval(0, c("#52627c", "#b45309")),
        fontWeight = "700"
      ) %>%
      formatStyle(
        "Decision supervision",
        backgroundColor = styleEqual(c("valide_en_etat", "modifie_et_valide", "rejete"), c("#e9f7ef", "#eef7ff", "#fff1d6")),
        color = styleEqual(c("valide_en_etat", "modifie_et_valide", "rejete"), c("#1e8449", "#1f5f8b", "#b45f06")),
        fontWeight = styleEqual(c("valide_en_etat", "modifie_et_valide", "rejete"), c("700", "700", "700"))
      )
  }
  
  output$agate_table_supervision_queue <- renderDT({
    make_supervision_table(supervision_queue(), mode = "queue")
  })
  
  output$agate_table_supervision_in_progress <- renderDT({
    make_supervision_table(supervision_in_progress(), mode = "progress")
  })
  
  output$agate_table_supervision_rejected <- renderDT({
    make_supervision_table(supervision_rejected(), mode = "rejected")
  })
  
  output$agate_table_supervision_reference_source <- renderDT({
    build_reference_source_datatable(
      ref_df = ref_agate,
      selection = "multiple",
      page_length = 25L,
      length_menu = c(10, 25, 50, 100),
      scroll_y = "58vh",
      dom = "Blfrtip"
    )
  })
  
  output$agate_supervision_edit_preview <- renderUI({
    draft <- supervision_draft()
    
    if (is.null(draft) || !is_filled(draft$code_ogr_parent)) {
      return(tags$p(class = "supervision-note", "Selectionne une proposition pour precharger la reprise supervision."))
    }
    
    child_df <- child_df_from_vectors(draft$child_codes, draft$child_labels)
    
    tags$div(
      tags$hr(),
      tags$p(tags$strong("Parent retenu : "), paste0(draft$libelle_parent, " [", draft$code_ogr_parent, "]")),
      tags$p(tags$strong("Enfants retenus : "), nrow(child_df))
    )
  })
  
  output$agate_supervision_modification_workspace <- renderUI({
    proposal <- selected_supervision()
    active_tab <- input$agate_supervision_status_tab
    
    if (is.null(proposal) || !identical(active_tab, "En cours") || !identical(proposal$statut_proposition[1], "en_cours")) {
      return(NULL)
    }
    
    mode <- scalar_chr(input$agate_supervision_modification_mode, default = "quick")
    if (!(mode %in% c("quick", "complete"))) {
      mode <- "quick"
    }
    
    mode_help <- if (identical(mode, "quick")) {
      tags$div(
        class = "supervision-mode-help is-quick",
        tags$strong("Ajustement rapide : "),
        "pars de la version edition prechargee, retire les enfants en trop, ajoute les oublis ou change le parent sans reconstruire toute la famille."
      )
    } else {
      tags$div(
        class = "supervision-mode-help is-complete",
        tags$strong("Recomposition complete : "),
        "vide volontairement la version supervision, puis reconstruis le parent et tous les enfants depuis le referentiel source."
      )
    }
    
    complete_mode_actions <- if (identical(mode, "complete")) {
      tags$div(
        class = "supervision-recomposition-actions",
        actionButton(
          "agate_supervision_clear_recomposition",
          "Vider la version supervision",
          class = "btn-danger"
        )
      )
    } else {
      NULL
    }
    
    tags$div(
      class = "supervision-card supervision-modification-card",
      section_title_with_info(
        "Modification de la proposition",
        "Deux voies sont disponibles : ajuster rapidement la version edition prechargee, ou repartir d'une recomposition complete. Les boutons de decision restent dans le panneau de gauche : envoyer en validation MOA en l'etat ou rejeter."
      ),
      tags$div(
        class = "supervision-modification-warning",
        "La version édition reste consultable dans le détail au-dessus. Le bloc ci-dessous prépare uniquement une version supervision modifiée à transmettre à la MOA."
      ),
      tags$div(
        class = "supervision-modification-layout",
        tags$div(
          class = "supervision-modification-side",
          section_title_with_info(
            "Voie de modification",
            "Choisis Ajustement rapide pour corriger quelques éléments, ou Recomposition complète pour reconstruire la famille depuis zéro."
          ),
          radioButtons(
            inputId = "agate_supervision_modification_mode",
            label = NULL,
            choices = c(
              "Ajustement rapide" = "quick",
              "Recomposition complète" = "complete"
            ),
            selected = mode,
            inline = TRUE
          ),
          mode_help,
          tags$hr(),
          section_title_with_info(
            "Version supervision courante",
            "Cette version est celle qui sera envoyée à la MOA si tu utilises le bouton d'envoi de version modifiée."
          ),
          uiOutput("agate_supervision_current_parent_ui"),
          tags$div(
            class = "supervision-children-work-header",
            tags$strong("Enfants supervision"),
            tags$span("Sélectionne une ou plusieurs lignes pour les retirer à la volée.")
          ),
          div(class = "supervision-dt supervision-children-work-dt", DTOutput("agate_table_supervision_children_work")),
          tags$div(
            class = "supervision-modification-actions",
            actionButton(
              "agate_supervision_remove_selected_children",
              "Retirer les enfants sélectionnés",
              class = "btn-warning"
            ),
            actionButton(
              "agate_supervision_reset_from_edition",
              "Réinitialiser depuis la version édition",
              class = "btn-default"
            )
          ),
          complete_mode_actions,
          uiOutput("agate_supervision_edit_preview"),
          tags$div(
            class = "supervision-modification-actions supervision-modification-submit",
            actionButton(
              "agate_validate_supervision_with_changes",
              "Envoyer la version modifiée à la validation MOA",
              class = "btn-primary"
            )
          )
        ),
        tags$div(
          class = "supervision-modification-reference",
          section_title_with_info(
            "Référentiel source",
            "Filtre et sélectionne les lignes utiles, puis utilise les boutons pour définir le parent ou ajouter des enfants à la version supervision."
          ),
          tags$div(
            class = "supervision-reference-actions",
            actionButton(
              "agate_supervision_set_reference_parent",
              "Définir comme parent",
              class = "btn-info"
            ),
            actionButton(
              "agate_supervision_add_reference_children",
              "Ajouter comme enfant(s)",
              class = "btn-success"
            )
          ),
          tags$div(
            class = "supervision-note",
            "La sélection dans ce tableau n'écrase rien automatiquement : elle alimente seulement les actions ci-dessus."
          ),
          div(class = "supervision-dt", DTOutput("agate_table_supervision_reference_source"))
        )
      )
    )
  })
  
  output$agate_supervision_modification_compare <- DT::renderDT({
    compare <- supervision_modification_compare()
    
    if (is.null(compare) || !isTRUE(compare$available)) {
      return(NULL)
    }
    
    make_modification_compare_datatable(compare$child_compare)
  })
  
  proposal_family_view <- function(proposal, version = c("courante", "edition", "supervision")) {
    version <- match.arg(version)
    
    if (is.null(proposal) || nrow(proposal) == 0) {
      return(NULL)
    }
    
    if (identical(version, "edition")) {
      return(list(
        family_title = paste("Version edition -", proposal$id_proposition[1]),
        parent_label = first_non_empty(proposal$libelle_parent_edition[1], proposal$libelle_parent[1]),
        parent_code = first_non_empty(proposal$code_ogr_parent_edition[1], proposal$code_ogr_parent[1]),
        child_labels = split_pipe_values(first_non_empty(proposal$libelles_enfants_edition[1], proposal$libelles_enfants[1])),
        child_codes = split_pipe_values(first_non_empty(proposal$codes_ogr_enfants_edition[1], proposal$codes_ogr_enfants[1]))
      ))
    }
    
    if (identical(version, "supervision")) {
      return(list(
        family_title = paste("Version supervision -", proposal$id_proposition[1]),
        parent_label = first_non_empty(proposal$libelle_parent_supervision[1], proposal$libelle_parent[1]),
        parent_code = first_non_empty(proposal$code_ogr_parent_supervision[1], proposal$code_ogr_parent[1]),
        child_labels = split_pipe_values(first_non_empty(proposal$libelles_enfants_supervision[1], proposal$libelles_enfants[1])),
        child_codes = split_pipe_values(first_non_empty(proposal$codes_ogr_enfants_supervision[1], proposal$codes_ogr_enfants[1]))
      ))
    }
    
    list(
      family_title = paste("Version courante -", proposal$id_proposition[1]),
      parent_label = first_non_empty(proposal$libelle_parent[1], proposal$libelle_parent_edition[1]),
      parent_code = first_non_empty(proposal$code_ogr_parent[1], proposal$code_ogr_parent_edition[1]),
      child_labels = split_pipe_values(first_non_empty(proposal$libelles_enfants[1], proposal$libelles_enfants_edition[1])),
      child_codes = split_pipe_values(first_non_empty(proposal$codes_ogr_enfants[1], proposal$codes_ogr_enfants_edition[1]))
    )
  }
  
  show_supervision_family_graph <- function(family, title = "Graphe de filiation") {
    if (is.null(family)) {
      showNotification("Aucune filiation disponible pour cette proposition.", type = "warning")
      return(invisible(NULL))
    }
    
    if (!has_plotly) {
      showModal(modalDialog(
        title = title,
        p("Le package 'plotly' n'est pas installé sur cette machine."),
        easyClose = TRUE,
        footer = modalButton("Fermer")
      ))
      return(invisible(NULL))
    }
    
    parent_label <- first_non_empty(family$parent_label, "Parent non renseigné")
    parent_code <- first_non_empty(family$parent_code, "")
    child_labels <- family$child_labels
    child_codes <- family$child_codes
    family_title <- first_non_empty(family$family_title, "Filiation")
    
    max_len <- max(length(child_labels), length(child_codes), 0L)
    
    if (max_len == 0) {
      child_labels <- character(0)
      child_codes <- character(0)
    } else {
      length(child_labels) <- max_len
      length(child_codes) <- max_len
      child_labels[is.na(child_labels)] <- ""
      child_codes[is.na(child_codes)] <- ""
    }
    
    output$agate_supervision_family_plot <- plotly::renderPlotly({
      if (length(child_labels) == 0) {
        return(
          plotly::plot_ly() %>%
            plotly::layout(
              title = "Aucun enfant à afficher",
              xaxis = list(visible = FALSE),
              yaxis = list(visible = FALSE),
              paper_bgcolor = "#0f172a",
              plot_bgcolor = "#0f172a",
              font = list(color = "#ffffff")
            )
        )
      }
      
      labels <- c(parent_label, child_labels)
      codes <- c(parent_code, child_codes)
      
      child_palette <- rep_len(
        c("#FF6B6B", "#FFD166", "#06D6A0", "#4D96FF", "#9B5DE5", "#F15BB5", "#00BBF9", "#F9844A"),
        length(child_labels)
      )
      
      node_colors <- c("#2563eb", child_palette)
      link_colors <- hex_to_rgba(child_palette, alpha = 0.38)
      
      custom_text <- c(
        paste0(
          "<b>Parent</b><br>",
          parent_label,
          if (is_filled(parent_code)) paste0("<br>Code APET : ", parent_code) else ""
        ),
        paste0(
          "<b>Enfant</b><br>",
          child_labels,
          ifelse(!is.na(child_codes) & nzchar(child_codes), paste0("<br>Code APET : ", child_codes), "")
        )
      )
      
      node_x <- c(0.10, rep(0.84, length(child_labels)))
      node_y <- c(
        0.5,
        if (length(child_labels) == 1) {
          0.5
        } else {
          seq(0.08, 0.92, length.out = length(child_labels))
        }
      )
      
      plotly::plot_ly(
        type = "sankey",
        arrangement = "fixed",
        node = list(
          pad = 26,
          thickness = 28,
          line = list(color = "#ffffff", width = 1.5),
          label = labels,
          color = node_colors,
          x = node_x,
          y = node_y,
          customdata = custom_text,
          hovertemplate = "%{customdata}<extra></extra>"
        ),
        link = list(
          source = rep(0, length(child_labels)),
          target = seq_along(child_labels),
          value = rep(1, length(child_labels)),
          color = link_colors,
          hovertemplate = paste0(
            "<b>Filiation</b><br>",
            parent_label,
            " → %{target.label}<extra></extra>"
          )
        )
      ) %>%
        plotly::layout(
          title = list(
            text = family_title,
            font = list(size = 18, color = "#ffffff")
          ),
          font = list(family = "Arial", size = 13, color = "#ffffff"),
          paper_bgcolor = "#0f172a",
          plot_bgcolor = "#0f172a",
          margin = list(l = 20, r = 20, t = 90, b = 24),
          annotations = list(
            list(
              x = 0.01,
              y = 1.13,
              xref = "paper",
              yref = "paper",
              text = paste0("Parent : <b>", parent_label, "</b>"),
              showarrow = FALSE,
              align = "left",
              font = list(size = 13, color = "#dbeafe")
            ),
            list(
              x = 0.01,
              y = 1.06,
              xref = "paper",
              yref = "paper",
              text = paste0("Enfants reliés : <b>", length(child_labels), "</b>"),
              showarrow = FALSE,
              align = "left",
              font = list(size = 12, color = "#bfdbfe")
            )
          )
        )
    })
    
    showModal(modalDialog(
      title = title,
      plotly::plotlyOutput("agate_supervision_family_plot", height = "620px"),
      size = "l",
      easyClose = TRUE,
      footer = modalButton("Fermer")
    ))
    
    invisible(NULL)
  }
  observeEvent(input$agate_open_supervision_children_edition, {
    proposal <- selected_supervision()
    
    if (is.null(proposal)) {
      showNotification("Sélectionne une proposition avant d'afficher les enfants.", type = "warning")
      return()
    }
    
    children_df <- child_df_from_vectors(
      split_pipe_values(proposal$codes_ogr_enfants_edition[1]),
      split_pipe_values(proposal$libelles_enfants_edition[1])
    )
    
    show_supervision_children_modal(
      children_df,
      title = "Enfants - version édition"
    )
  }, ignoreInit = TRUE)
  
  observeEvent(input$agate_open_supervision_children_current, {
    proposal <- selected_supervision()
    
    if (is.null(proposal)) {
      showNotification("Sélectionne une proposition avant d'afficher les enfants.", type = "warning")
      return()
    }
    
    children_df <- child_df_from_vectors(
      split_pipe_values(proposal$codes_ogr_enfants[1]),
      split_pipe_values(proposal$libelles_enfants[1])
    )
    
    show_supervision_children_modal(
      children_df,
      title = "Enfants - version courante"
    )
  }, ignoreInit = TRUE)
  # output$agate_supervision_detail <- renderUI({
  #   proposal <- selected_supervision()
  #   
  #   if (is.null(proposal)) {
  #     return(tags$p("Selectionne une proposition dans une des files de supervision."))
  #   }
  #   
  #   current_children <- child_df_from_vectors(
  #     split_pipe_values(proposal$codes_ogr_enfants[1]),
  #     split_pipe_values(proposal$libelles_enfants[1])
  #   )
  #   
  #   edition_children <- child_df_from_vectors(
  #     split_pipe_values(proposal$codes_ogr_enfants_edition[1]),
  #     split_pipe_values(proposal$libelles_enfants_edition[1])
  #   )
  #   
  #   compare <- supervision_modification_compare()
  #   
  #   box <- function(label, value) {
  #     tags$div(
  #       class = "supervision-detail-box",
  #       tags$div(class = "supervision-detail-label", label),
  #       tags$div(class = "supervision-detail-value", ifelse(nzchar(value), value, ""))
  #     )
  #   }
  #   
  #   tagList(
  #     tags$div(
  #       class = "supervision-detail-grid",
  #       box("ID proposition", proposal$id_proposition[1]),
  #       box("Lignee", proposal$id_lignee[1]),
  #       box("Phase courante", paste(proposal$phase_proposition[1], proposal$statut_proposition[1])),
  #       box("Prochaine action", dplyr::case_when(
  #         proposal$statut_proposition[1] == "a_superviser" ~ "Prendre en charge",
  #         proposal$statut_proposition[1] == "en_cours" ~ "Decider puis envoyer MOA ou rejeter",
  #         proposal$statut_proposition[1] == "rejetes" ~ "Creer une reprise",
  #         TRUE ~ ""
  #       )),
  #       box("Operation", proposal$type_operation[1]),
  #       box("Edition", paste(proposal$idep_agent_edition[1], proposal$horodatage_edition[1])),
  #       box("Supervision", paste(first_non_empty(proposal$idep_agent_supervision[1], "Non prise en charge"), first_non_empty(proposal$horodatage_prise_en_charge_supervision[1], ""))),
  #       box("Parent edition", paste0(proposal$libelle_parent_edition[1], " [", proposal$code_ogr_parent_edition[1], "]")),
  #       box("Parent courant", paste0(proposal$libelle_parent[1], " [", proposal$code_ogr_parent[1], "]")),
  #       box("Delta edition", paste("Ajoutes :", first_non_empty(proposal$delta_enfants_ajoutes_edition[1], "Aucun"), "| Retires :", first_non_empty(proposal$delta_enfants_retires_edition[1], "Aucun"))),
  #       box("Enfants edition", if (nrow(edition_children) == 0) "Aucun" else as.character(nrow(edition_children))),
  #       box("Enfants courants", if (nrow(current_children) == 0) "Aucun" else as.character(nrow(current_children))),
  #       box("Decision supervision", first_non_empty(proposal$decision_supervision[1], "Pas encore tranchee")),
  #       box("Commentaire supervision", first_non_empty(proposal$commentaire_supervision[1], "Aucun commentaire")),
  #       box("Source", first_non_empty(proposal$id_proposition_source[1], "Aucune reprise"))
  #     ),
  #     if (!is.null(compare) && isTRUE(compare$is_modification)) {
  #       tagList(
  #         tags$hr(),
  #         tags$h4("Comparatif avant / apres"),
  #         if (!isTRUE(compare$available)) {
  #           tags$p(class = "supervision-note", compare$reason)
  #         } else {
  #           tagList(
  #             tags$p(
  #               class = "supervision-note",
  #               paste("Base stock :", compare$base_family_id)
  #             ),
  #             tags$div(
  #               class = "supervision-detail-grid",
  #               box("Parent avant", compare$parent_before),
  #               box("Parent apres", compare$parent_after),
  #               box("Enfants avant", as.character(compare$before_child_count)),
  #               box("Enfants apres", as.character(compare$after_child_count))
  #             ),
  #             if (nrow(compare$child_compare) == 0) {
  #               tags$p(class = "supervision-note", "Aucun enfant a comparer entre l'avant et l'apres.")
  #             } else {
  #               DT::DTOutput("agate_supervision_modification_compare")
  #             }
  #           )
  #         }
  #       )
  #     }
  #   )
  # })
  
  output$agate_supervision_detail <- renderUI({
    proposal <- selected_supervision()
    
    if (is.null(proposal)) {
      return(tags$p("Selectionne une proposition dans une des files de supervision."))
    }
    
    current_children <- child_df_from_vectors(
      split_pipe_values(proposal$codes_ogr_enfants[1]),
      split_pipe_values(proposal$libelles_enfants[1])
    )
    
    edition_children <- child_df_from_vectors(
      split_pipe_values(proposal$codes_ogr_enfants_edition[1]),
      split_pipe_values(proposal$libelles_enfants_edition[1])
    )
    
    supervision_children <- child_df_from_vectors(
      split_pipe_values(proposal$codes_ogr_enfants_supervision[1]),
      split_pipe_values(proposal$libelles_enfants_supervision[1])
    )
    
    compare <- supervision_modification_compare()
    
    status <- proposal$statut_proposition[1]
    phase <- proposal$phase_proposition[1]
    
    next_action <- dplyr::case_when(
      status == "a_superviser" ~ "Prendre en charge",
      status == "en_cours" ~ "Décider : envoyer en validation MOA, modifier ou rejeter",
      status == "rejetes" ~ "Créer une reprise d'édition",
      TRUE ~ "Aucune action disponible"
    )
    
    same_lineage <- identical(
      first_non_empty(proposal$id_proposition[1], ""),
      first_non_empty(proposal$id_lignee[1], "")
    )
    
    has_supervision_version <- is_filled(first_non_empty(
      proposal$code_ogr_parent_supervision[1],
      proposal$codes_ogr_enfants_supervision[1],
      proposal$decision_supervision[1],
      ""
    ))
    
    is_rejected_supervision <- identical(status, "rejetes") || identical(proposal$decision_supervision[1], "rejete")
    rejection_comment_supervision <- first_non_empty(proposal$commentaire_supervision[1], "Aucun commentaire")
    
    box <- function(label, value, class_extra = "", action_id = NULL) {
      value <- first_non_empty(value, "")
      
      box_content <- tagList(
        tags$div(class = "supervision-detail-label", label),
        tags$div(class = "supervision-detail-value", ifelse(nzchar(value), value, "—"))
      )
      
      if (is.null(action_id)) {
        return(tags$div(
          class = paste("supervision-detail-box", class_extra),
          box_content
        ))
      }
      
      actionButton(
        inputId = action_id,
        label = box_content,
        class = paste(
          "supervision-detail-box",
          "supervision-detail-clickable",
          "supervision-detail-action",
          class_extra
        )
      )
    }
    
    section <- function(title, subtitle = NULL, ..., class_extra = "") {
      tags$div(
        class = paste("supervision-detail-section", class_extra),
        tags$div(
          class = "supervision-detail-section-head",
          tags$div(class = "supervision-detail-section-title", title),
          if (!is.null(subtitle)) {
            tags$div(class = "supervision-detail-section-subtitle", subtitle)
          }
        ),
        tags$div(
          class = "supervision-detail-grid",
          ...
        )
      )
    }
    
    tagList(
      if (isTRUE(is_rejected_supervision)) {
        tags$div(
          class = "alert alert-warning",
          tags$strong("Commentaire de rejet supervision : "),
          rejection_comment_supervision
        )
      },
      section(
        title = "Synthèse dossier",
        subtitle = "Identifiants et état courant du fichier dans le workflow.",
        box("ID proposition", proposal$id_proposition[1], "is-identity"),
        if (!same_lineage) {
          box("Lignée", proposal$id_lignee[1], "is-identity")
        } else {
          box("Lignée", "Même identifiant que la proposition initiale", "is-muted")
        },
        box("Phase / statut", paste(phase, status), "is-status"),
        box("Prochaine action", next_action, "is-status")
      ),
      
      section(
        title = "Version édition",
        subtitle = "Contenu proposé par l'édition avant arbitrage supervision.",
        box(
          "Édition",
          paste(proposal$idep_agent_edition[1], proposal$horodatage_edition[1]),
          "is-edition"
        ),
        box(
          "Opération",
          proposal$type_operation[1],
          "is-edition"
        ),
        box(
          "Parent édition",
          paste0(proposal$libelle_parent_edition[1], " [", proposal$code_ogr_parent_edition[1], "]"),
          "is-edition"
        ),
        box(
          "Enfants édition",
          if (nrow(edition_children) == 0) "Aucun" else paste(nrow(edition_children), "enfant(s)"),
          "is-edition",
          action_id = "agate_open_supervision_children_edition"
        ),
        box(
          "Delta édition",
          paste(
            "Ajoutés :",
            first_non_empty(proposal$delta_enfants_ajoutes_edition[1], "Aucun"),
            "| Retirés :",
            first_non_empty(proposal$delta_enfants_retires_edition[1], "Aucun")
          ),
          "is-edition-wide"
        ),
        box(
          "Voir graphe édition",
          "Cliquer pour visualiser la filiation proposée par l'édition",
          "is-graph",
          action_id = "agate_open_supervision_graph_edition"
        )
      ),
      
      section(
        title = "Version courante",
        subtitle = "Version actuellement portée par le fichier après éventuel arbitrage supervision.",
        box(
          "Parent courant",
          paste0(proposal$libelle_parent[1], " [", proposal$code_ogr_parent[1], "]"),
          "is-current"
        ),
        box(
          "Enfants courants",
          if (nrow(current_children) == 0) "Aucun" else paste(nrow(current_children), "enfant(s)"),
          "is-current",
          action_id = "agate_open_supervision_children_current"
        ),
        box(
          "Voir graphe courant",
          "Cliquer pour visualiser la filiation courante",
          "is-graph",
          action_id = "agate_open_supervision_graph_current"
        )
      ),
      
      section(
        title = "Supervision",
        subtitle = "Traçabilité de la prise en charge et de la décision supervision.",
        box(
          "Prise en charge",
          paste(
            first_non_empty(proposal$idep_agent_supervision[1], "Non prise en charge"),
            first_non_empty(proposal$horodatage_prise_en_charge_supervision[1], "")
          ),
          "is-supervision"
        ),
        box(
          "Décision supervision",
          first_non_empty(proposal$decision_supervision[1], "Pas encore tranchée"),
          "is-supervision"
        ),
        box(
          "Commentaire supervision",
          first_non_empty(proposal$commentaire_supervision[1], "Aucun commentaire"),
          "is-supervision-wide"
        ),
        if (isTRUE(has_supervision_version)) {
          box(
            "Voir graphe supervision",
            "Cliquer pour visualiser la version arbitrée par la supervision",
            "is-graph",
            action_id = "agate_open_supervision_graph_supervision"
          )
        }
      ),
      
      section(
        title = "Traçabilité",
        subtitle = "Origine du fichier et lien éventuel avec une reprise.",
        box(
          "Source",
          first_non_empty(proposal$id_proposition_source[1], "Aucune reprise"),
          "is-muted"
        ),
        box(
          "Fichier",
          first_non_empty(proposal$fichier_stockage[1], "Non renseigné"),
          "is-muted"
        )
      ),
      
      if (!is.null(compare) && isTRUE(compare$is_modification)) {
        tagList(
          tags$hr(),
          tags$div(
            class = "supervision-detail-section",
            tags$div(
              class = "supervision-detail-section-head",
              tags$div(class = "supervision-detail-section-title", "Comparatif avant / après"),
              tags$div(class = "supervision-detail-section-subtitle", "Comparaison avec la famille stock de base.")
            ),
            if (!isTRUE(compare$available)) {
              tags$p(class = "supervision-note", compare$reason)
            } else {
              tagList(
                tags$p(
                  class = "supervision-note",
                  paste("Base stock :", compare$base_family_id)
                ),
                tags$div(
                  class = "supervision-detail-grid",
                  box("Parent avant", compare$parent_before, "is-before"),
                  box("Parent après", compare$parent_after, "is-after"),
                  box("Enfants avant", as.character(compare$before_child_count), "is-before"),
                  box("Enfants après", as.character(compare$after_child_count), "is-after")
                ),
                if (nrow(compare$child_compare) == 0) {
                  tags$p(class = "supervision-note", "Aucun enfant à comparer entre l'avant et l'après.")
                } else {
                  DT::DTOutput("agate_supervision_modification_compare")
                }
              )
            }
          )
        )
      }
    )
  })
  
  observeEvent(input$agate_open_supervision_graph_current, {
    proposal <- selected_supervision()
    
    if (is.null(proposal)) {
      showNotification("Sélectionne une proposition avant d'afficher le graphe.", type = "warning")
      return()
    }
    
    show_supervision_family_graph(
      proposal_family_view(proposal, version = "courante"),
      title = "Graphe de filiation - version courante"
    )
  }, ignoreInit = TRUE)
  
  observeEvent(input$agate_open_supervision_graph_edition, {
    proposal <- selected_supervision()
    
    if (is.null(proposal)) {
      showNotification("Sélectionne une proposition avant d'afficher le graphe.", type = "warning")
      return()
    }
    
    show_supervision_family_graph(
      proposal_family_view(proposal, version = "edition"),
      title = "Graphe de filiation - version édition"
    )
  }, ignoreInit = TRUE)  
  
  observeEvent(input$agate_open_supervision_graph_supervision, {
    proposal <- selected_supervision()
    
    if (is.null(proposal)) {
      showNotification("Sélectionne une proposition avant d'afficher le graphe.", type = "warning")
      return()
    }
    
    show_supervision_family_graph(
      proposal_family_view(proposal, version = "supervision"),
      title = "Graphe de filiation - version supervision"
    )
  })
  
  observeEvent(input$agate_take_in_charge_supervision, {
    proposal <- selected_supervision()
    
    if (is.null(proposal)) {
      showNotification("Selectionne une proposition a prendre en charge.", type = "warning")
      return()
    }
    
    if (!identical(proposal$statut_proposition[1], "a_superviser")) {
      showNotification("La prise en charge ne s'applique qu'aux propositions a superviser.", type = "warning")
      return()
    }
    
    agent_supervision <- supervision_agent_value()
    
    if (!is_filled(agent_supervision)) {
      showNotification("IDEP supervision non détecté. Impossible de tracer la prise en charge.", type = "warning")
      return()
    }
    
    ok <- run_supervision_transition(
      action_fun = function() take_in_charge_supervision(proposal, agent_supervision),
      failure_prefix = "Prise en charge supervision impossible :"
    )
    
    if (!isTRUE(ok)) {
      return()
    }
    
    updateTabsetPanel(session, "agate_supervision_status_tab", selected = "En cours")
    showNotification("Proposition prise en charge. Les decisions supervision sont maintenant ouvertes.", type = "message", duration = 5)
  })
  
  observeEvent(input$agate_validate_supervision_as_is, {
    proposal <- selected_supervision()
    
    if (is.null(proposal) || !identical(proposal$statut_proposition[1], "en_cours")) {
      showNotification("Prends d'abord en charge une proposition avant de la valider.", type = "warning")
      return()
    }
    
    agent_supervision <- supervision_agent_value()
    
    if (!is_filled(agent_supervision)) {
      showNotification("IDEP supervision non détecté. Impossible de tracer la décision.", type = "warning")
      return()
    }
    
    workflow_checks <- build_family_conflict_checks(
      draft = proposal_row_to_draft(proposal),
      stock_families = stock_families(),
      workflow_proposals = workflow_active_proposals(),
      current_proposal = proposal
    )
    
    if (has_blocking_family_conflicts(workflow_checks)) {
      show_family_conflict_modal(
        title = "Doublon ou chevauchement detecte",
        checks = workflow_checks,
        closing_copy = "Corrigez la proposition avant de l'envoyer en validation MOA."
      )
      return()
    }
    
    ok <- run_supervision_transition(
      action_fun = function() {
        save_supervision_decision(
          proposal_row = proposal,
          idep_agent_supervision = agent_supervision,
          commentaire_supervision = input$agate_supervision_comment,
          decision = "valide_en_etat",
          ref_df = ref_agate
        )
      },
      failure_prefix = "Envoi vers validation impossible :"
    )
    if (!isTRUE(ok)) {
      return()
    }
    
    removeModal()
    updateTabsetPanel(session, "agate_supervision_status_tab", selected = "A superviser")
    showNotification("Proposition envoyee a la validation MOA en l'etat.", type = "message", duration = 6)
  })
  
  observeEvent(input$agate_validate_supervision_with_changes, {
    proposal <- selected_supervision()
    draft <- supervision_draft()
    agent_supervision <- supervision_agent_value()
    
    if (is.null(proposal) || !identical(proposal$statut_proposition[1], "en_cours")) {
      showNotification("Prends d'abord en charge une proposition avant de la modifier.", type = "warning")
      return()
    }
    
    if (!is_filled(agent_supervision)) {
      showNotification("IDEP supervision non détecté. Impossible de tracer la décision.", type = "warning")
      return()
    }
    
    if (is.null(draft) || !is_filled(draft$code_ogr_parent) || length(draft$child_codes) == 0) {
      showNotification("Definis un parent et au moins un enfant pour la version supervision.", type = "warning")
      showModal(modalDialog(
        title = "Version supervision incomplete",
        tags$p("Definis un parent et au moins un enfant avant d'envoyer la version modifiee a la validation MOA."),
        easyClose = TRUE,
        footer = modalButton("Fermer")
      ))
      return()
    }
    
    workflow_checks <- build_family_conflict_checks(
      draft = draft,
      stock_families = stock_families(),
      workflow_proposals = workflow_active_proposals(),
      current_proposal = proposal
    )
    
    if (has_blocking_family_conflicts(workflow_checks)) {
      show_family_conflict_modal(
        title = "Doublon ou chevauchement detecte",
        checks = workflow_checks,
        closing_copy = "Corrigez la version supervision avant de l'envoyer en validation MOA."
      )
      return()
    }
    
    ok <- run_supervision_transition(
      action_fun = function() {
        save_supervision_decision(
          proposal_row = proposal,
          idep_agent_supervision = agent_supervision,
          commentaire_supervision = input$agate_supervision_comment,
          decision = "modifie_et_valide",
          parent_code = draft$code_ogr_parent,
          child_codes = draft$child_codes,
          ref_df = ref_agate
        )
      },
      failure_prefix = "Modification supervision impossible :"
    )
    
    if (!isTRUE(ok)) {
      return()
    }
    
    removeModal()
    updateTabsetPanel(session, "agate_supervision_status_tab", selected = "A superviser")
    showNotification("Version supervision modifiee envoyee a la validation MOA.", type = "message", duration = 6)
  })
  
  
  observeEvent(input$agate_reject_supervision, {
    proposal <- selected_supervision()
    agent_supervision <- supervision_agent_value()
    
    if (is.null(proposal) || !identical(proposal$statut_proposition[1], "en_cours")) {
      showNotification("Prends d'abord en charge une proposition avant de la rejeter.", type = "warning")
      return()
    }
    
    if (!is_filled(agent_supervision)) {
      showNotification("IDEP supervision non détecté. Impossible de tracer le rejet.", type = "warning")
      return()
    }
    
    ok <- run_supervision_transition(
      action_fun = function() {
        save_supervision_decision(
          proposal_row = proposal,
          idep_agent_supervision = agent_supervision,
          commentaire_supervision = input$agate_supervision_comment,
          decision = "rejete",
          ref_df = ref_agate
        )
      },
      failure_prefix = "Rejet supervision impossible :"
    )
    
    if (!isTRUE(ok)) {
      return()
    }
    
    removeModal()
    updateTabsetPanel(session, "agate_supervision_status_tab", selected = "Rejetes")
    showNotification("Proposition rejetee et deplacee dans les rejets supervision.", type = "message", duration = 6)
  })
  
  observeEvent(input$agate_reintegrate_supervision, {
    proposal <- selected_supervision()
    
    if (is.null(proposal) || !identical(proposal$statut_proposition[1], "rejetes")) {
      showNotification("Selectionne un rejet supervision pour creer une reprise.", type = "warning")
      return()
    }
    
    reprise_idep <- reprise_idep_agent_value()
    if (!is_filled(reprise_idep)) {
      showNotification("IDEP de reprise non détecté.", type = "warning")
      return()
    }
    
    ok <- run_supervision_transition(
      action_fun = function() {
        reintegrate_rejected_proposal(
          proposal_row = proposal,
          idep_agent_edition = reprise_idep
        )
      },
      failure_prefix = "Creation de la reprise impossible :"
    )
    if (!isTRUE(ok)) {
      return()
    }
    
    updateTabsetPanel(session, "agate_supervision_status_tab", selected = "A superviser")
    showNotification("Une nouvelle reprise d'edition a ete creee et remise dans la file de supervision.", type = "message", duration = 6)
  })
}
