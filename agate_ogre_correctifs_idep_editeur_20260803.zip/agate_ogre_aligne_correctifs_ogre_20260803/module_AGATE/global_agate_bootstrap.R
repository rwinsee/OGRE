source_agate_workflow <- function(env = parent.frame()) {
  source(
    "modules/module_AGATE/edition/global_agate_workflow.R",
    encoding = "UTF-8",
    local = env
  )
  invisible(TRUE)
}

source_agate_stock_valides <- function(env = parent.frame()) {
  source(
    "modules/module_AGATE/stock_valides/ui_stock_valides.R",
    encoding = "UTF-8",
    local = env
  )
  source(
    "modules/module_AGATE/stock_valides/server_stock_valides.R",
    encoding = "UTF-8",
    local = env
  )
  invisible(TRUE)
}

source_agate_modules <- function(env = parent.frame()) {
  # Charge AGATE dans un environnement prive afin de ne pas ecraser les
  # helpers generiques d'OGRE lorsque les deux modules cohabitent.
  module_env <- new.env(parent = env)
  source_agate_workflow(env = module_env)
  
  source(
    "modules/module_AGATE/edition/ui_edition.R",
    encoding = "UTF-8",
    local = module_env
  )
  source(
    "modules/module_AGATE/edition/server_edition.R",
    encoding = "UTF-8",
    local = module_env
  )
  source(
    "modules/module_AGATE/supervision/ui_supervision.R",
    encoding = "UTF-8",
    local = module_env
  )
  source(
    "modules/module_AGATE/supervision/server_supervision.R",
    encoding = "UTF-8",
    local = module_env
  )
  source(
    "modules/module_AGATE/validation/ui_validation.R",
    encoding = "UTF-8",
    local = module_env
  )
  source(
    "modules/module_AGATE/validation/server_validation.R",
    encoding = "UTF-8",
    local = module_env
  )
  source_agate_stock_valides(env = module_env)
  
  exported_functions <- c(
    "agate_edition_ui",
    "agate_edition_server",
    "agate_supervision_ui",
    "agate_supervision_server",
    "agate_validation_ui",
    "agate_validation_server",
    "agate_stock_valides_ui",
    "agate_stock_valides_server"
  )
  
  missing_exports <- exported_functions[!vapply(
    exported_functions,
    exists,
    logical(1),
    envir = module_env,
    inherits = FALSE
  )]
  
  if (length(missing_exports) > 0L) {
    stop(
      paste("Fonctions AGATE non chargees :", paste(missing_exports, collapse = ", ")),
      call. = FALSE
    )
  }
  
  for (name in exported_functions) {
    assign(name, get(name, envir = module_env, inherits = FALSE), envir = env)
  }
  
  invisible(TRUE)
}
