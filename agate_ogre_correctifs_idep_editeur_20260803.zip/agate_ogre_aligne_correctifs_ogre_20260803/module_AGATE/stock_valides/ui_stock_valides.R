agate_stock_valides_ui <- function() {
  inline_info <- function(text) {
    tags$span(
      class = "agate-info-dot",
      `data-toggle` = "tooltip",
      `data-bs-toggle` = "tooltip",
      title = text,
      "?"
    )
  }
  
  label_with_info <- function(label, info_text) {
    tags$span(label, inline_info(info_text))
  }
  
  section_title_with_info <- function(title, info_text) {
    tags$div(
      class = "stock-valides-section-title",
      tags$span(title),
      inline_info(info_text)
    )
  }
  
  tagList(
    tags$style(HTML("
body.theme-dark div.dt-button-collection,
.theme-dark div.dt-button-collection {
  background: #111827 !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  box-shadow: 0 18px 45px rgba(0, 0, 0, 0.45) !important;
  padding: 6px !important;
}

body.theme-dark div.dt-button-collection button.dt-button,
body.theme-dark div.dt-button-collection a.dt-button,
.theme-dark div.dt-button-collection button.dt-button,
.theme-dark div.dt-button-collection a.dt-button {
  background: transparent !important;
  color: #e5e7eb !important;
  border: 0 !important;
  box-shadow: none !important;
  text-align: left !important;
  padding: 8px 14px !important;
  width: 100% !important;
}

body.theme-dark div.dt-button-collection button.dt-button:hover,
body.theme-dark div.dt-button-collection a.dt-button:hover,
.theme-dark div.dt-button-collection button.dt-button:hover,
.theme-dark div.dt-button-collection a.dt-button:hover {
  background: #1f2937 !important;
  color: #ffffff !important;
}

body.theme-dark div.dt-button-collection button.dt-button.active,
body.theme-dark div.dt-button-collection a.dt-button.active,
.theme-dark div.dt-button-collection button.dt-button.active,
.theme-dark div.dt-button-collection a.dt-button.active {
  background: #172554 !important;
  color: #ffffff !important;
}

body.theme-dark div.dt-button-collection button.dt-button.active:after,
body.theme-dark div.dt-button-collection a.dt-button.active:after,
.theme-dark div.dt-button-collection button.dt-button.active:after,
.theme-dark div.dt-button-collection a.dt-button.active:after {
  color: #93c5fd !important;
}

body.theme-dark div.dt-button-background,
.theme-dark div.dt-button-background {
  background: rgba(2, 6, 23, 0.45) !important;
}
")),
    tags$style(HTML("
      /* ============================================================
         module familles validées agate
         la classe racine agate-stock-valides-page limite le css au module
         ============================================================ */

      .agate-stock-valides-page {
        padding: 8px 0 24px 0;
        color: #0f172a;
      }

      .agate-stock-valides-page .agate-info-dot {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 16px;
        height: 16px;
        margin-left: 6px;
        border-radius: 50%;
        background: #eef2ff;
        color: #3730a3;
        font-size: 11px;
        font-weight: 700;
        cursor: help;
        vertical-align: middle;
      }

      .agate-stock-valides-page .stock-valides-hero {
        margin-bottom: 14px;
        padding: 16px 18px;
        border: 1px solid #dbeafe;
        border-radius: 14px;
        background: linear-gradient(135deg, #f8fbff 0%, #eef6ff 100%);
      }

      .agate-stock-valides-page .stock-valides-hero h3 {
        margin-top: 0;
        margin-bottom: 6px;
        font-weight: 700;
        color: #172554;
      }

      .agate-stock-valides-page .stock-valides-hero p {
        margin-bottom: 0;
        color: #334155;
      }

      .agate-stock-valides-page .stock-valides-toolbar {
        display: flex;
        align-items: end;
        gap: 10px;
        flex-wrap: wrap;
        margin-bottom: 12px;
      }

      .agate-stock-valides-page .stock-valides-toolbar .form-group {
        margin-bottom: 0;
      }

      .agate-stock-valides-page .stock-valides-card {
        margin-bottom: 14px;
        padding: 14px;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
        background: #ffffff;
        box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);
      }

      .agate-stock-valides-page .stock-valides-card-muted {
        background: #f8fafc;
      }

      .agate-stock-valides-page .stock-valides-section-title {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
        font-size: 16px;
        font-weight: 700;
        color: #0f172a;
      }

      .agate-stock-valides-page .stock-valides-help {
        margin-top: 6px;
        color: #64748b;
        font-size: 13px;
      }

      .agate-stock-valides-page .stock-valides-kpis {
        display: grid;
        grid-template-columns: repeat(4, minmax(120px, 1fr));
        gap: 10px;
        margin-bottom: 14px;
      }

      .agate-stock-valides-page .stock-valides-kpi {
        padding: 12px;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        background: #ffffff;
      }

      .agate-stock-valides-page .stock-valides-kpi .label {
        display: block;
        color: #64748b;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: .02em;
        background: transparent;
        padding: 0;
      }

      .agate-stock-valides-page .stock-valides-kpi .value {
        display: block;
        margin-top: 3px;
        color: #0f172a;
        font-size: 23px;
        font-weight: 800;
      }

      .agate-stock-valides-page .stock-valides-detail-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
        margin-bottom: 12px;
      }

      .agate-stock-valides-page .stock-valides-detail-box {
        padding: 10px 12px;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        background: #f8fafc;
      }

      .agate-stock-valides-page .stock-valides-detail-box .label {
        display: block;
        color: #64748b;
        font-size: 12px;
        font-weight: 700;
        background: transparent;
        padding: 0;
      }

      .agate-stock-valides-page .stock-valides-detail-box .value {
        display: block;
        margin-top: 4px;
        color: #111827;
        font-weight: 600;
        word-break: break-word;
      }

      .agate-stock-valides-page .stock-valides-warning {
        padding: 12px;
        border-left: 4px solid #f59e0b;
        border-radius: 8px;
        background: #fffbeb;
        color: #78350f;
      }

      .agate-stock-valides-page .stock-valides-success {
        padding: 12px;
        border-left: 4px solid #22c55e;
        border-radius: 8px;
        background: #f0fdf4;
        color: #14532d;
      }

      .agate-stock-valides-page .stock-valides-danger {
        padding: 12px;
        border-left: 4px solid #ef4444;
        border-radius: 8px;
        background: #fef2f2;
        color: #7f1d1d;
      }

      .agate-stock-valides-page .stock-valides-actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        margin-top: 10px;
      }

      .agate-stock-valides-page .stock-valides-dt .dataTables_wrapper {
        width: 100%;
      }

      /* ============================================================
         mode sombre
         on cible .theme-dark pour fonctionner si la classe est sur html ou body
         ============================================================ */

      .theme-dark .agate-stock-valides-page {
        color: #e5e7eb;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-hero {
        background: linear-gradient(135deg, #0f172a 0%, #172554 100%);
        border-color: #1d4ed8;
        color: #dbeafe;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-hero h3 {
        color: #eff6ff;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-hero p {
        color: #bfdbfe;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-card,
      .theme-dark .agate-stock-valides-page .tab-content {
        background: #1f2937;
        border-color: #374151;
        color: #e5e7eb;
        box-shadow: none;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-card-muted {
        background: #111827;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-section-title {
        color: #f9fafb;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-help {
        color: #cbd5e1;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-kpi {
        background: #111827;
        border-color: #374151;
        color: #e5e7eb;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-kpi .label {
        color: #cbd5e1;
        background: transparent;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-kpi .value {
        color: #f9fafb;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-detail-box {
        background: #111827;
        border-color: #374151;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-detail-box .label {
        color: #cbd5e1;
        background: transparent;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-detail-box .value {
        color: #f9fafb;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-warning {
        background: #422006;
        border-color: #f59e0b;
        color: #fde68a;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-success {
        background: #052e16;
        border-color: #22c55e;
        color: #bbf7d0;
      }

      .theme-dark .agate-stock-valides-page .stock-valides-danger {
        background: #450a0a;
        border-color: #ef4444;
        color: #fecaca;
      }

      .theme-dark .agate-stock-valides-page .agate-info-dot {
        background: #1e3a8a;
        color: #dbeafe;
      }

      .theme-dark .agate-stock-valides-page input,
      .theme-dark .agate-stock-valides-page select,
      .theme-dark .agate-stock-valides-page textarea,
      .theme-dark .agate-stock-valides-page .form-control {
        background: #111827;
        color: #e5e7eb;
        border-color: #4b5563;
      }

      .theme-dark .agate-stock-valides-page input::placeholder,
      .theme-dark .agate-stock-valides-page textarea::placeholder {
        color: #94a3b8;
      }

      .theme-dark .agate-stock-valides-page .nav-tabs {
        border-bottom-color: #374151;
      }

      .theme-dark .agate-stock-valides-page .nav-tabs > li > a {
        background: #111827;
        color: #e5e7eb;
        border-color: #374151;
      }

      .theme-dark .agate-stock-valides-page .nav-tabs > li > a:hover,
      .theme-dark .agate-stock-valides-page .nav-tabs > li > a:focus {
        background: #1f2937;
        color: #f9fafb;
        border-color: #4b5563;
      }

      .theme-dark .agate-stock-valides-page .nav-tabs > li.active > a,
      .theme-dark .agate-stock-valides-page .nav-tabs > li.active > a:hover,
      .theme-dark .agate-stock-valides-page .nav-tabs > li.active > a:focus {
        background: #14532d;
        color: #dcfce7;
        border-color: #22c55e;
      }

      .theme-dark .agate-stock-valides-page .dataTables_wrapper,
      .theme-dark .agate-stock-valides-page .dataTables_length,
      .theme-dark .agate-stock-valides-page .dataTables_filter,
      .theme-dark .agate-stock-valides-page .dataTables_info,
      .theme-dark .agate-stock-valides-page .dataTables_paginate {
        color: #e5e7eb !important;
      }

      .theme-dark .agate-stock-valides-page .dataTables_filter input,
      .theme-dark .agate-stock-valides-page .dataTables_length select {
        background: #111827;
        color: #e5e7eb;
        border: 1px solid #4b5563;
      }

      .theme-dark .agate-stock-valides-page table.dataTable {
        background: #111827;
        color: #e5e7eb;
        border-color: #374151;
      }

      .theme-dark .agate-stock-valides-page table.dataTable thead th,
      .theme-dark .agate-stock-valides-page table.dataTable thead td {
        background: #1f2937;
        color: #f9fafb;
        border-color: #374151;
      }

      .theme-dark .agate-stock-valides-page table.dataTable tbody th,
      .theme-dark .agate-stock-valides-page table.dataTable tbody td {
        background: #111827;
        color: #e5e7eb;
        border-color: #374151;
      }

      .theme-dark .agate-stock-valides-page table.dataTable tbody tr:hover td {
        background: #1f2937;
      }

      .theme-dark .agate-stock-valides-page table.dataTable.no-footer {
        border-bottom-color: #374151;
      }

      .theme-dark .agate-stock-valides-page .paginate_button {
        color: #e5e7eb !important;
      }

      .theme-dark .agate-stock-valides-page .paginate_button.disabled {
        color: #64748b !important;
      }

      @media (max-width: 992px) {
        .agate-stock-valides-page .stock-valides-kpis,
        .agate-stock-valides-page .stock-valides-detail-grid {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }
      }

      @media (max-width: 640px) {
        .agate-stock-valides-page .stock-valides-kpis,
        .agate-stock-valides-page .stock-valides-detail-grid {
          grid-template-columns: 1fr;
        }
      }
    ")),
    
    tags$script(HTML("
      $(document).on('shiny:value shiny:bound', function() {
        if ($.fn.tooltip) { $('[data-toggle=tooltip]').tooltip({container: 'body'}); }
        if (window.bootstrap && bootstrap.Tooltip) {
          document.querySelectorAll('[data-bs-toggle=tooltip]').forEach(function(el) {
            if (!bootstrap.Tooltip.getInstance(el)) new bootstrap.Tooltip(el);
          });
        }
      });
    ")),
    
    div(
      class = "agate-stock-valides-page agate-stock-valides-module",
      
      div(
        class = "stock-valides-hero",
        h3("Familles validées AGATE"),
        p("Sélectionnez une famille, consultez son détail, puis utilisez Remettre en jeu uniquement si elle doit évoluer. Les vues graphiques et consolidées sont facultatives.")
      ),
      
      tags$details(
        class = "stock-valides-card stock-valides-card-muted",
        tags$summary("Voir les indicateurs du stock"),
        uiOutput("agate_stock_valides_kpi_panel")
      ),
      
      div(
        class = "stock-valides-toolbar",
        textInput(
          "agate_stock_valides_search",
          label_with_info(
            "Recherche",
            "Filtre local sur le parent, les enfants, les codes APET, les codes A88 et l'identifiant de famille"
          ),
          value = "",
          placeholder = "parent, enfant, code APET, code A88, id famille"
        ),
        actionButton("agate_stock_valides_refresh", "Rafraîchir", icon = icon("rotate-right")),
        actionButton("agate_stock_valides_reset", "Réinitialiser la sélection", icon = icon("eraser")),
        actionButton("agate_stock_valides_rejouer", "Remettre en jeu", icon = icon("redo"), class = "btn-warning")
      ),
      
      tabsetPanel(
        id = "agate_stock_valides_tabs",
        
        tabPanel(
          title = "1. Choisir une famille",
          value = "Familles validées",
          br(),
          div(
            class = "stock-valides-card",
            section_title_with_info(
              "Familles validées publiées",
              "Chaque ligne correspond à une famille AGATE validée et publiée"
            ),
            div(class = "stock-valides-dt", DT::DTOutput("agate_table_stock_valides")),
            div(class = "stock-valides-help", "Sélectionner une ligne pour afficher le détail, la filiation graphique et les activités APET rattachées.")
          ),
          uiOutput("agate_stock_valides_selected_notice"),
          uiOutput("agate_stock_valides_family_detail"),
          div(
            class = "stock-valides-card",
            section_title_with_info(
              "Détail DT de la famille sélectionnée",
              "Détail DT du parent et des enfants, enrichi avec les informations du référentiel AGATE lorsqu'elles sont disponibles"
            ),
            div(class = "stock-valides-dt", DT::DTOutput("agate_table_stock_valides_children"))
          )
        ),
        
        tabPanel(
          title = "2. Voir la filiation",
          value = "Filiation graphique",
          br(),
          div(
            class = "stock-valides-card stock-valides-card-muted",
            section_title_with_info(
              "Filiation graphique",
              "Le parent est relié à chaque activité APET enfant de la famille validée sélectionnée"
            ),
            uiOutput("agate_stock_valides_graph_container")
          )
        ),
        
        tabPanel(
          title = "Vue consolidée APET",
          value = "Appellations principales",
          br(),
          div(
            class = "stock-valides-card",
            section_title_with_info(
              "Activités APET parentes publiées",
              "Vue consolidée par activité parente pour contrôler rapidement les familles validées"
            ),
            div(class = "stock-valides-dt", DT::DTOutput("agate_table_stock_valides_appellations")),
            div(class = "stock-valides-help", "Sélectionner une activité parente pour afficher son détail ci-dessous.")
          ),
          div(
            class = "stock-valides-card",
            section_title_with_info(
              "Détail de l'activité parente sélectionnée",
              "Affiche le parent et tous ses enfants avec les informations du référentiel APET"
            ),
            div(class = "stock-valides-dt", DT::DTOutput("agate_table_stock_valides_appellation_detail"))
          )
        ),
        
        tabPanel(
          title = "3. Remettre en jeu",
          value = "Remise en jeu",
          br(),
          div(
            class = "stock-valides-card",
            section_title_with_info(
              "Remettre en jeu une famille validée",
              "La famille sélectionnée est recopiée dans la file de supervision comme proposition de modification, sans supprimer la famille publiée"
            ),
            uiOutput("agate_stock_valides_rejeu_panel")
          )
        )
      )
    )
  )
}
