source_agate_workflow <- function(env = parent.frame()) {
  source(
    "modules/module_AGATE/edition/global_agate_workflow.R",
    encoding = "UTF-8",
    local = env
  )
  invisible(TRUE)
}