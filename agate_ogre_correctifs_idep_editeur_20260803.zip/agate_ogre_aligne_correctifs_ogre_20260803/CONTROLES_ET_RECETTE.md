# Contrôles effectués et recette conseillée

## Contrôles effectués sur la livraison

- analyse syntaxique de tous les scripts R actifs AGATE et OGRE : **20 fichiers analysés, 0 erreur** ;
- vérification des liaisons UI/serveur : aucun composant UI actif sans observateur ou sortie serveur ;
- vérification des identifiants Shiny : aucun identifiant UI dupliqué dans AGATE ;
- vérification de compatibilité des schémas : toutes les colonnes historiques sont conservées ;
- vérification du module OGRE : seuls l'éditeur et la validation MOA sont modifiés ; la supervision, le workflow et le stock validé restent inchangés ;
- vérification du verrou IDEP OGRE : aucun traitement de validation ne dépend encore d'un champ IDEP éditable ;
- vérification des références croisées : aucune référence résiduelle à `ref_ogr`, `source_ogre_workflow` ou `module_OGRE` dans les scripts AGATE ;
- vérification du vocabulaire utilisateur : les écrans principaux affichent APET et A88 ;
- vérification du bootstrap : les huit points d’entrée UI/serveur sont exportés depuis un environnement AGATE isolé.

Ces contrôles sont statiques et ne sollicitent ni le S3 ni une session Shiny déployée.

## Recette applicative recommandée

### 1. Création simple

1. Ouvrir AGATE > Édition.
2. Filtrer le référentiel APET et sélectionner plusieurs activités.
3. Choisir un parent et conserver au moins un enfant.
4. Cliquer sur **Vérifier**, puis **Créer la proposition**.
5. Vérifier que la proposition apparaît dans la file **À superviser**.

### 2. Remise en jeu d’une famille validée

1. Ouvrir **Familles validées AGATE**.
2. Sélectionner une famille et consulter son détail.
3. Cliquer sur **Remettre en jeu**, confirmer et ouvrir l’édition.
4. Vérifier que la famille est préchargée mais qu’aucune proposition n’est encore créée.
5. Ajuster la composition, créer la proposition et contrôler les champs de traçabilité du rejeu.
6. Vérifier que la famille publiée d’origine est toujours présente dans le stock.

### 3. Supervision avec modification

1. Prendre en charge la proposition.
2. Activer la modification.
3. Ajouter ou retirer une activité depuis le référentiel APET.
4. Contrôler la comparaison avant/après.
5. Transmettre la version modifiée en validation.

### 4. Validation MOA

1. Prendre en charge le dossier.
2. Vérifier que les IDEP validation et reprise sont affichés avec un verrou et ne sont pas modifiables.
3. Vérifier que l'IDEP enregistré dans la proposition correspond bien à l'IDEP de la session.
4. Tester une mise en attente puis une reprise.
5. Tester la publication en l’état sur un dossier.
6. Tester la recomposition et la publication avec modifications sur un autre dossier.
7. Vérifier le stock final et les liens publiés.

### 5. Éditeur OGRE repensé

1. Ouvrir OGRE > Édition et vérifier l'en-tête d'atelier ainsi que les quatre indicateurs de composition.
2. Sélectionner plusieurs lignes dans le référentiel et vérifier la mise à jour du compteur de sélection.
3. Choisir un parent et des enfants, puis vérifier les états `Prêt` dans les indicateurs.
4. Contrôler la lisibilité des onglets, du panneau de composition et du bouton principal de création.
5. Réaliser une création complète pour confirmer que les identifiants Shiny et le workflow sont inchangés.

### 6. Non-régression visuelle

- contrôler le thème clair et le thème sombre ;
- contrôler un écran large puis une largeur inférieure à 1 180 px ;
- vérifier que les indicateurs restent repliés par défaut ;
- vérifier que les options avancées n’empêchent pas le parcours simple ;
- vérifier les tables avec 10, 25, 50, 100 lignes et l’option d’affichage complet.
