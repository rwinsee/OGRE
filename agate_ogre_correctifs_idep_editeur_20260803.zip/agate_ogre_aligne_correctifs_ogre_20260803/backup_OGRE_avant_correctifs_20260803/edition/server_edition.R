dbg <- function(...) {
  cat(
    format(Sys.time(), "%H:%M:%S"),
    "[OGRE_EDITION]",
    paste(..., collapse = " "),
    "\n"
  )
}

dbg_df <- function(label, df) {
  dbg(
    label,
    "| nrow =", ifelse(is.null(df), "NULL", nrow(df)),
    "| ncol =", ifelse(is.null(df), "NULL", ncol(df)),
    "| cols =", ifelse(is.null(df), "NULL", paste(names(df), collapse = ", "))
  )
}

ogre_edition_server <- function(input, output, session) {
  
  if (is.null(session$userData$workflow_refresh)) {
    session$userData$workflow_refresh <- reactiveVal(0)
  }
  
  refresh_token <- session$userData$workflow_refresh
  last_parent_code <- reactiveVal("")
  selected_ref_codes <- reactiveVal(character(0))
  create_proposal_in_progress <- reactiveVal(FALSE)
  pending_incoherent_draft <- reactiveVal(NULL)
  reset_draft_in_progress <- reactiveVal(FALSE)
  
  if (is.null(session$userData$ogre_replay_context)) {
    session$userData$ogre_replay_context <- reactiveVal(NULL)
  }
  
  active_replay_context <- reactiveVal(NULL)
  replay_edit_mode <- reactiveVal("ajustement")
  
  normalize_ogr_codes <- function(codes) {
    codes <- unique(trimws(as.character(codes)))
    codes[!is.na(codes) & nzchar(codes)]
  }
  
  current_reference_codes <- reactive({
    normalize_ogr_codes(c(
      selected_ref_codes(),
      input$parent_code,
      input$child_codes
    ))
  })
  
  refresh_family_inputs <- function(parent_code = isolate(input$parent_code),
                                    source_codes = isolate(selected_ref_codes())) {
    codes <- normalize_ogr_codes(source_codes)
    
    selected <- ref_ogr %>%
      dplyr::filter(code_ogr %in% codes) %>%
      dplyr::distinct(code_ogr, .keep_all = TRUE)
    
    if (nrow(selected) == 0) {
      reset_composition_inputs(clear_table = FALSE)
      return(invisible(NULL))
    }
    
    ref_choices <- build_reference_choices(selected)
    
    parent_code <- trimws(first_non_empty(parent_code, ""))
    
    if (!nzchar(parent_code) || !(parent_code %in% unname(ref_choices))) {
      parent_code <- character(0)
    }
    
    child_choices <- ref_choices[unname(ref_choices) != parent_code]
    selected_children <- unname(child_choices)
    
    freezeReactiveValue(input, "parent_code")
    freezeReactiveValue(input, "child_codes")
    
    updateSelectizeInput(
      session,
      "parent_code",
      choices = ref_choices,
      selected = parent_code,
      options = list(placeholder = "Choisir le parent"),
      server = FALSE
    )
    
    updateSelectizeInput(
      session,
      "child_codes",
      choices = child_choices,
      selected = selected_children,
      options = list(placeholder = "Choisir les enfants"),
      server = FALSE
    )
    
    invisible(NULL)
  }
  
  sync_reference_selection <- function(codes,
                                       parent_code = isolate(input$parent_code),
                                       focus_selection_tab = FALSE) {
    codes <- normalize_ogr_codes(codes)
    
    selected_ref_codes(codes)
    
    if (isTRUE(focus_selection_tab)) {
      updateTabsetPanel(session, "edition_main_tabs", selected = "selection")
    }
    
    proxy <- DT::dataTableProxy("table_ref", session = session)
    rows <- match(codes, ref_ogr$code_ogr)
    rows <- as.integer(rows[!is.na(rows)])
    
    if (length(rows) == 0) {
      DT::selectRows(proxy, NULL)
      reset_composition_inputs(clear_table = FALSE)
      return(invisible(NULL))
    }
    
    DT::selectRows(proxy, rows)
    refresh_family_inputs(parent_code = parent_code, source_codes = codes)
    
    invisible(rows)
  }
  
  reset_composition_inputs <- function(clear_table = FALSE) {
    last_parent_code("")
    
    updateSelectizeInput(
      session,
      "parent_code",
      choices = character(0),
      selected = character(0),
      options = list(placeholder = "Choisir le parent"),
      server = FALSE
    )
    
    updateSelectizeInput(
      session,
      "child_codes",
      choices = character(0),
      selected = character(0),
      options = list(placeholder = "Choisir les enfants"),
      server = FALSE
    )
    
    if (isTRUE(clear_table)) {
      proxy <- DT::dataTableProxy("table_ref", session = session)
      try(DT::selectRows(proxy, NULL), silent = TRUE)
    }
    
    invisible(NULL)
  }
  
  replay_context_codes <- function(ctx) {
    normalize_ogr_codes(c(ctx$code_ogr_parent, ctx$child_codes))
  }
  
  apply_replay_context_to_editor <- function(ctx, focus_selection_tab = TRUE) {
    if (is.null(ctx)) {
      return(invisible(NULL))
    }
    
    active_replay_context(ctx)
    replay_edit_mode("ajustement")
    
    codes <- replay_context_codes(ctx)
    sync_reference_selection(
      codes = codes,
      parent_code = first_non_empty(ctx$code_ogr_parent, ""),
      focus_selection_tab = isTRUE(focus_selection_tab)
    )
    
    updateTextAreaInput(
      session,
      "commentaire_edition",
      value = first_non_empty(
        ctx$commentaire_edition,
        paste0("Remise en jeu de la famille validée ", first_non_empty(ctx$id_famille, ""), ".")
      )
    )
    
    showNotification(
      "Famille validée chargée dans l'atelier d'édition. Ajustez la proposition puis créez la modification.",
      type = "message",
      duration = 6
    )
    
    invisible(NULL)
  }
  
  get_current_idep <- function() {
    first_non_empty(
      get0("user_idep", envir = .GlobalEnv, ifnotfound = "", inherits = TRUE),
      ogre_current_idep(""),
      ""
    )
  }
  
  selected_reference <- reactive({
    codes <- current_reference_codes()
    
    dbg("selected_reference codes =", paste(codes, collapse = ","))
    
    if (length(codes) == 0) {
      dbg("selected_reference empty")
      return(reference_template()[0, , drop = FALSE])
    }
    
    out <- ref_ogr %>%
      dplyr::filter(code_ogr %in% codes) %>%
      dplyr::distinct(code_ogr, .keep_all = TRUE)
    
    dbg_df("selected_reference out", out)
    out
  })  
  available_reference <- reactive({
    selected <- selected_reference()
    
    if (nrow(selected) == 0) {
      return(reference_template()[0, , drop = FALSE])
    }
    
    selected
  })
  selection_recommendations <- reactive({
    build_selection_recommendations(selected_reference())
  })
  
  recommendation_detail <- reactive({
    build_recommendation_context(selected_reference(), ref_ogr)
  })
  
  show_edition_message_modal <- function(title, message, type = c("warning", "info")) {
    type <- match.arg(type)
    modal_class <- if (identical(type, "warning")) "alert alert-warning" else "alert alert-info"
    showModal(modalDialog(
      title = title,
      tags$div(class = modal_class, message),
      easyClose = TRUE,
      footer = modalButton("Fermer")
    ))
    invisible(NULL)
  }
  
  
  selection_incoherence_report <- function(draft) {
    empty <- list(
      has_warning = FALSE,
      reasons = character(0),
      parent_domain = "",
      child_domains = character(0),
      child_mismatches = data.frame()
    )
    
    if (is.null(draft)) {
      return(empty)
    }
    
    parent_code <- first_non_empty(draft$code_ogr_parent, "")
    child_codes <- normalize_ogr_codes(draft$child_codes)
    
    if (!nzchar(parent_code) || length(child_codes) == 0) {
      return(empty)
    }
    
    clean_value <- function(x) {
      x <- trimws(as.character(x)[1])
      if (is.na(x)) "" else x
    }
    
    row_value <- function(row, col) {
      if (!col %in% names(row) || nrow(row) == 0) {
        return("")
      }
      clean_value(row[[col]][1])
    }
    
    rome_section <- function(x) {
      x <- toupper(clean_value(x))
      if (!nzchar(x)) "" else substr(x, 1L, 1L)
    }
    
    rows <- ref_ogr %>%
      dplyr::filter(code_ogr %in% unique(c(parent_code, child_codes))) %>%
      dplyr::distinct(code_ogr, .keep_all = TRUE)
    
    if (nrow(rows) == 0) {
      return(empty)
    }
    
    parent_row <- rows %>%
      dplyr::filter(code_ogr == parent_code) %>%
      dplyr::slice(1)
    
    if (nrow(parent_row) == 0) {
      return(empty)
    }
    
    parent_domain <- row_value(parent_row, "libelle_grand_domaine")
    parent_prof_domain <- row_value(parent_row, "libelle_domaine_professionnel")
    parent_rome_parent <- row_value(parent_row, "code_rome_parent")
    parent_rome <- row_value(parent_row, "code_rome")
    parent_rome_section <- rome_section(parent_rome)
    
    child_rows <- rows %>%
      dplyr::filter(code_ogr %in% child_codes)
    
    if (nrow(child_rows) == 0) {
      return(empty)
    }
    
    child_rows$libelle_appellation_metier <- if ("libelle_appellation_metier" %in% names(child_rows)) {
      as.character(child_rows$libelle_appellation_metier)
    } else {
      ""
    }
    
    child_checks <- lapply(seq_len(nrow(child_rows)), function(i) {
      row <- child_rows[i, , drop = FALSE]
      child_domain <- row_value(row, "libelle_grand_domaine")
      child_prof_domain <- row_value(row, "libelle_domaine_professionnel")
      child_rome_parent <- row_value(row, "code_rome_parent")
      child_rome <- row_value(row, "code_rome")
      child_rome_section <- rome_section(child_rome)
      
      checks <- character(0)
      
      if (nzchar(parent_domain) && nzchar(child_domain) && !identical(parent_domain, child_domain)) {
        checks <- c(checks, "grand domaine différent")
      }
      
      if (nzchar(parent_prof_domain) && nzchar(child_prof_domain) && !identical(parent_prof_domain, child_prof_domain)) {
        checks <- c(checks, "domaine professionnel différent")
      }
      
      if (nzchar(parent_rome_parent) && nzchar(child_rome_parent) && !identical(parent_rome_parent, child_rome_parent)) {
        checks <- c(checks, "code ROME parent différent")
      }
      
      if (nzchar(parent_rome_section) && nzchar(child_rome_section) && !identical(parent_rome_section, child_rome_section)) {
        checks <- c(checks, "section ROME différente")
      }
      
      data.frame(
        code_ogr = row_value(row, "code_ogr"),
        libelle = row_value(row, "libelle_appellation_metier"),
        grand_domaine = child_domain,
        domaine_professionnel = child_prof_domain,
        code_rome = child_rome,
        code_rome_parent = child_rome_parent,
        controles = paste(unique(checks), collapse = " / "),
        stringsAsFactors = FALSE
      )
    })
    
    child_checks <- dplyr::bind_rows(child_checks)
    child_mismatches <- child_checks %>%
      dplyr::filter(nzchar(controles))
    
    child_domains <- unique(child_checks$grand_domaine[nzchar(child_checks$grand_domaine)])
    child_prof_domains <- unique(child_checks$domaine_professionnel[nzchar(child_checks$domaine_professionnel)])
    child_rome_sections <- unique(substr(child_checks$code_rome[nzchar(child_checks$code_rome)], 1L, 1L))
    
    has_diverse_children <-
      length(child_domains) > 1L ||
      length(child_prof_domains) > 1L ||
      length(child_rome_sections) > 1L
    
    if (nrow(child_mismatches) == 0 && !isTRUE(has_diverse_children)) {
      return(empty)
    }
    
    mismatch_labels <- paste0(
      child_mismatches$code_ogr,
      " — ",
      child_mismatches$libelle,
      " [",
      ifelse(nzchar(child_mismatches$grand_domaine), child_mismatches$grand_domaine, "grand domaine non renseigné"),
      " / ",
      ifelse(nzchar(child_mismatches$domaine_professionnel), child_mismatches$domaine_professionnel, "domaine pro non renseigné"),
      " / ",
      ifelse(nzchar(child_mismatches$code_rome), child_mismatches$code_rome, "ROME non renseigné"),
      "] : ",
      child_mismatches$controles
    )
    
    reasons <- c(
      paste0(
        "parent : ",
        first_non_empty(draft$libelle_parent, parent_code),
        " [grand domaine=", first_non_empty(parent_domain, "non renseigné"),
        " ; domaine pro=", first_non_empty(parent_prof_domain, "non renseigné"),
        " ; ROME=", first_non_empty(parent_rome, "non renseigné"), "]"
      ),
      if (nrow(child_mismatches) > 0) {
        paste0(
          "enfant(s) avec contexte différent : ",
          paste(utils::head(mismatch_labels, 8), collapse = " / ")
        )
      },
      if (isTRUE(has_diverse_children)) {
        "les enfants sélectionnés couvrent eux-mêmes plusieurs contextes métier"
      }
    )
    
    list(
      has_warning = TRUE,
      reasons = reasons[nzchar(reasons)],
      parent_domain = parent_domain,
      child_domains = child_domains,
      child_mismatches = child_mismatches
    )
  }
  
  show_incoherent_selection_modal <- function(report) {
    showModal(modalDialog(
      title = "Sélection possiblement incohérente",
      div(
        class = "alert alert-warning",
        tags$strong("Contrôle de cohérence métier : "),
        "la composition mélange des contextes qui peuvent être éloignés."
      ),
      if (length(report$reasons) > 0) {
        tags$ul(lapply(report$reasons, tags$li))
      },
      tags$p(
        "Ce contrôle est informatif : vous pouvez poursuivre si le regroupement est justifié métier."
      ),
      easyClose = FALSE,
      footer = tagList(
        modalButton("Revenir à la composition"),
        actionButton(
          "confirm_create_incoherent_selection",
          "Créer quand même la proposition",
          class = "btn-warning"
        )
      )
    ))
  }
  
  output$edition_replay_context_panel <- renderUI({
    ctx <- active_replay_context()
    if (is.null(ctx)) {
      return(NULL)
    }
    
    mode_label <- if (identical(replay_edit_mode(), "recomposition")) {
      "Recomposition complète"
    } else {
      "Ajustement rapide"
    }
    
    tags$div(
      class = "replay-context-card",
      tags$div(class = "replay-kicker", "Modification d'une famille validée"),
      tags$div(
        class = "replay-title",
        first_non_empty(ctx$libelle_parent, "Famille sans libellé"),
        " [", first_non_empty(ctx$code_ogr_parent, ""), "]"
      ),
      tags$p(
        class = "replay-copy",
        "Cette famille a été remise en jeu depuis le stock validé. La version de travail est initialisée avec la famille actuelle. Par défaut, ajustez à la marge ; utilisez la recomposition complète uniquement si la famille doit être reconstruite."
      ),
      tags$div(
        class = "replay-meta-grid",
        tags$span(tags$strong("Famille : "), first_non_empty(ctx$id_famille, "-")),
        tags$span(tags$strong("Enfants origine : "), length(ctx$child_codes)),
        tags$span(tags$strong("Mode : "), mode_label)
      ),
      tags$div(
        class = "replay-action-row",
        actionButton("edition_replay_quick_mode", "Ajustement rapide", class = "btn-success btn-sm"),
        actionButton("edition_replay_clear_work", "Recomposition complète", class = "btn-warning btn-sm"),
        actionButton("edition_replay_reset_from_stock", "Réinitialiser depuis la famille validée", class = "btn-default btn-sm"),
        actionButton("edition_replay_cancel", "Annuler la remise en jeu", class = "btn-danger btn-sm")
      )
    )
  })
  
  observeEvent(session$userData$ogre_replay_context(), {
    ctx <- session$userData$ogre_replay_context()
    if (is.null(ctx)) {
      return()
    }
    apply_replay_context_to_editor(ctx, focus_selection_tab = TRUE)
    session$userData$ogre_replay_context(NULL)
  }, ignoreInit = FALSE)
  
  observeEvent(input$edition_replay_quick_mode, {
    ctx <- active_replay_context()
    if (is.null(ctx)) {
      return()
    }
    replay_edit_mode("ajustement")
    showNotification("Mode ajustement rapide actif : retirez, ajoutez ou changez le parent sans repartir de zéro.", type = "message", duration = 4)
  })
  
  observeEvent(input$edition_replay_reset_from_stock, {
    ctx <- active_replay_context()
    if (is.null(ctx)) {
      return()
    }
    apply_replay_context_to_editor(ctx, focus_selection_tab = TRUE)
  })
  
  observeEvent(input$edition_replay_clear_work, {
    ctx <- active_replay_context()
    if (is.null(ctx)) {
      return()
    }
    
    showModal(modalDialog(
      title = "Recomposition complète",
      p("Cette action vide la version de travail courante."),
      p("La famille validée d'origine reste conservée dans le bandeau de contexte et vous pourrez la réinitialiser si besoin."),
      easyClose = TRUE,
      footer = tagList(
        modalButton("Annuler"),
        actionButton("edition_replay_confirm_clear_work", "Vider la version de travail", class = "btn-warning")
      )
    ))
  })
  
  observeEvent(input$edition_replay_confirm_clear_work, {
    removeModal()
    replay_edit_mode("recomposition")
    selected_ref_codes(character(0))
    last_parent_code("")
    reset_composition_inputs(clear_table = TRUE)
    updateTextAreaInput(
      session,
      "commentaire_edition",
      value = paste0(
        "Recomposition complète depuis la famille validée ",
        first_non_empty(active_replay_context()$id_famille, ""),
        "."
      )
    )
    updateTabsetPanel(session, "edition_main_tabs", selected = "selection")
    showNotification("Version de travail vidée. Sélectionnez un nouveau parent et les enfants depuis le référentiel.", type = "warning", duration = 6)
  })
  
  observeEvent(input$edition_replay_cancel, {
    active_replay_context(NULL)
    replay_edit_mode("standard")
    session$userData$ogre_replay_context(NULL)
    selected_ref_codes(character(0))
    last_parent_code("")
    reset_composition_inputs(clear_table = TRUE)
    updateTextAreaInput(session, "commentaire_edition", value = "")
    showNotification("Remise en jeu annulée dans l'atelier d'édition.", type = "message", duration = 4)
  })
  
  pipe_values_to_reco_buttons <- function(x, empty_label = "Aucun") {
    values <- split_pipe_values(x)
    if (length(values) == 0) {
      return(tags$span(class = "reco-ref-chip is-empty", empty_label))
    }
    
    tagList(lapply(values, function(value) {
      code <- sub("^.*\\[([^]]+)\\]$", "\\1", value)
      if (identical(code, value) || !nzchar(code)) {
        return(tags$span(class = "reco-ref-chip", value))
      }
      tags$button(
        type = "button",
        class = "reco-ref-chip-button",
        title = paste("Ajouter", value, "a la famille"),
        onclick = sprintf(
          "Shiny.setInputValue('%s', '%s', {priority: 'event'})",
          session$ns("recommendation_add_code"),
          code
        ),
        value
      )
    }))
  }
  
  
  # observeEvent(input$table_ref_rows_selected, {
  #   idx <- input$table_ref_rows_selected
  #   
  #   dbg("table_ref_rows_selected raw =", paste(idx, collapse = ","))
  #   
  #   if (is.null(idx) || length(idx) == 0) {
  #     return()
  #   }
  #   
  #   idx <- as.integer(idx)
  #   idx <- idx[!is.na(idx) & idx >= 1 & idx <= nrow(ref_ogr)]
  #   
  #   if (length(idx) == 0) {
  #     return()
  #   }
  #   
  #   clicked_codes <- ref_ogr$code_ogr[idx]
  #   clicked_codes <- unique(clicked_codes[!is.na(clicked_codes) & nzchar(clicked_codes)])
  #   
  #   old_codes <- selected_ref_codes()
  #   new_codes <- unique(c(old_codes, clicked_codes))
  #   
  #   dbg("selected_ref_codes old =", paste(old_codes, collapse = ","))
  #   dbg("selected_ref_codes clicked =", paste(clicked_codes, collapse = ","))
  #   dbg("selected_ref_codes new =", paste(new_codes, collapse = ","))
  #   
  #   selected_ref_codes(new_codes)
  #   
  #   refresh_family_inputs(parent_code = isolate(input$parent_code))
  # }, ignoreNULL = TRUE)  
  
  observeEvent(input$table_ref_rows_selected, {
    idx <- input$table_ref_rows_selected
    
    dbg("table_ref_rows_selected raw =", paste(idx, collapse = ","))
    
    if (is.null(idx) || length(idx) == 0) {
      dbg("table_ref_rows_selected empty -> reset composition")
      selected_ref_codes(character(0))
      reset_composition_inputs(clear_table = FALSE)
      return()
    }
    
    idx <- as.integer(idx)
    idx <- idx[!is.na(idx) & idx >= 1 & idx <= nrow(ref_ogr)]
    
    if (length(idx) == 0) {
      dbg("table_ref_rows_selected invalid -> reset composition")
      selected_ref_codes(character(0))
      reset_composition_inputs(clear_table = FALSE)
      return()
    }
    
    current_codes <- ref_ogr$code_ogr[idx]
    current_codes <- unique(current_codes[!is.na(current_codes) & nzchar(current_codes)])
    
    dbg("selected_ref_codes current =", paste(current_codes, collapse = ","))
    
    selected_ref_codes(current_codes)
    
    refresh_family_inputs(parent_code = isolate(input$parent_code), source_codes = current_codes)
  }, ignoreNULL = FALSE)  
  
  observeEvent(input$reset_draft, {
    dbg("CLICK reset_draft")
    
    reset_draft_in_progress(TRUE)
    on.exit(reset_draft_in_progress(FALSE), add = TRUE)
    
    # reset complet de l'atelier edition
    # y compris le contexte de remise en jeu, sinon le bandeau orange reste affiche
    selected_ref_codes(character(0))
    last_parent_code("")
    active_replay_context(NULL)
    replay_edit_mode("standard")
    session$userData$ogre_replay_context(NULL)
    pending_incoherent_draft(NULL)
    
    reset_composition_inputs(clear_table = TRUE)
    
    updateTextAreaInput(
      session,
      inputId = "commentaire_edition",
      value = ""
    )
    
    updateTabsetPanel(session, "edition_main_tabs", selected = "selection")
    
    showNotification(
      "Composition reinitialisee. Le contexte de remise en jeu a ete annule.",
      type = "message"
    )
  }, ignoreInit = TRUE)
  
  observeEvent(input$parent_code, {
    selected <- selected_reference()
    
    if (nrow(selected) == 0) {
      return()
    }
    
    parent_code <- trimws(first_non_empty(input$parent_code, ""))
    
    if (!nzchar(parent_code)) {
      return()
    }
    
    last_parent_code(parent_code)
    
    ref_choices <- build_reference_choices(selected)
    child_choices <- ref_choices[unname(ref_choices) != parent_code]
    selected_children <- unname(child_choices)
    
    freezeReactiveValue(input, "child_codes")
    
    updateSelectizeInput(
      session,
      "child_codes",
      choices = child_choices,
      selected = selected_children,
      options = list(placeholder = "Choisir les enfants"),
      server = FALSE
    )
  }, ignoreInit = TRUE)
  build_recommendation_panel_ui <- function() {
    reco <- selection_recommendations()
    detail <- recommendation_detail()
    actionable_suggestions <- detail$family_suggestions %>%
      filter(!deja_selectionne)
    has_recommendation <- nzchar(reco$suggested_parent_code) ||
      nrow(reco$candidate_parents) > 0 ||
      nrow(actionable_suggestions) > 0
    
    if (reco$selection_size == 0) {
      return(tags$div(
        class = "reco-inline-empty",
        tags$em("La preconisation s'affichera ici une fois une selection posee dans le referentiel.")
      ))
    }
    
    if (!has_recommendation) {
      return(tags$div(
        class = "reco-inline-empty",
        tags$em("Aucune preconisation proposee pour cette selection.")
      ))
    }
    
    summary_copy <- if (nzchar(reco$suggested_parent_code)) {
      paste("Parent conseille :", reco$suggested_parent_label)
    } else if (nrow(actionable_suggestions) > 0) {
      paste0(
        nrow(actionable_suggestions),
        " autre(s) piste(s) cliquable(s) a relire dans le meme contexte ROME."
      )
    } else {
      paste0(
        nrow(reco$candidate_parents),
        " candidat(s) parent a relire avant creation."
      )
    }
    
    tags$div(
      class = "reco-inline",
      tags$div(
        class = "reco-inline-copy",
        summary_copy
      ),
      actionButton("show_recommendation_detail", "Voir les preconisations", class = "btn-default")
    )
  }
  
  output$recommendation_panel <- renderUI({
    build_recommendation_panel_ui()
  })
  
  output$recommendation_modal_intro <- renderUI({
    reco <- selection_recommendations()
    detail <- recommendation_detail()
    actionable_suggestions <- detail$family_suggestions %>%
      filter(!deja_selectionne)
    
    intro_copy <- if (nzchar(reco$suggested_parent_code)) {
      "La selection courante fait ressortir un parent conseille. Tu peux l'appliquer directement ou completer la famille avec les autres suggestions plus bas."
    } else {
      "Pas de parent unique conseille pour l'instant. Utilise le contexte ROME et les autres suggestions de famille pour completer ou affiner la selection."
    }
    
    tags$div(
      class = "reco-section",
      tags$div(class = "reco-section-title", "Preconisation sur la selection courante"),
      tags$div(class = "reco-section-help", intro_copy),
      if (nzchar(reco$suggested_parent_code)) {
        tags$div(
          class = "reco-inline",
          tags$div(
            class = "reco-inline-copy",
            tags$strong("Parent conseille : "),
            reco$suggested_parent_label
          ),
          actionButton("apply_recommended_parent", "Appliquer le parent conseille", class = "btn-default")
        )
      } else {
        tags$p(class = "reco-note-italic", "Aucun parent unique conseille pour cette selection.")
      },
      if (nrow(actionable_suggestions) > 0) {
        tags$p(
          class = "reco-section-help",
          paste(
            nrow(actionable_suggestions),
            "autre(s) code(s) du meme contexte ROME peuvent etre ajoutes a la famille depuis la zone ci-dessous."
          )
        )
      }
    )
  })
  
  output$recommendation_detail_summary <- renderUI({
    detail <- recommendation_detail()
    code_detail <- detail$code_detail
    rome_detail <- detail$rome_detail
    
    card <- function(label, value, help, alt = FALSE) {
      tags$div(
        class = paste("reco-summary-card", if (alt) "alt"),
        tags$div(class = "reco-summary-label", label),
        tags$div(class = "reco-summary-value", value),
        tags$div(class = "reco-summary-help", help)
      )
    }
    
    tags$div(
      class = "reco-summary-grid",
      card("Codes OGR", nrow(code_detail), "Nombre de lignes dans la selection"),
      card("Codes ROME", nrow(rome_detail), "Nombre de contextes ROME touches", alt = TRUE),
      card("Principales", sum(code_detail$classification == "PRINCIPALE"), "Appellations principales visibles"),
      card("Synonymes", sum(code_detail$classification == "SYNONYME"), "Appellations synonymes visibles", alt = TRUE)
    )
  })
  
  output$recommendation_code_table <- renderDT({
    detail <- recommendation_detail()
    code_display <- detail$code_detail %>%
      transmute(
        code_ogr = code_ogr,
        libelle = libelle,
        classification = ifelse(
          classification == "PRINCIPALE",
          "<span class='reco-badge reco-badge-parent'>PRINCIPALE</span>",
          "<span class='reco-badge reco-badge-neutral'>SYNONYME</span>"
        ),
        code_rome = code_rome,
        code_rome_parent = code_rome_parent,
        lecture = dplyr::case_when(
          lecture_preco == "Plutot parent" ~ "<span class='reco-badge reco-badge-parent'>Plutot parent</span>",
          lecture_preco == "Plutot enfant" ~ "<span class='reco-badge reco-badge-child'>Plutot enfant</span>",
          TRUE ~ paste0("<span class='reco-badge reco-badge-neutral'>", lecture_preco, "</span>")
        )
      )
    
    datatable(
      code_display,
      rownames = FALSE,
      escape = FALSE,
      selection = "none",
      options = ogre_dt_options(
        page_length = 6,
        scroll_y = "32vh",
        dom = "tip",
        column_defs = list(
          list(width = "90px", targets = 0),
          list(width = "280px", targets = 1),
          list(width = "140px", targets = 2),
          list(width = "90px", targets = 3),
          list(width = "110px", targets = 4),
          list(width = "150px", targets = 5)
        )
      )
    )
  }, server = F)
  
  output$recommendation_rome_cards <- renderUI({
    detail <- recommendation_detail()
    rome_detail <- detail$rome_detail
    
    if (nrow(rome_detail) == 0) {
      return(tags$p("Aucun contexte ROME a afficher."))
    }
    
    tags$div(
      class = "reco-rome-stack",
      lapply(seq_len(nrow(rome_detail)), function(i) {
        row <- rome_detail[i, , drop = FALSE]
        
        tags$div(
          class = "reco-rome-card",
          tags$div(
            class = "reco-rome-head",
            tags$div(
              tags$div(class = "reco-rome-title", paste("ROME", row$code_rome[1])),
              tags$div(class = "reco-rome-subtitle", paste("ROME parent :", row$code_rome_parent[1]))
            ),
            tags$div(
              class = "reco-rome-metrics",
              tags$span(class = "reco-rome-metric", paste(row$nb_codes_selectionnes[1], "codes selectionnes")),
              tags$span(class = "reco-rome-metric", paste(row$nb_principales_rome[1], "principales visibles")),
              tags$span(class = "reco-rome-metric", paste(row$nb_synonymes_rome[1], "synonymes visibles"))
            )
          ),
          tags$div(
            class = "reco-rome-block",
            tags$div(class = "reco-rome-block-title", "Dans ta selection"),
            pipe_values_to_tags(row$codes_selectionnes[1], empty_label = "Aucun code selectionne")
          ),
          tags$div(
            class = "reco-rome-block",
            tags$div(class = "reco-rome-block-title", "Principales du meme ROME"),
            pipe_values_to_reco_buttons(row$principales_du_rome[1], empty_label = "Aucune principale visible")
          ),
          tags$div(
            class = "reco-rome-block",
            tags$div(class = "reco-rome-block-title", "Synonymes du meme ROME"),
            pipe_values_to_reco_buttons(row$synonymes_du_rome[1], empty_label = "Aucun synonyme visible")
          )
        )
      })
    )
  })
  
  output$recommendation_family_suggestions <- renderUI({
    detail <- recommendation_detail()
    suggestions <- detail$family_suggestions %>%
      filter(!deja_selectionne)
    
    if (nrow(suggestions) == 0) {
      return(tags$div(
        class = "reco-section",
        tags$div(class = "reco-section-title", "Autres suggestions de famille"),
        tags$p(class = "reco-note-italic", "Aucune autre ligne a ajouter depuis cette preconisation.")
      ))
    }
    
    groups <- split(suggestions, suggestions$code_rome)
    
    tags$div(
      class = "reco-section",
      tags$div(class = "reco-section-title", "Autres suggestions de famille"),
      tags$div(
        class = "reco-section-help",
        "Clique sur une ou plusieurs lignes ci-dessous pour les ajouter a la famille. La selection du referentiel est synchronisee automatiquement."
      ),
      lapply(names(groups), function(code_rome) {
        group_df <- groups[[code_rome]]
        group_parent <- unique(group_df$code_rome_parent[nzchar(group_df$code_rome_parent) & group_df$code_rome_parent != "ND"])
        
        tags$div(
          class = "reco-rome-block",
          tags$div(
            class = "reco-rome-block-title",
            paste(
              "ROME",
              code_rome,
              if (length(group_parent) == 0) "" else paste0("- parent ", group_parent[1])
            )
          ),
          tagList(lapply(seq_len(nrow(group_df)), function(i) {
            row <- group_df[i, , drop = FALSE]
            tags$button(
              type = "button",
              class = paste(
                "reco-ref-chip-button",
                if (identical(row$classification[1], "PRINCIPALE")) "is-parent" else "is-child"
              ),
              title = paste(
                "Ajouter",
                row$libelle[1],
                "[", row$code_ogr[1], "]",
                "-",
                row$classification[1]
              ),
              onclick = sprintf(
                "Shiny.setInputValue('%s', '%s', {priority: 'event'})",
                session$ns("recommendation_add_code"),
                row$code_ogr[1]
              ),
              build_reference_label(row$code_ogr[1], row$libelle[1])
            )
          }))
        )
      })
    )
  })
  
  families_data <- reactive({
    refresh_token()
    load_families() %>%
      arrange(desc(date_creation), id_famille)
  })
  
  proposals_data <- reactive({
    token <- refresh_token()
    dbg("proposals_data refresh_token =", token)
    
    out <- load_proposals("edition") %>%
      arrange(desc(horodatage_edition), id_proposition)
    
    dbg_df("proposals_data OUT", out)
    
    out
  })
  
  workflow_active_proposals <- reactive({
    refresh_token()
    load_active_workflow_proposals() %>%
      arrange(desc(horodatage_edition), id_proposition)
  })
  
  families_view <- reactive({
    enrich_family_diagnostics(families_data())
  })
  
  selected_family <- reactive({
    families <- families_view()
    if (nrow(families) == 0) {
      return(NULL)
    }
    
    idx <- input$table_families_rows_selected
    visible_rows <- input$table_families_rows_all
    
    if (is.null(idx) || length(idx) != 1) {
      idx <- input$table_families_detail_rows_selected
      visible_rows <- input$table_families_detail_rows_all
    }
    
    if (is.null(idx) || length(idx) != 1) {
      return(NULL)
    }
    
    if (!is.null(visible_rows) && length(visible_rows) > 0) {
      idx <- visible_rows[idx]
    }
    
    idx <- as.integer(idx)
    
    if (is.na(idx) || idx < 1 || idx > nrow(families)) {
      return(NULL)
    }
    
    families[idx, , drop = FALSE]
  })
  
  selected_proposal <- reactive({
    idx <- input$table_proposals_rows_selected
    proposals <- proposals_data()
    
    if (length(idx) != 1 || nrow(proposals) < idx) {
      return(NULL)
    }
    
    proposals[idx, , drop = FALSE]
  })
  
  draft_family <- reactive({
    parent_code <- first_non_empty(input$parent_code, "")
    parent_code <- trimws(parent_code)
    child_codes <- input$child_codes
    if (is.null(child_codes) || length(child_codes) == 0) {
      child_codes <- character(0)
    }
    child_codes <- unique(trimws(child_codes))
    child_codes <- child_codes[nzchar(child_codes)]
    child_codes <- setdiff(child_codes, parent_code)
    commentaire_edition = trimws(first_non_empty(input$commentaire_edition, ""))
    selected_ref <- available_reference()
    
    if (!nzchar(parent_code)) {
      return(NULL)
    }
    
    parent_row <- selected_ref %>%
      filter(code_ogr == parent_code) %>%
      slice(1)
    
    if (nrow(parent_row) == 0) {
      return(NULL)
    }
    
    child_rows <- selected_ref %>%
      filter(code_ogr %in% child_codes) %>%
      distinct(code_ogr, .keep_all = TRUE)
    
    if (nrow(child_rows) > 0) {
      child_rows <- child_rows[match(child_codes, child_rows$code_ogr), , drop = FALSE]
    }
    
    replay_ctx <- active_replay_context()
    
    list(
      id_famille = "BROUILLON",
      idep_agent = trimws(get_current_idep()),
      code_ogr_parent = parent_row$code_ogr[1],
      code_rome_parent = parent_row$code_rome[1],
      libelle_parent = parent_row$libelle_appellation_metier[1],
      child_codes = as.character(child_rows$code_ogr),
      child_labels = as.character(child_rows$libelle_appellation_metier),
      commentaire_edition = trimws(first_non_empty(input$commentaire_edition, "")),
      base_famille_id = if (is.null(replay_ctx)) "" else first_non_empty(replay_ctx$id_famille, ""),
      base_codes_ogr_enfants = if (is.null(replay_ctx)) "" else paste(replay_ctx$child_codes, collapse = " | "),
      origine_rejeu_stock = if (is.null(replay_ctx)) "" else "famille_validee",
      origine_proposition = if (is.null(replay_ctx)) "" else first_non_empty(replay_ctx$origine_proposition, "rejeu_stock_valide"),
      mode_entree_edition = if (is.null(replay_ctx)) "composition_manuelle" else first_non_empty(replay_ctx$mode_entree_edition, "remise_en_jeu"),
      id_proposition_source = if (is.null(replay_ctx)) "" else first_non_empty(replay_ctx$id_proposition_source, ""),
      fichier_source = if (is.null(replay_ctx)) "" else first_non_empty(replay_ctx$fichier_source, ""),
      id_famille_rejouee = if (is.null(replay_ctx)) "" else first_non_empty(replay_ctx$id_famille_rejouee, replay_ctx$id_famille),
      fichier_famille_rejouee = if (is.null(replay_ctx)) "" else first_non_empty(replay_ctx$fichier_famille_rejouee, replay_ctx$fichier_source),
      horodatage_rejeu = if (is.null(replay_ctx)) "" else first_non_empty(replay_ctx$horodatage_rejeu, ""),
      idep_agent_rejeu = if (is.null(replay_ctx)) "" else first_non_empty(replay_ctx$idep_agent_rejeu, replay_ctx$idep_agent),
      commentaire_rejeu = if (is.null(replay_ctx)) "" else first_non_empty(replay_ctx$commentaire_rejeu, "")
    )
  })
  
  output$family_preview <- renderUI({
    draft <- draft_family()
    
    if (is.null(draft)) {
      return(
        tags$div(
          class = "reco-box",
          tags$p(
            class = "reco-line",
            tags$strong("Aucun parent selectionne.")
          ),
          tags$p(
            class = "action-help",
            "Choisissez un parent pour visualiser le resume de la famille."
          )
        )
      )
    }
    
    child_df <- child_df_from_vectors(draft$child_codes, draft$child_labels)
    replay_ctx <- active_replay_context()
    base_family <- find_base_family_for_draft(draft, families_data())
    operation_label <- if (!is.null(replay_ctx) || !is.null(base_family)) "Modification" else "Creation"
    
    tags$div(
      tags$p(tags$strong("IDEP agent : "), ifelse(nzchar(draft$idep_agent), draft$idep_agent, "non renseigne")),
      tags$p(tags$strong("Type de proposition : "), operation_label),
      tags$p(tags$strong("Parent : "), draft$libelle_parent),
      tags$p(tags$strong("Code parent : "), draft$code_ogr_parent),
      tags$p(tags$strong("Code ROME parent : "), draft$code_rome_parent),
      if (!is.null(base_family)) {
        tags$p(tags$strong("Famille stock cible : "), base_family$id_famille[1])
      },
      tags$p(tags$strong("Nombre d'enfants : "), nrow(child_df)),
      if (nrow(child_df) == 0) {
        tags$p("Aucun enfant selectionne.")
      } else {
        tags$table(
          class = "table table-striped table-bordered preview-table",
          tags$thead(
            tags$tr(
              tags$th("Code OGR"),
              tags$th("Libelle enfant")
            )
          ),
          tags$tbody(
            lapply(seq_len(nrow(child_df)), function(i) {
              tags$tr(
                tags$td(child_df$code_ogr[i]),
                tags$td(child_df$libelle[i])
              )
            })
          )
        )
      }
    )
  })
  
  output$table_ref <- DT::renderDT({
    build_reference_source_datatable(
      ref_df = ref_ogr,
      selection = "multiple",
      page_length = 10L,
      length_menu = c(5, 10, 15, 25),
      dom = "Bfrtip"
    )
  }, server = FALSE)
  
  make_families_stock_table <- function() {
    datatable(
      families_view() %>%
        select(
          id_famille,
          idep_agent,
          code_rome_parent,
          code_ogr_parent,
          libelle_parent,
          doublon_parent,
          doublon_enfant,
          codes_enfants_en_doublon,
          codes_ogr_enfants,
          nb_enfants,
          date_creation,
          fichier_stockage
        ),
      extensions = "Buttons",
      selection = "single",
      rownames = FALSE,
      options = ogre_dt_options(
        page_length = 10,
        scroll_y = "50vh",
        dom = "Bfrtip",
        buttons = TRUE
      )
    ) %>%
      formatStyle(
        "doublon_parent",
        backgroundColor = styleEqual(c("OUI", "NON"), c("#ffe3e0", "#e9f7ef")),
        color = styleEqual(c("OUI", "NON"), c("#a93226", "#1e8449")),
        fontWeight = styleEqual(c("OUI", "NON"), c("700", "500"))
      ) %>%
      formatStyle(
        "doublon_enfant",
        backgroundColor = styleEqual(c("OUI", "NON"), c("#fff1d6", "#eef7ff")),
        color = styleEqual(c("OUI", "NON"), c("#b45f06", "#1f5f8b")),
        fontWeight = styleEqual(c("OUI", "NON"), c("700", "500"))
      )
  }
  
  output$table_families <- renderDT({
    make_families_stock_table()
  }, server = FALSE)
  
  output$table_families_detail <- renderDT({
    make_families_stock_table()
  }, server = FALSE)
  
  output$stock_families_notice <- renderUI({
    tags$div(
      class = "app-card",
      if (nrow(families_data()) == 0) {
        tags$p(
          tags$strong("Aucune famille publiee pour le moment. "),
          "Le stock sera alimente apres publication d'une proposition en validation MOA."
        )
      } else {
        tags$p(
          tags$strong("Stock en lecture seule dans Edition. "),
          "Cet onglet sert a consulter l'etat publie. Une famille validee par la MOA ne peut pas etre supprimee directement ici."
        )
      },
      tags$p(
        class = "action-help",
        "Si une famille publiee doit evoluer, il faut repartir sur une nouvelle proposition puis laisser la decision finale a la validation MOA."
      )
    )
  })
  
  observeEvent(input$edition_main_tabs, {
    current_tab <- tolower(first_non_empty(input$edition_main_tabs, ""))
    
    dbg("TAB opened =", current_tab)
    
    if (current_tab %in% c("propositions", "stock existant", "detail stock")) {
      dbg("TAB opened -> force refresh =", current_tab)
      refresh_token(isolate(refresh_token()) + 1)
    }
  }, ignoreInit = TRUE)
  
  
  output$table_proposals <- renderDT({
    
    badge_status <- function(x) {
      x <- as.character(x)
      
      css <- dplyr::case_when(
        x == "a_superviser" ~ "ogre-status-a-superviser",
        x == "en_cours"     ~ "ogre-status-en-cours",
        x == "rejetes"      ~ "ogre-status-rejetes",
        x == "a_valider"    ~ "ogre-status-a-valider",
        x == "valides"      ~ "ogre-status-valides",
        TRUE                ~ "ogre-status-en-cours"
      )
      
      paste0(
        "<span class='ogre-badge ", css, "'>",
        htmltools::htmlEscape(x),
        "</span>"
      )
    }
    
    badge_type <- function(x) {
      x <- as.character(x)
      
      css <- dplyr::case_when(
        x == "creation"     ~ "ogre-type-creation",
        x == "modification" ~ "ogre-type-modification",
        TRUE                ~ "ogre-type-creation"
      )
      
      paste0(
        "<span class='ogre-badge ", css, "'>",
        htmltools::htmlEscape(x),
        "</span>"
      )
    }
    
    data <- proposals_data() %>%
      dplyr::select(
        id_proposition,
        phase_proposition,
        statut_proposition,
        type_operation,
        idep_agent_edition,
        code_ogr_parent,
        libelle_parent,
        nb_enfants,
        commentaire_edition,
        base_famille_id,
        delta_enfants_ajoutes_edition,
        delta_enfants_retires_edition,
        decision_supervision,
        horodatage_edition
      ) %>%
      dplyr::mutate(
        commentaire_edition = htmltools::htmlEscape(ogre_truncate_chr(commentaire_edition, 160L)),
        statut_proposition = badge_status(statut_proposition),
        type_operation = badge_type(type_operation)
      )
    
    DT::datatable(
      data,
      extensions = "Buttons",
      selection = "single",
      rownames = FALSE,
      escape = FALSE,
      options = ogre_dt_options(
        page_length = 10,
        scroll_y = "50vh",
        dom = "Bfrtip",
        buttons = TRUE
      )
    )
    
  }, server = FALSE)
  
  outputOptions(output, "table_proposals", suspendWhenHidden = FALSE)
  
  output$proposal_detail <- renderUI({
    proposal <- selected_proposal()
    
    if (is.null(proposal)) {
      return(tags$p("Selectionnez une proposition pour voir son detail."))
    }
    
    child_df <- child_df_from_vectors(
      split_pipe_values(proposal$codes_ogr_enfants[1]),
      split_pipe_values(proposal$libelles_enfants[1])
    )
    
    tags$div(
      class = "app-card",
      tags$p(tags$strong("ID proposition : "), proposal$id_proposition[1]),
      tags$p(tags$strong("Phase : "), proposal$phase_proposition[1]),
      tags$p(tags$strong("Statut : "), proposal$statut_proposition[1]),
      tags$p(tags$strong("Type : "), proposal$type_operation[1]),
      if ("origine_proposition" %in% names(proposal) && nzchar(proposal$origine_proposition[1])) {
        tags$p(tags$strong("Origine : "), proposal$origine_proposition[1])
      },
      if ("mode_entree_edition" %in% names(proposal) && nzchar(proposal$mode_entree_edition[1])) {
        tags$p(tags$strong("Mode entree edition : "), proposal$mode_entree_edition[1])
      },
      if ("id_famille_rejouee" %in% names(proposal) && nzchar(proposal$id_famille_rejouee[1])) {
        tags$p(tags$strong("Famille remise en jeu : "), proposal$id_famille_rejouee[1])
      },
      if ("idep_agent_rejeu" %in% names(proposal) && nzchar(proposal$idep_agent_rejeu[1])) {
        tags$p(tags$strong("Agent remise en jeu : "), proposal$idep_agent_rejeu[1])
      },
      if ("horodatage_rejeu" %in% names(proposal) && nzchar(proposal$horodatage_rejeu[1])) {
        tags$p(tags$strong("Horodatage remise en jeu : "), proposal$horodatage_rejeu[1])
      },
      tags$p(tags$strong("Lignee : "), proposal$id_lignee[1]),
      if (nzchar(proposal$id_proposition_source[1])) {
        tags$p(tags$strong("Source : "), proposal$id_proposition_source[1])
      },
      tags$p(tags$strong("IDEP edition : "), proposal$idep_agent_edition[1]),
      tags$p(tags$strong("Horodatage edition : "), proposal$horodatage_edition[1]),
      tags$p(tags$strong("Famille stock cible : "), ifelse(nzchar(proposal$base_famille_id[1]), proposal$base_famille_id[1], "Aucune")),
      tags$p(tags$strong("Code parent : "), proposal$code_ogr_parent[1]),
      tags$p(tags$strong("Parent : "), proposal$libelle_parent[1]),
      
      if (nzchar(proposal$delta_enfants_ajoutes_edition[1])) {
        tags$p(tags$strong("Enfants ajoutes en edition : "), proposal$delta_enfants_ajoutes_edition[1])
      },
      if (nzchar(proposal$delta_enfants_retires_edition[1])) {
        tags$p(tags$strong("Enfants retires en edition : "), proposal$delta_enfants_retires_edition[1])
      },
      if (nzchar(proposal$commentaire_edition[1])) {
        tags$p(tags$strong("Commentaire édition : "), proposal$commentaire_edition[1])
      },
      if (nzchar(proposal$decision_supervision[1])) {
        tags$p(tags$strong("Decision supervision : "), proposal$decision_supervision[1])
      },
      if (nzchar(proposal$commentaire_supervision[1])) {
        tags$p(tags$strong("Commentaire supervision : "), proposal$commentaire_supervision[1])
      },
      tags$h4("Contenu propose"),
      if (nrow(child_df) == 0) {
        tags$p("Aucun enfant.")
      } else {
        tags$table(
          class = "table table-striped table-bordered",
          tags$thead(
            tags$tr(
              tags$th("Code OGR"),
              tags$th("Libelle")
            )
          ),
          tags$tbody(
            lapply(seq_len(nrow(child_df)), function(i) {
              tags$tr(
                tags$td(child_df$code_ogr[i]),
                tags$td(child_df$libelle[i])
              )
            })
          )
        )
      }
    )
  })
  
  render_family_detail <- function() {
    family <- selected_family()
    
    if (nrow(families_data()) == 0) {
      return(tags$div(
        class = "app-card",
        tags$p("Aucune famille n'est encore publiee dans le stock.")
      ))
    }
    
    if (is.null(family)) {
      return(tags$div(
        class = "app-card",
        tags$p("Selectionnez une famille dans le stock pour voir son detail.")
      ))
    }
    
    child_df <- child_df_from_vectors(
      split_pipe_values(family$codes_ogr_enfants[1]),
      split_pipe_values(family$libelles_enfants[1])
    )
    
    tags$div(
      class = "app-card",
      tags$p(tags$strong("ID : "), family$id_famille[1]),
      tags$p(tags$strong("IDEP agent : "), family$idep_agent[1]),
      tags$p(tags$strong("Fichier : "), family$fichier_stockage[1]),
      tags$p(tags$strong("Code ROME parent : "), family$code_rome_parent[1]),
      tags$p(tags$strong("Code parent : "), family$code_ogr_parent[1]),
      tags$p(tags$strong("Parent : "), family$libelle_parent[1]),
      tags$p(tags$strong("Doublon parent : "), family$doublon_parent[1]),
      tags$p(tags$strong("Doublon enfant : "), family$doublon_enfant[1]),
      if (nzchar(family$codes_enfants_en_doublon[1])) {
        tags$p(tags$strong("Codes enfants en doublon : "), family$codes_enfants_en_doublon[1])
      },
      tags$p(tags$strong("Date creation : "), family$date_creation[1]),
      tags$h4("Enfants"),
      if (nrow(child_df) == 0) {
        tags$p("Aucun enfant.")
      } else {
        tags$div(
          class = "ogre-detail-table-wrap",
          tags$table(
            class = "table table-striped table-bordered ogre-detail-table",
            tags$thead(
              tags$tr(
                tags$th("Code OGR"),
                tags$th("Libelle")
              )
            ),
            tags$tbody(
              lapply(seq_len(nrow(child_df)), function(i) {
                tags$tr(
                  tags$td(child_df$code_ogr[i]),
                  tags$td(child_df$libelle[i])
                )
              })
            )
          )
        )
      }
    )
  }
  
  output$stock_family_detail <- renderUI({
    render_family_detail()
  })
  
  output$detail_stock_family_detail <- renderUI({
    render_family_detail()
  })
  
  output$family_detail <- renderUI({
    render_family_detail()
  })
  
  observeEvent(input$apply_recommended_parent, {
    dbg("CLICK apply_recommended_parent")
    
    reco <- selection_recommendations()
    
    dbg(
      "RECO",
      "| selection_size =", reco$selection_size,
      "| suggested_parent_code =", reco$suggested_parent_code,
      "| suggested_parent_label =", reco$suggested_parent_label
    )
    
    dbg(
      "INPUTS BEFORE",
      "| table_ref_rows_selected =", paste(input$table_ref_rows_selected, collapse = ","),
      "| parent_code =", input$parent_code,
      "| child_codes =", paste(input$child_codes, collapse = ",")
    )
    
    dbg_df("selected_reference BEFORE", selected_reference())
    dbg_df("available_reference BEFORE", available_reference())
    
    if (!nzchar(reco$suggested_parent_code)) {
      dbg("STOP no suggested parent")
      showNotification("Aucune preconisation unique a appliquer sur cette selection.", type = "warning")
      return()
    }
    
    tryCatch({
      refresh_family_inputs(
        parent_code = reco$suggested_parent_code,
        source_codes = current_reference_codes()
      )
      last_parent_code(reco$suggested_parent_code)
      showNotification("Preconisation appliquee a la composition.", type = "message", duration = 5)
    }, error = function(e) {
      dbg("ERROR apply_recommended_parent:", conditionMessage(e))
      showNotification(paste("Erreur application preconisation :", conditionMessage(e)), type = "error")
    })
  })
  
  observeEvent(input$recommendation_add_code, {
    code_to_add <- trimws(first_non_empty(input$recommendation_add_code, ""))
    
    if (!nzchar(code_to_add)) {
      return()
    }
    
    current_codes <- current_reference_codes()
    next_codes <- normalize_ogr_codes(c(current_codes, code_to_add))
    
    if (identical(sort(next_codes), sort(current_codes))) {
      showNotification("Cette ligne est deja dans la famille.", type = "message", duration = 4)
      return()
    }
    
    added_row <- ref_ogr %>%
      filter(code_ogr == code_to_add) %>%
      distinct(code_ogr, .keep_all = TRUE) %>%
      slice(1)
    
    sync_reference_selection(
      codes = next_codes,
      parent_code = isolate(input$parent_code),
      focus_selection_tab = TRUE
    )
    
    added_label <- if (nrow(added_row) == 0) {
      code_to_add
    } else {
      build_reference_label(added_row$code_ogr[1], added_row$libelle_appellation_metier[1])
    }
    
    showNotification(
      paste(added_label, "ajoute a la famille en cours."),
      type = "message",
      duration = 5
    )
  }, ignoreInit = TRUE)
  
  observeEvent(input$show_recommendation_detail, {
    reco <- selection_recommendations()
    
    if (reco$selection_size == 0) {
      showNotification("Selectionnez d'abord quelques lignes dans le referentiel.", type = "warning")
      return()
    }
    
    showModal(modalDialog(
      title = "Preconisations de famille",
      tags$div(
        class = "reco-detail-wrap",
        uiOutput("recommendation_modal_intro"),
        tags$div(
          class = "reco-section",
          tags$div(class = "reco-section-title", "Vue d'ensemble"),
          uiOutput("recommendation_detail_summary")
        ),
        tags$div(
          class = "reco-section",
          tags$div(class = "reco-section-title", "Lecture rapide des codes selectionnes"),
          tags$div(
            class = "reco-section-help",
            "Une ligne par code OGR, avec une lecture courte de ce qu'on voit pour choisir le parent."
          ),
          DTOutput("recommendation_code_table")
        ),
        tags$div(
          class = "reco-section",
          tags$div(class = "reco-section-title", "Contexte ROME"),
          tags$div(
            class = "reco-section-help",
            "Pour chaque code ROME touche par ta selection, tu vois les principales et synonymes disponibles autour."
          ),
          uiOutput("recommendation_rome_cards")
        ),
        uiOutput("recommendation_family_suggestions")
      ),
      size = "l",
      easyClose = TRUE,
      footer = modalButton("Fermer")
    ))
  })
  
  show_family_simulation <- function(family) {
    if (is.null(family)) {
      show_edition_message_modal(
        title = "Filiation incomplete",
        message = "Choisissez un parent puis au moins un enfant avant de verifier la filiation.",
        type = "warning"
      )
      return(invisible(NULL))
    }
    
    if (is.list(family)) {
      parent_label <- family$libelle_parent
      parent_code <- family$code_ogr_parent
      child_labels <- family$child_labels
      child_codes <- family$child_codes
      family_title <- family$id_famille
    } else {
      parent_label <- family$libelle_parent[1]
      parent_code <- family$code_ogr_parent[1]
      child_labels <- split_pipe_values(family$libelles_enfants[1])
      child_codes <- split_pipe_values(family$codes_ogr_enfants[1])
      family_title <- family$id_famille[1]
    }
    
    max_len <- max(length(child_labels), length(child_codes))
    if (max_len == 0) {
      child_labels <- character(0)
      child_codes <- character(0)
    } else {
      length(child_labels) <- max_len
      length(child_codes) <- max_len
      child_labels[is.na(child_labels)] <- ""
      child_codes[is.na(child_codes)] <- ""
    }
    
    if (length(child_labels) == 0) {
      show_edition_message_modal(
        title = "Aucun enfant selectionne",
        message = "La famille contient un parent, mais aucun enfant. Ajoutez au moins un enfant avant de verifier la filiation.",
        type = "warning"
      )
      return(invisible(NULL))
    }
    
    if (!has_plotly) {
      showModal(modalDialog(
        title = "Simulation de filiation",
        p("Le package 'plotly' n'est pas installe sur cette machine."),
        easyClose = TRUE,
        footer = modalButton("Fermer")
      ))
      return(invisible(NULL))
    }
    
    output$family_plot <- plotly::renderPlotly({
      if (length(child_labels) == 0) {
        return(
          plotly::plot_ly() %>%
            plotly::layout(
              title = "Aucun enfant a afficher",
              xaxis = list(visible = FALSE),
              yaxis = list(visible = FALSE),
              paper_bgcolor = "#f7f9fd",
              plot_bgcolor = "#f7f9fd"
            )
        )
      }
      
      labels <- c(parent_label, child_labels)
      codes <- c(parent_code, child_codes)
      child_palette <- rep_len(
        c("#FF6B6B", "#FFD166", "#06D6A0", "#4D96FF", "#9B5DE5", "#F15BB5", "#00BBF9", "#F9844A"),
        length(child_labels)
      )
      node_colors <- c("#003049", child_palette)
      link_colors <- c("rgba(0, 48, 73, 0.55)", hex_to_rgba(child_palette, alpha = 0.42))
      custom_text <- c(
        paste0("<b>Parent</b><br>", parent_label, "<br>Code OGR : ", parent_code),
        paste0("<b>Enfant</b><br>", child_labels, "<br>Code OGR : ", child_codes)
      )
      node_x <- c(0.12, rep(0.84, length(child_labels)))
      node_y <- c(
        0.5,
        if (length(child_labels) == 1) {
          0.5
        } else {
          seq(0.08, 0.92, length.out = length(child_labels))
        }
      )
      
      plotly::plot_ly(
        type = "sankey",
        arrangement = "fixed",
        node = list(
          pad = 26,
          thickness = 28,
          line = list(color = "#ffffff", width = 2),
          label = labels,
          color = node_colors,
          x = node_x,
          y = node_y,
          customdata = custom_text,
          hovertemplate = "%{customdata}<extra></extra>"
        ),
        link = list(
          source = rep(0, length(child_labels)),
          target = seq_along(child_labels),
          value = rep(1, length(child_labels)),
          color = link_colors[-1],
          hovertemplate = paste0(
            "<b>Flux de filiation</b><br>",
            parent_label,
            " -> %{target.label}<extra></extra>"
          )
        )
      ) %>%
        plotly::layout(
          title = list(text = paste("Simulation de filiation -", family_title)),
          font = list(family = "Arial", size = 14, color = "#17324d"),
          paper_bgcolor = "#fffdf8",
          plot_bgcolor = "#fffdf8",
          margin = list(l = 20, r = 20, t = 78, b = 24),
          annotations = list(
            list(
              x = 0.01,
              y = 1.12,
              xref = "paper",
              yref = "paper",
              text = paste0("Parent : <b>", parent_label, "</b>"),
              showarrow = FALSE,
              align = "left",
              font = list(size = 13, color = "#52627c")
            ),
            list(
              x = 0.01,
              y = 1.05,
              xref = "paper",
              yref = "paper",
              text = paste0("Enfants relies : <b>", length(child_labels), "</b>"),
              showarrow = FALSE,
              align = "left",
              font = list(size = 12, color = "#7a5c00")
            )
          )
        )
    })
    
    showModal(modalDialog(
      title = "Simulation de filiation",
      plotly::plotlyOutput("family_plot", height = "620px"),
      size = "l",
      easyClose = TRUE,
      footer = modalButton("Fermer")
    ))
  }
  
  save_draft_proposal <- function(draft) {
    dbg("SAVE proposal start")
    showNotification("Creation de la proposition en cours...", type = "message", duration = 3)
    dbg("refresh_token before =", isolate(refresh_token()))
    
    before <- load_proposals("edition")
    dbg_df("proposals BEFORE create", before)
    
    created_id <- create_proposal(
      draft = draft,
      stock_families = families_data(),
      phase = "supervision",
      statut = "a_superviser",
      origin_phase = "edition"
    )
    
    created_path <- attr(created_id, "path_fichier")
    
    dbg("created proposal id =", created_id)
    dbg("created proposal path =", created_path)
    dbg("created proposal direct exists =", ogre_key_exists(created_path))
    
    dbg("created proposal id =", created_id)
    
    all_files <- list_proposal_files(scope = "edition")
    dbg("proposal files after create =", paste(basename(all_files), collapse = " | "))
    
    all_raw <- load_proposals("all")
    dbg_df("load_proposals ALL after create", all_raw)
    
    edition_raw <- load_proposals("edition")
    dbg_df("load_proposals EDITION after create", edition_raw)
    
    if (nrow(all_raw) > 0) {
      dbg(
        "ALL ids =",
        paste(all_raw$id_proposition, all_raw$phase_proposition, all_raw$statut_proposition, sep = " / ", collapse = " | ")
      )
    }
    
    after <- load_proposals("edition")
    dbg_df("proposals AFTER create before refresh", after)
    
    refresh_token(isolate(refresh_token()) + 1)
    dbg("refresh_token after =", isolate(refresh_token()))
    updateTabsetPanel(session, "edition_main_tabs", selected = "propositions")
    
    selected_ref_codes(character(0))
    last_parent_code("")
    active_replay_context(NULL)
    replay_edit_mode("standard")
    session$userData$ogre_replay_context(NULL)
    reset_composition_inputs(clear_table = TRUE)
    
    updateTextAreaInput(
      session = session,
      inputId = "commentaire_edition",
      value = ""
    )
    
    showNotification("Proposition creee et deposee dans la file de supervision.", type = "message")
    dbg("SAVE proposal end")
  }
  observeEvent(input$simulate_draft, {
    show_family_simulation(draft_family())
  })
  
  observeEvent(input$create_proposal, {
    if (isTRUE(create_proposal_in_progress())) {
      showNotification("Creation deja en cours. Patientez quelques secondes.", type = "warning")
      return()
    }
    
    create_proposal_in_progress(TRUE)
    updateActionButton(session, "create_proposal", label = "Creation en cours...")
    on.exit(create_proposal_in_progress(FALSE), add = TRUE)
    on.exit(updateActionButton(session, "create_proposal", label = "Creer la proposition"), add = TRUE)
    
    draft <- draft_family()
    
    if (!nzchar(trimws(get_current_idep()))) {
      showNotification("IDEP agent non detecte.", type = "error")
      return()
    }
    
    if (is.null(draft) || !nzchar(first_non_empty(draft$code_ogr_parent, ""))) {
      showNotification("Choisissez un parent.", type = "warning")
      showModal(modalDialog(
        title = "Proposition incomplete",
        p("Vous devez choisir un parent avant de creer la proposition."),
        easyClose = TRUE,
        footer = modalButton("Fermer")
      ))
      return()
    }
    
    if (length(draft$child_labels) == 0) {
      showNotification("Choisissez au moins un enfant.", type = "warning")
      showModal(modalDialog(
        title = "Proposition incomplete",
        p("Vous devez choisir au moins un enfant avant de creer la proposition."),
        easyClose = TRUE,
        footer = modalButton("Fermer")
      ))
      return()
    }
    
    stock_families <- families_data()
    workflow_checks <- build_family_conflict_checks(
      draft = draft,
      stock_families = stock_families,
      workflow_proposals = workflow_active_proposals()
    )
    
    if (has_blocking_family_conflicts(workflow_checks)) {
      showModal(modalDialog(
        title = "Doublon ou chevauchement detecte",
        div(
          class = "conflict-modal-body",
          build_family_conflict_modal_content(workflow_checks),
          p(
            class = "conflict-modal-footer-text",
            "Corrigez la composition avant de creer une nouvelle proposition."
          )
        ),
        size = "l",
        easyClose = TRUE,
        footer = modalButton("Fermer")
      ))
      return()
    }
    
    incoherence <- selection_incoherence_report(draft)
    if (isTRUE(incoherence$has_warning)) {
      pending_incoherent_draft(draft)
      show_incoherent_selection_modal(incoherence)
      return()
    }
    
    withProgress(message = "Creation de la proposition OGRE", value = 0.2, {
      save_draft_proposal(draft)
    })
  })
  
  observeEvent(input$confirm_create_incoherent_selection, {
    draft <- pending_incoherent_draft()
    pending_incoherent_draft(NULL)
    removeModal()
    
    if (is.null(draft)) {
      showNotification("Aucune proposition en attente de confirmation.", type = "warning")
      return()
    }
    
    withProgress(message = "Creation de la proposition OGRE", value = 0.2, {
      save_draft_proposal(draft)
    })
  }, ignoreInit = TRUE)
  
  observeEvent(input$delete_proposal, {
    proposal <- selected_proposal()
    
    if (is.null(proposal)) {
      showNotification("Selectionnez une proposition a supprimer.", type = "warning")
      return()
    }
    
    showModal(modalDialog(
      title = "Supprimer la proposition",
      p("Voulez-vous vraiment supprimer cette proposition du workflow ?"),
      p(paste("ID :", proposal$id_proposition[1])),
      p(paste("Parent :", proposal$libelle_parent[1])),
      easyClose = TRUE,
      footer = tagList(
        modalButton("Annuler"),
        actionButton("confirm_delete_proposal", "Supprimer", class = "btn-danger")
      )
    ))
  })
  
  observeEvent(input$confirm_delete_proposal, {
    proposal <- selected_proposal()
    if (is.null(proposal)) {
      removeModal()
      return()
    }
    
    delete_proposal_by_id(proposal$id_proposition[1], phase = proposal$phase_proposition[1])
    removeModal()
    refresh_token(refresh_token() + 1)
    showNotification("Proposition supprimee.", type = "message")
  })
}