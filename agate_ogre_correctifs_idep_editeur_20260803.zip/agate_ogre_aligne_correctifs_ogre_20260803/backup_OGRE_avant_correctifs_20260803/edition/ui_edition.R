ogre_edition_ui <- function() {
  helper_details <- function(summary_text, ...) {
    tags$details(
      class = "helper-details",
      tags$summary(
        span(class = "info-dot info-dot-inline", "i"),
        span(summary_text)
      ),
      div(class = "helper-details-body", ...)
    )
  }
  
  inline_info <- function(text) {
    tags$span(
      class = "inline-info",
      tabindex = "0",
      `data-tooltip` = text,
      `aria-label` = text,
      "i"
    )
  }
  
  label_with_info <- function(label, info_text) {
    tags$span(
      class = "label-with-info",
      span(label),
      inline_info(info_text)
    )
  }
  
  tagList(
    tags$head(
      tags$style(HTML("
body.theme-dark div.dt-button-collection,
.theme-dark div.dt-button-collection {
  background: #111827 !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  box-shadow: 0 18px 45px rgba(0, 0, 0, 0.45) !important;
  padding: 6px !important;
}

body.theme-dark div.dt-button-collection button.dt-button,
body.theme-dark div.dt-button-collection a.dt-button,
.theme-dark div.dt-button-collection button.dt-button,
.theme-dark div.dt-button-collection a.dt-button {
  background: transparent !important;
  color: #e5e7eb !important;
  border: 0 !important;
  box-shadow: none !important;
  text-align: left !important;
  padding: 8px 14px !important;
  width: 100% !important;
}

body.theme-dark div.dt-button-collection button.dt-button:hover,
body.theme-dark div.dt-button-collection a.dt-button:hover,
.theme-dark div.dt-button-collection button.dt-button:hover,
.theme-dark div.dt-button-collection a.dt-button:hover {
  background: #1f2937 !important;
  color: #ffffff !important;
}

body.theme-dark div.dt-button-collection button.dt-button.active,
body.theme-dark div.dt-button-collection a.dt-button.active,
.theme-dark div.dt-button-collection button.dt-button.active,
.theme-dark div.dt-button-collection a.dt-button.active {
  background: #172554 !important;
  color: #ffffff !important;
}

body.theme-dark div.dt-button-collection button.dt-button.active:after,
body.theme-dark div.dt-button-collection a.dt-button.active:after,
.theme-dark div.dt-button-collection button.dt-button.active:after,
.theme-dark div.dt-button-collection a.dt-button.active:after {
  color: #93c5fd !important;
}

body.theme-dark div.dt-button-background,
.theme-dark div.dt-button-background {
  background: rgba(2, 6, 23, 0.45) !important;
}
"))
      ,
      tags$style(HTML("
/* =========================================================
   OGRE EDITION - BASE LIGHT
   ========================================================= */

.ogre-edition-page {
  background: linear-gradient(180deg, #f5f7fb 0%, #eef2f9 100%);
  padding: 16px 0 24px;
}

.app-card {
  background: #ffffff;
  border: 1px solid #d9e1ef;
  border-radius: 18px;
  box-shadow: 0 10px 24px rgba(23, 43, 77, 0.08);
  padding: 18px;
  margin-bottom: 18px;
}

.card-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  flex-wrap: wrap;
  margin-bottom: 8px;
}

.card-head h4 {
  margin: 0;
}

.card-copy {
  font-size: 13px;
  line-height: 1.55;
  color: #60708f;
  margin-bottom: 12px;
}

.card-badge {
  display: inline-flex;
  align-items: center;
  padding: 5px 10px;
  border-radius: 999px;
  border: 1px solid #d6e1ef;
  background: #f5f8fc;
  color: #35506b;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.03em;
}

.section-kicker {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: #5f7793;
  margin-bottom: 6px;
}

.guide-step {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin-top: 12px;
}

.guide-step-index {
  width: 28px;
  height: 28px;
  border-radius: 999px;
  background: #17324d;
  color: #ffffff;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  font-weight: 700;
  flex: 0 0 auto;
}

.guide-step-title {
  font-size: 14px;
  font-weight: 700;
  color: #17324d;
  margin-bottom: 2px;
}

.guide-step-copy {
  font-size: 13px;
  line-height: 1.5;
  color: #5a6c83;
}

.info-dot {
  width: 20px;
  height: 20px;
  border-radius: 999px;
  background: #17324d;
  color: #ffffff;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 700;
  flex: 0 0 auto;
  margin-top: 1px;
}

.info-dot-inline {
  margin-top: 0;
}

.label-with-info {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.inline-info {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  border-radius: 999px;
  background: #17324d;
  color: #ffffff;
  font-size: 11px;
  font-weight: 700;
  line-height: 1;
  cursor: help;
}

.inline-info::after {
  content: attr(data-tooltip);
  position: absolute;
  left: 50%;
  top: calc(100% + 10px);
  transform: translateX(-50%);
  min-width: 220px;
  max-width: 280px;
  padding: 10px 12px;
  border-radius: 12px;
  background: #17324d;
  color: #ffffff;
  font-size: 12px;
  line-height: 1.45;
  text-transform: none;
  letter-spacing: normal;
  white-space: normal;
  box-shadow: 0 14px 26px rgba(23, 43, 77, 0.18);
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  transition: opacity 0.12s ease, transform 0.12s ease;
  z-index: 20;
}

.inline-info::before {
  content: '';
  position: absolute;
  left: 50%;
  top: calc(100% + 4px);
  transform: translateX(-50%);
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  border-bottom: 6px solid #17324d;
  opacity: 0;
  visibility: hidden;
  transition: opacity 0.12s ease;
  z-index: 21;
}

.inline-info:hover::after,
.inline-info:hover::before,
.inline-info:focus::after,
.inline-info:focus::before {
  opacity: 1;
  visibility: visible;
}

.inline-info:focus {
  outline: 2px solid #8cb6dd;
  outline-offset: 2px;
}

.helper-details {
  border: 1px solid #dce5f1;
  border-radius: 14px;
  background: #fcfdff;
  padding: 0 12px;
  margin-top: 10px;
}

.helper-details summary {
  list-style: none;
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 12px 0;
  font-size: 13px;
  font-weight: 700;
  color: #17324d;
}

.helper-details summary::-webkit-details-marker {
  display: none;
}

.helper-details-body {
  padding-bottom: 12px;
}

.helper-details-body p {
  margin: 0 0 8px;
  font-size: 13px;
  line-height: 1.55;
  color: #5a6c83;
}

.helper-details-body p:last-child {
  margin-bottom: 0;
}

.action-row {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  margin-top: 8px;
}

.action-help {
  margin-top: 10px;
  font-size: 12px;
  line-height: 1.5;
  color: #687993;
}

.tab-intro {
  margin-bottom: 12px;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: 8px;
  flex-wrap: wrap;
  color: #5f7793;
  font-size: 12px;
}

.tab-intro-copy {
  line-height: 1.5;
}

.preview-table {
  margin-top: 10px;
}

.preview-table th {
  background: #f4f7fc;
}

/* Sous-onglets Resume / Preconisations */
.subpanel-tabs > .nav {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  border-bottom: none;
  margin: 4px 0 14px;
}

.subpanel-tabs > .nav > li {
  float: none;
  margin: 0;
}

.subpanel-tabs > .nav > li > a {
  border: 1px solid #d6e1ef;
  border-radius: 999px;
  background: #f7f9fc;
  color: #35506b;
  font-size: 12px;
  font-weight: 700;
  padding: 8px 14px;
}

.subpanel-tabs > .nav > li > a:hover {
  background: #eef3f9;
  border-color: #c4d4e8;
}

.subpanel-tabs > .nav > li.active > a,
.subpanel-tabs > .nav > li.active > a:hover,
.subpanel-tabs > .nav > li.active > a:focus {
  background: #17324d;
  border-color: #17324d;
  color: #ffffff;
}

.subpanel-content {
  min-height: 180px;
}

/* Recommandations */
.reco-box {
  background: linear-gradient(160deg, #f8fbff 0%, #eef4fb 100%);
  border: 1px solid #d8e2f0;
  border-radius: 14px;
  padding: 14px;
}

.reco-line {
  color: #30445f;
  margin-bottom: 8px;
}

.reco-label {
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: #60708f;
  margin-bottom: 6px;
}

.reco-value {
  font-weight: 700;
  color: #15314b;
}

.reco-chip {
  display: inline-block;
  background: #ffffff;
  border: 1px solid #cfdae9;
  border-radius: 999px;
  padding: 6px 10px;
  margin: 0 8px 8px 0;
  color: #28415c;
}

.reco-detail-wrap {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.reco-summary-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
}

.reco-summary-card {
  background: linear-gradient(160deg, #fff9ef 0%, #fff3dc 100%);
  border: 1px solid #f3ddab;
  border-radius: 14px;
  padding: 12px;
}

.reco-summary-card.alt {
  background: linear-gradient(160deg, #eef8ff 0%, #e0f0ff 100%);
  border-color: #c9def6;
}

.reco-summary-label {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: #7c6a37;
  margin-bottom: 6px;
}

.reco-summary-card.alt .reco-summary-label {
  color: #41617f;
}

.reco-summary-value {
  font-size: 24px;
  font-weight: 700;
  color: #3d2f11;
  line-height: 1.05;
  margin-bottom: 4px;
}

.reco-summary-card.alt .reco-summary-value {
  color: #17324d;
}

.reco-summary-help {
  font-size: 12px;
  color: #6f6658;
}

.reco-section {
  background: #fbfcfe;
  border: 1px solid #dbe4f0;
  border-radius: 16px;
  padding: 14px;
}

.reco-section-title {
  font-size: 15px;
  font-weight: 700;
  color: #17324d;
  margin-bottom: 6px;
}

.reco-section-help {
  font-size: 12px;
  color: #6d7d94;
  margin-bottom: 12px;
}

.reco-badge {
  display: inline-block;
  border-radius: 999px;
  padding: 4px 10px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.03em;
}

.reco-badge-parent {
  background: #dff7ea;
  color: #146c43;
}

.reco-badge-child {
  background: #fff0d9;
  color: #a75f00;
}

.reco-badge-neutral {
  background: #e9eef5;
  color: #405469;
}

.reco-rome-stack {
  display: flex;
  flex-direction: column;
  gap: 12px;
  max-height: 420px;
  overflow-y: auto;
  padding-right: 4px;
}

.reco-rome-card {
  background: #ffffff;
  border: 1px solid #d6e0ed;
  border-radius: 16px;
  padding: 14px;
}

.reco-rome-head {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  align-items: flex-start;
  margin-bottom: 10px;
}

.reco-rome-title {
  font-size: 16px;
  font-weight: 700;
  color: #16324a;
}

.reco-rome-subtitle {
  font-size: 12px;
  color: #6c7b8d;
  margin-top: 2px;
}

.reco-rome-metrics {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.reco-rome-metric {
  background: #f4f7fc;
  border: 1px solid #dbe4f0;
  border-radius: 999px;
  padding: 5px 10px;
  font-size: 12px;
  color: #29435d;
}

.reco-rome-block {
  margin-top: 10px;
}

.reco-rome-block-title {
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: #60708f;
  margin-bottom: 6px;
}

.reco-ref-chip {
  display: inline-block;
  background: #f4f7fc;
  border: 1px solid #d7e1ee;
  border-radius: 12px;
  padding: 6px 8px;
  margin: 0 6px 6px 0;
  font-size: 12px;
  color: #29435d;
  vertical-align: top;
}

.reco-ref-chip.is-empty {
  background: #f8fafc;
  color: #8491a3;
}

.reco-inline {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 14px;
  margin: 12px 0 16px;
  background: linear-gradient(160deg, #f8fbff 0%, #eef4fb 100%);
  border: 1px solid #d8e2f0;
  border-radius: 14px;
}

.reco-inline-copy {
  font-size: 13px;
  color: #28415c;
  line-height: 1.45;
}

.reco-inline-empty,
.reco-note-italic {
  font-size: 12px;
  color: #6d7d94;
  font-style: italic;
}

.reco-ref-chip-button {
  display: inline-block;
  background: #ffffff;
  border: 1px dashed #c7d5e7;
  border-radius: 12px;
  padding: 6px 10px;
  margin: 0 6px 6px 0;
  font-size: 12px;
  color: #17324d;
  vertical-align: top;
  cursor: pointer;
  transition: background 0.15s ease, border-color 0.15s ease, transform 0.15s ease;
}

.reco-ref-chip-button:hover,
.reco-ref-chip-button:focus {
  background: #eef4fb;
  border-color: #8da8c5;
  transform: translateY(-1px);
  outline: none;
}

.reco-ref-chip-button.is-parent {
  background: #eef9f2;
  border-style: solid;
  border-color: #b9e3c8;
  color: #146c43;
}

.reco-ref-chip-button.is-child {
  background: #fff7eb;
  border-color: #f1d19a;
  color: #a75f00;
}

/* Responsive */
@media (max-width: 1200px) {
  .reco-summary-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 991px) {
  .card-head {
    align-items: flex-start;
  }
}

@media (max-width: 700px) {
  .reco-summary-grid {
    grid-template-columns: 1fr;
  }
}

/* =========================================================
   OGRE EDITION - DARK MODE
   ========================================================= */

body.theme-dark .ogre-edition-page {
  background: linear-gradient(180deg, #0f172a 0%, #020617 100%);
  color: #f8fafc;
}

body.theme-dark .ogre-edition-page .app-card,
body.theme-dark .ogre-edition-page .helper-details,
body.theme-dark .ogre-edition-page .reco-box,
body.theme-dark .ogre-edition-page .reco-inline,
body.theme-dark .ogre-edition-page .reco-section,
body.theme-dark .ogre-edition-page .reco-summary-card,
body.theme-dark .ogre-edition-page .reco-summary-card.alt,
body.theme-dark .ogre-edition-page .reco-rome-card,
body.theme-dark .ogre-edition-page .reco-ref-chip,
body.theme-dark .ogre-edition-page .reco-rome-metric {
  background: #1e293b;
  border-color: #64748b;
  color: #f8fafc;
  box-shadow: 0 12px 24px rgba(0, 0, 0, 0.35);
}

body.theme-dark .ogre-edition-page .card-head h4,
body.theme-dark .ogre-edition-page .guide-step-title,
body.theme-dark .ogre-edition-page .helper-details summary,
body.theme-dark .ogre-edition-page .reco-section-title,
body.theme-dark .ogre-edition-page .reco-summary-value,
body.theme-dark .ogre-edition-page .reco-rome-title,
body.theme-dark .ogre-edition-page label,
body.theme-dark .ogre-edition-page .control-label {
  color: #ffffff;
}

body.theme-dark .ogre-edition-page .card-copy,
body.theme-dark .ogre-edition-page .guide-step-copy,
body.theme-dark .ogre-edition-page .helper-details-body p,
body.theme-dark .ogre-edition-page .action-help,
body.theme-dark .ogre-edition-page .tab-intro,
body.theme-dark .ogre-edition-page .tab-intro-copy,
body.theme-dark .ogre-edition-page .reco-inline-copy,
body.theme-dark .ogre-edition-page .reco-inline-empty,
body.theme-dark .ogre-edition-page .reco-note-italic,
body.theme-dark .ogre-edition-page .reco-line,
body.theme-dark .ogre-edition-page .reco-label,
body.theme-dark .ogre-edition-page .reco-summary-help,
body.theme-dark .ogre-edition-page .reco-section-help,
body.theme-dark .ogre-edition-page .reco-rome-subtitle,
body.theme-dark .ogre-edition-page .reco-rome-block-title {
  color: #e2e8f0;
}

body.theme-dark .ogre-edition-page .section-kicker,
body.theme-dark .ogre-edition-page .reco-label {
  color: #93c5fd;
}

body.theme-dark .ogre-edition-page .card-badge,
body.theme-dark .ogre-edition-page .reco-chip,
body.theme-dark .ogre-edition-page .reco-ref-chip-button,
body.theme-dark .ogre-edition-page .reco-badge-neutral {
  background: #020617;
  border-color: #94a3b8;
  color: #f8fafc;
}

body.theme-dark .ogre-edition-page .reco-ref-chip-button.is-parent {
  background: #133c2b;
  border-color: #1f6d4a;
  color: #bbf7d0;
}

body.theme-dark .ogre-edition-page .reco-ref-chip-button.is-child {
  background: #422006;
  border-color: #a16207;
  color: #fde68a;
}

body.theme-dark .ogre-edition-page .info-dot,
body.theme-dark .ogre-edition-page .inline-info {
  background: #2563eb;
  color: #ffffff;
}

body.theme-dark .ogre-edition-page .inline-info::after {
  background: #020617;
  color: #ffffff;
  border: 1px solid #94a3b8;
}

body.theme-dark .ogre-edition-page .inline-info::before {
  border-bottom-color: #94a3b8;
}

/* Onglets principaux */
body.theme-dark .ogre-edition-page > .row .nav-tabs > li > a,
body.theme-dark .ogre-edition-page .nav-tabs > li > a {
  background: #0f172a !important;
  border: 1px solid #64748b !important;
  color: #f8fafc !important;
}

body.theme-dark .ogre-edition-page > .row .nav-tabs > li > a:hover,
body.theme-dark .ogre-edition-page .nav-tabs > li > a:hover {
  background: #1e293b !important;
  border-color: #94a3b8 !important;
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page > .row .nav-tabs > li.active > a,
body.theme-dark .ogre-edition-page > .row .nav-tabs > li.active > a:hover,
body.theme-dark .ogre-edition-page > .row .nav-tabs > li.active > a:focus,
body.theme-dark .ogre-edition-page .nav-tabs > li.active > a,
body.theme-dark .ogre-edition-page .nav-tabs > li.active > a:hover,
body.theme-dark .ogre-edition-page .nav-tabs > li.active > a:focus {
  background: #2563eb !important;
  border-color: #60a5fa !important;
  color: #ffffff !important;
}

/* Sous-onglets Resume / Preconisations */
body.theme-dark .ogre-edition-page .subpanel-tabs > .nav > li > a {
  background: #020617 !important;
  border-color: #64748b !important;
  color: #f8fafc !important;
}

body.theme-dark .ogre-edition-page .subpanel-tabs > .nav > li > a:hover {
  background: #1e40af !important;
  border-color: #60a5fa !important;
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page .subpanel-tabs > .nav > li.active > a,
body.theme-dark .ogre-edition-page .subpanel-tabs > .nav > li.active > a:hover,
body.theme-dark .ogre-edition-page .subpanel-tabs > .nav > li.active > a:focus {
  background: #2563eb !important;
  border-color: #60a5fa !important;
  color: #ffffff !important;
}

/* =========================================================
   DARK MODE - SELECTIZE
   ========================================================= */

body.theme-dark .ogre-edition-page .selectize-control span,
body.theme-dark .ogre-edition-page .dataTables_wrapper span,
body.theme-dark .ogre-edition-page .nav-tabs span {
  color: inherit !important;
}

body.theme-dark .ogre-edition-page .form-control,
body.theme-dark .ogre-edition-page .selectize-control.single .selectize-input,
body.theme-dark .ogre-edition-page .selectize-control.multi .selectize-input,
body.theme-dark .ogre-edition-page .selectize-dropdown,
body.theme-dark .ogre-edition-page .selectize-dropdown-content {
  background: #020617 !important;
  color: #ffffff !important;
  border-color: #94a3b8 !important;
  box-shadow: none !important;
}

body.theme-dark .ogre-edition-page .selectize-input input {
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page .selectize-input input::placeholder {
  color: #cbd5e1 !important;
}

body.theme-dark .ogre-edition-page .selectize-control.single .selectize-input > div,
body.theme-dark .ogre-edition-page .selectize-control.single .selectize-input .item {
  color: #ffffff !important;
  background: transparent !important;
}

body.theme-dark .ogre-edition-page .selectize-control.multi .selectize-input > div,
body.theme-dark .ogre-edition-page .selectize-control.multi .selectize-input .item {
  background: #1d4ed8 !important;
  border: 1px solid #60a5fa !important;
  color: #ffffff !important;
  border-radius: 6px !important;
  padding: 3px 7px !important;
  margin: 2px 4px 2px 0 !important;
  text-shadow: none !important;
}

body.theme-dark .ogre-edition-page .selectize-dropdown .option {
  background: #020617 !important;
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page .selectize-dropdown .option.active,
body.theme-dark .ogre-edition-page .selectize-dropdown .option:hover {
  background: #2563eb !important;
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page .selectize-control.single .selectize-input:after {
  border-color: #ffffff transparent transparent transparent !important;
}

body.theme-dark .ogre-edition-page .selectize-control.single .selectize-input.dropdown-active:after {
  border-color: transparent transparent #ffffff transparent !important;
}

body.theme-dark .ogre-edition-page .selectize-input.focus,
body.theme-dark .ogre-edition-page .form-control:focus {
  border-color: #60a5fa !important;
  box-shadow: 0 0 0 2px rgba(96, 165, 250, 0.35) !important;
}

/* =========================================================
   DARK MODE - DATATABLES
   ========================================================= */

body.theme-dark .ogre-edition-page table.dataTable,
body.theme-dark .ogre-edition-page table.dataTable thead th,
body.theme-dark .ogre-edition-page table.dataTable thead td {
  background: #020617 !important;
  color: #ffffff !important;
  border-color: #64748b !important;
}

body.theme-dark .ogre-edition-page table.dataTable tbody td {
  background: #020617 !important;
  color: #ffffff !important;
  border-color: #1e293b !important;
}

body.theme-dark .ogre-edition-page table.dataTable tbody tr:nth-child(odd) td {
  background: #111827 !important;
}

body.theme-dark .ogre-edition-page table.dataTable tbody tr:nth-child(even) td {
  background: #020617 !important;
}

body.theme-dark .ogre-edition-page table.dataTable tbody tr:hover td {
  background: #1e293b !important;
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page table.dataTable tbody tr.selected td,
body.theme-dark .ogre-edition-page table.dataTable tbody tr.selected:hover td {
  background: #2563eb !important;
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page table.dataTable thead input,
body.theme-dark .ogre-edition-page table.dataTable thead select,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_filter input,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_length select {
  background: #020617 !important;
  color: #ffffff !important;
  border: 1px solid #94a3b8 !important;
}

body.theme-dark .ogre-edition-page table.dataTable thead input::placeholder {
  color: #cbd5e1 !important;
}

body.theme-dark .ogre-edition-page .dataTables_wrapper,
body.theme-dark .ogre-edition-page .dataTables_wrapper label,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_info,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_paginate,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_length,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_filter {
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page .preview-table th {
  background: #1e293b !important;
  color: #ffffff !important;
}

/* =========================================================
   DARK MODE - BOUTONS
   ========================================================= */

body.theme-dark .ogre-edition-page .btn,
body.theme-dark .ogre-edition-page .btn-default {
  background: #1e293b !important;
  border-color: #64748b !important;
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page .btn:hover,
body.theme-dark .ogre-edition-page .btn-default:hover {
  background: #334155 !important;
  border-color: #94a3b8 !important;
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page .btn-primary {
  background: #2563eb !important;
  border-color: #60a5fa !important;
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page .btn-primary:hover {
  background: #1d4ed8 !important;
  border-color: #93c5fd !important;
  color: #ffffff !important;
}

/* =========================================================
   DARK MODE - MODALES
   ========================================================= */

body.theme-dark .modal-content {
  background: #0f172a;
  color: #f8fafc;
  border: 1px solid #64748b;
}

body.theme-dark .modal-header,
body.theme-dark .modal-footer {
  background: #1e293b;
  border-color: #64748b;
  color: #ffffff;
}

body.theme-dark .modal-title {
  color: #ffffff;
}

body.theme-dark .modal-body {
  background: #0f172a;
  color: #f8fafc;
}

body.theme-dark .modal-body .reco-section,
body.theme-dark .modal-body .reco-rome-card,
body.theme-dark .modal-body .reco-inline,
body.theme-dark .modal-body .reco-summary-card,
body.theme-dark .modal-body .reco-summary-card.alt {
  background: #1e293b;
  border-color: #64748b;
  color: #f8fafc;
}

body.theme-dark .modal-body .reco-section-title,
body.theme-dark .modal-body .reco-rome-title,
body.theme-dark .modal-body .reco-summary-value {
  color: #ffffff;
}

body.theme-dark .modal-body .reco-section-help,
body.theme-dark .modal-body .reco-rome-subtitle,
body.theme-dark .modal-body .reco-summary-help,
body.theme-dark .modal-body .reco-inline-copy,
body.theme-dark .modal-body .reco-inline-empty,
body.theme-dark .modal-body .reco-note-italic,
body.theme-dark .modal-body .reco-rome-block-title {
  color: #e2e8f0;
}

body.theme-dark .modal-body .reco-summary-card {
  background: #312e1f;
  border-color: #facc15;
}

body.theme-dark .modal-body .reco-summary-card.alt {
  background: #172554;
  border-color: #60a5fa;
}

body.theme-dark .modal-body .reco-summary-label {
  color: #fde68a;
}

body.theme-dark .modal-body .reco-summary-card.alt .reco-summary-label {
  color: #bfdbfe;
}

body.theme-dark .modal-body .reco-ref-chip,
body.theme-dark .modal-body .reco-ref-chip-button,
body.theme-dark .modal-body .reco-rome-metric {
  background: #020617;
  border-color: #94a3b8;
  color: #ffffff;
}

body.theme-dark .modal-body .reco-ref-chip-button.is-parent {
  background: #133c2b;
  border-color: #1f6d4a;
  color: #bbf7d0;
}

body.theme-dark .modal-body .reco-ref-chip-button.is-child {
  background: #422006;
  border-color: #a16207;
  color: #fde68a;
}

body.theme-dark .modal-body .reco-badge,
body.theme-dark .modal-body .reco-badge-neutral {
  background: #020617;
  color: #ffffff;
  border: 1px solid #94a3b8;
}

body.theme-dark .modal-body table.dataTable,
body.theme-dark .modal-body table.dataTable thead th,
body.theme-dark .modal-body table.dataTable tbody td,
body.theme-dark .modal-body table.dataTable tbody tr {
  background: #020617 !important;
  color: #f8fafc !important;
  border-color: #64748b !important;
}

body.theme-dark .modal-body table.dataTable tbody tr:hover,
body.theme-dark .modal-body table.dataTable tbody tr:hover td {
  background: #1e293b !important;
  color: #ffffff !important;
}

body.theme-dark .modal-body .dataTables_wrapper,
body.theme-dark .modal-body .dataTables_wrapper label,
body.theme-dark .modal-body .dataTables_wrapper .dataTables_info,
body.theme-dark .modal-body .dataTables_wrapper .dataTables_paginate,
body.theme-dark .modal-body .dataTables_wrapper .dataTables_length,
body.theme-dark .modal-body .dataTables_wrapper .dataTables_filter {
  color: #f8fafc !important;
}

body.theme-dark .modal-body .dataTables_wrapper select,
body.theme-dark .modal-body .dataTables_wrapper input {
  background: #020617 !important;
  color: #ffffff !important;
  border: 1px solid #94a3b8 !important;
}

body.theme-dark .modal-body .paginate_button,
body.theme-dark .modal-body .paginate_button a {
  background: #020617 !important;
  color: #ffffff !important;
  border-color: #64748b !important;
}

body.theme-dark .modal-body .paginate_button.active a {
  background: #2563eb !important;
  color: #ffffff !important;
  border-color: #60a5fa !important;
}

body.theme-dark .modal-body .dataTables_scrollBody,
body.theme-dark .modal-body .dataTables_scrollHead {
  background: #020617 !important;
  border-color: #64748b !important;
}

/* Scrollbars dark */
body.theme-dark .modal-body .dataTables_scrollBody::-webkit-scrollbar,
body.theme-dark .modal-body .reco-rome-stack::-webkit-scrollbar,
body.theme-dark .ogre-edition-page .dataTables_scrollBody::-webkit-scrollbar,
body.theme-dark .ogre-edition-page .reco-rome-stack::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}

body.theme-dark .modal-body .dataTables_scrollBody::-webkit-scrollbar-thumb,
body.theme-dark .modal-body .reco-rome-stack::-webkit-scrollbar-thumb,
body.theme-dark .ogre-edition-page .dataTables_scrollBody::-webkit-scrollbar-thumb,
body.theme-dark .ogre-edition-page .reco-rome-stack::-webkit-scrollbar-thumb {
  background: #64748b;
  border-radius: 999px;
}

body.theme-dark .modal-body .dataTables_scrollBody::-webkit-scrollbar-track,
body.theme-dark .modal-body .reco-rome-stack::-webkit-scrollbar-track,
body.theme-dark .ogre-edition-page .dataTables_scrollBody::-webkit-scrollbar-track,
body.theme-dark .ogre-edition-page .reco-rome-stack::-webkit-scrollbar-track {
  background: #020617;
}

/* =========================================================
   DARK MODE - DATATABLES
   Important : ne pas écraser les couleurs inline DT::formatStyle()
   ========================================================= */

body.theme-dark .ogre-edition-page table.dataTable,
body.theme-dark .ogre-edition-page table.dataTable thead th,
body.theme-dark .ogre-edition-page table.dataTable thead td {
  background: #020617 !important;
  color: #ffffff !important;
  border-color: #64748b !important;
}

/* Ne jamais mettre background-color ici, sinon ça écrase formatStyle() */
body.theme-dark .ogre-edition-page table.dataTable tbody td {
  color: #ffffff;
  border-color: #1e293b !important;
}

/* Alternance uniquement sur les cellules qui n'ont PAS de style inline */
body.theme-dark .ogre-edition-page table.dataTable tbody tr:nth-child(odd) td:not([style]) {
  background: #111827;
}

body.theme-dark .ogre-edition-page table.dataTable tbody tr:nth-child(even) td:not([style]) {
  background: #020617;
}

body.theme-dark .ogre-edition-page table.dataTable tbody tr:hover td:not([style]) {
  background: #1e293b;
  color: #ffffff;
}

/* Sélection : prioritaire */
body.theme-dark .ogre-edition-page table.dataTable tbody tr.selected td,
body.theme-dark .ogre-edition-page table.dataTable tbody tr.selected:hover td {
  background: #2563eb !important;
  color: #ffffff !important;
}

/* Inputs de filtre / recherche */
body.theme-dark .ogre-edition-page table.dataTable thead input,
body.theme-dark .ogre-edition-page table.dataTable thead select,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_filter input,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_length select {
  background: #020617 !important;
  color: #ffffff !important;
  border: 1px solid #94a3b8 !important;
}

body.theme-dark .ogre-edition-page table.dataTable thead input::placeholder {
  color: #cbd5e1 !important;
}

body.theme-dark .ogre-edition-page .dataTables_wrapper,
body.theme-dark .ogre-edition-page .dataTables_wrapper label,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_info,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_paginate,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_length,
body.theme-dark .ogre-edition-page .dataTables_wrapper .dataTables_filter {
  color: #ffffff !important;
}

body.theme-dark .ogre-edition-page .preview-table th {
  background: #1e293b !important;
  color: #ffffff !important;
}

/* =========================================================
   BADGES METIER - Propositions
   ========================================================= */

.ogre-badge {
  display: inline-block;
  border-radius: 999px;
  padding: 4px 10px;
  font-size: 12px;
  font-weight: 800;
  line-height: 1.2;
  white-space: nowrap;
}

/* Statuts */
.ogre-status-a-superviser {
  background: #fce7f3;
  color: #9d174d;
  border: 1px solid #f9a8d4;
}

.ogre-status-en-cours {
  background: #dbeafe;
  color: #1d4ed8;
  border: 1px solid #93c5fd;
}

.ogre-status-rejetes {
  background: #fee2e2;
  color: #991b1b;
  border: 1px solid #fca5a5;
}

.ogre-status-a-valider {
  background: #dcfce7;
  color: #166534;
  border: 1px solid #86efac;
}

.ogre-status-valides {
  background: #ccfbf1;
  color: #0f766e;
  border: 1px solid #5eead4;
}

/* Types */
.ogre-type-creation {
  background: #dbeafe;
  color: #075985;
  border: 1px solid #93c5fd;
}

.ogre-type-modification {
  background: #fef3c7;
  color: #92400e;
  border: 1px solid #fcd34d;
}

/* Dark mode : badges plus contrastés */
body.theme-dark .ogre-status-a-superviser {
  background: #4a1f2a;
  color: #fecdd3;
  border-color: #fb7185;
}

body.theme-dark .ogre-status-en-cours {
  background: #172554;
  color: #bfdbfe;
  border-color: #60a5fa;
}

body.theme-dark .ogre-status-rejetes {
  background: #451a1a;
  color: #fecaca;
  border-color: #f87171;
}

body.theme-dark .ogre-status-a-valider {
  background: #123524;
  color: #bbf7d0;
  border-color: #4ade80;
}

body.theme-dark .ogre-status-valides {
  background: #064e3b;
  color: #a7f3d0;
  border-color: #2dd4bf;
}

body.theme-dark .ogre-type-creation {
  background: #102a43;
  color: #bfdbfe;
  border-color: #60a5fa;
}

body.theme-dark .ogre-type-modification {
  background: #3b2f13;
  color: #fde68a;
  border-color: #facc15;
}
/* =========================================================
   MODALE CONFLITS / DOUBLONS
   ========================================================= */

.conflict-modal-body {
  max-height: 68vh;
  overflow-y: auto;
  padding-right: 4px;
}

.conflict-table-wrap {
  width: 100%;
  max-width: 100%;
  overflow-x: auto;
  margin: 12px 0 18px;
  border: 1px solid #d6e1ef;
  border-radius: 12px;
}

.conflict-table {
  width: 100%;
  min-width: 760px;
  margin-bottom: 0 !important;
  table-layout: fixed;
  background: #ffffff;
}

.conflict-table th,
.conflict-table td {
  padding: 10px 12px !important;
  vertical-align: middle !important;
  white-space: normal !important;
  word-break: break-word;
  overflow-wrap: anywhere;
  font-size: 13px;
  line-height: 1.35;
}

.conflict-table th:nth-child(1),
.conflict-table td:nth-child(1) {
  width: 90px;
}

.conflict-table th:nth-child(2),
.conflict-table td:nth-child(2) {
  width: 190px;
}

.conflict-table th:nth-child(3),
.conflict-table td:nth-child(3) {
  width: 340px;
}

.conflict-table th:nth-child(4),
.conflict-table td:nth-child(4) {
  width: 170px;
}

.conflict-table thead th {
  background: #f4f7fc;
  color: #17324d;
  border-bottom: 1px solid #d6e1ef !important;
  font-weight: 800;
}

.conflict-table tbody td {
  background: #ffffff;
  color: #17324d;
  border-top: 1px solid #e3eaf4 !important;
}

.conflict-id {
  font-family: monospace;
  font-size: 12px;
  word-break: break-all;
}

.conflict-modal-footer-text {
  margin-top: 8px;
  margin-bottom: 0;
  font-weight: 600;
}

/* Dark mode */
body.theme-dark .conflict-table-wrap {
  border-color: #64748b;
  background: #020617;
}

body.theme-dark .conflict-table {
  background: #020617;
}

body.theme-dark .conflict-table thead th {
  background: #111827 !important;
  color: #ffffff !important;
  border-color: #64748b !important;
}

body.theme-dark .conflict-table tbody td {
  background: #020617 !important;
  color: #ffffff !important;
  border-color: #334155 !important;
}

body.theme-dark .conflict-table tbody tr:nth-child(even) td {
  background: #0f172a !important;
}

body.theme-dark .conflict-id {
  color: #bfdbfe;
}
/* =========================================================
   DARK MODE - TABLEAUX HTML simples dans les cards/modales
   Ex: Contenu proposé, conflits, preview famille
   ========================================================= */

body.theme-dark .ogre-edition-page .app-card table,
body.theme-dark .ogre-edition-page .modal-body table,
body.theme-dark .modal-body table {
  width: 100%;
  background: #020617 !important;
  color: #ffffff !important;
  border-collapse: collapse;
}

body.theme-dark .ogre-edition-page .app-card table th,
body.theme-dark .ogre-edition-page .modal-body table th,
body.theme-dark .modal-body table th {
  background: #1e293b !important;
  color: #ffffff !important;
  border: 1px solid #94a3b8 !important;
  padding: 10px 12px;
}

body.theme-dark .ogre-edition-page .app-card table td,
body.theme-dark .ogre-edition-page .modal-body table td,
body.theme-dark .modal-body table td {
  background: #0f172a !important;
  color: #ffffff !important;
  border: 1px solid #334155 !important;
  padding: 10px 12px;
}

body.theme-dark .ogre-edition-page .app-card table tbody tr:nth-child(odd) td,
body.theme-dark .ogre-edition-page .modal-body table tbody tr:nth-child(odd) td,
body.theme-dark .modal-body table tbody tr:nth-child(odd) td {
  background: #111827 !important;
}

body.theme-dark .ogre-edition-page .app-card table tbody tr:nth-child(even) td,
body.theme-dark .ogre-edition-page .modal-body table tbody tr:nth-child(even) td,
body.theme-dark .modal-body table tbody tr:nth-child(even) td {
  background: #020617 !important;
}

body.theme-dark .ogre-edition-page .app-card table tbody tr:hover td,
body.theme-dark .ogre-edition-page .modal-body table tbody tr:hover td,
body.theme-dark .modal-body table tbody tr:hover td {
  background: #1e293b !important;
}


.replay-context-card {
  border: 1px solid #f59e0b;
  border-left: 5px solid #f59e0b;
  border-radius: 16px;
  background: #fffbeb;
  padding: 14px;
  margin: 14px 0 16px;
}

.replay-kicker {
  font-size: 10px;
  font-weight: 800;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: #92400e;
  margin-bottom: 4px;
}

.replay-title {
  font-size: 15px;
  font-weight: 800;
  color: #78350f;
  margin-bottom: 6px;
}

.replay-copy {
  font-size: 12px;
  line-height: 1.45;
  color: #78350f;
  margin-bottom: 10px;
}

.replay-meta-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 4px;
  font-size: 12px;
  color: #78350f;
  margin-bottom: 10px;
}

.replay-action-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

body.theme-dark .ogre-edition-page .replay-context-card {
  background: #422006;
  border-color: #f59e0b;
  color: #fde68a;
}

body.theme-dark .ogre-edition-page .replay-kicker,
body.theme-dark .ogre-edition-page .replay-title,
body.theme-dark .ogre-edition-page .replay-copy,
body.theme-dark .ogre-edition-page .replay-meta-grid {
  color: #fde68a;
}
"))
    ),
    div(
      class = "ogre-edition-page",
      fluidRow(
        column(
          width = 4,
          div(
            class = "app-card",
            div(class = "section-kicker", "Edition"),
            div(
              class = "card-head",
              h4("Composer une famille"),
              span(class = "card-badge", "Etape guidee")
            ),
            p(
              class = "card-copy",
              "Pour un usage fluide, avancez en trois temps : selection dans le referentiel, choix du parent, puis verification avant creation."
            ),
            div(
              class = "guide-step",
              span(class = "guide-step-index", "1"),
              div(
                div(class = "guide-step-title", "Reperez les lignes utiles"),
                div(class = "guide-step-copy", "Commencez dans l'onglet Selection pour filtrer et retenir seulement les metiers a regrouper.")
              )
            ),
            div(
              class = "guide-step",
              span(class = "guide-step-index", "2"),
              div(
                div(class = "guide-step-title", "Choisissez un parent"),
                div(class = "guide-step-copy", "Le parent devient la ligne de reference. Les autres lignes constituent les enfants de la famille.")
              )
            ),
            div(
              class = "guide-step",
              span(class = "guide-step-index", "3"),
              div(
                div(class = "guide-step-title", "Verifiez avant envoi"),
                div(class = "guide-step-copy", "Le resume et la preconisation servent a reperer les incoherences avant de creer la proposition.")
              )
            ),
            helper_details(
              "Repere rapide pour demarrer",
              p("La verification ne sauvegarde rien. Elle permet juste de controler la composition de la famille avant envoi."),
              p("Si un doute persiste, comparez avec le stock existant ou une proposition deja creee dans les onglets de droite.")
            ),
            br(),
            uiOutput("edition_replay_context_panel"),
            selectizeInput(
              "parent_code",
              label_with_info(
                "1. Parent",
                "Choisissez la ligne la plus representative de la famille. Elle sert de point d'ancrage pour la lecture metier."
              ),
              choices = character(0),
              selected = NULL,
              options = list(placeholder = "Choisir le parent")
            ),
            selectizeInput(
              "child_codes",
              label_with_info(
                "2. Enfants",
                "Ajoutez ici les autres lignes rattachees au parent. Si le groupe parait trop heterogene, mieux vaut scinder la famille."
              ),
              choices = character(0),
              selected = NULL,
              multiple = TRUE,
              options = list(placeholder = "Choisir les enfants")
            ),
            textAreaInput(
              "commentaire_edition",
              label_with_info(
                "Commentaire édition",
                "Ajoutez si besoin une précision pour la supervision ou la validation."
              ),
              value = "",
              placeholder = "Ex : regroupement proposé car les appellations relèvent du même usage métier...",
              rows = 3
            ),
            br(),
            helper_details(
              "Comment choisir le parent et les enfants ?",
              p("Le parent est souvent la ligne la plus stable ou la plus representative du regroupement attendu."),
              p("Les enfants doivent rester lisibles pour un utilisateur non expert : si l'ensemble parait trop heterogene, il vaut mieux scinder la famille.")
            ),
            uiOutput("recommendation_panel"),
            div(
              class = "action-row",
              actionButton("simulate_draft", "Verifier la filiation"),
              actionButton("reset_draft", "Reinitialiser", class = "btn-default"),
              actionButton("create_proposal", "Creer la proposition", class = "btn-primary")
            ),
            p(
              class = "action-help",
              "Verifier la filiation permet de controler sans enregistrer. Creer la proposition lance ensuite le passage dans le workflow."
            )
          ),
          div(
            class = "app-card",
            div(
              class = "card-head",
              h4("Resume de la proposition"),
              span(class = "card-badge", "Controle final")
            ),
            p(
              class = "card-copy",
              "Relisez ici ce qui sera envoye. La preconisation, quand elle existe, se consulte juste au-dessus avant creation."
            ),
            div(
              class = "subpanel-content",
              p(
                class = "card-copy",
                "Ce bloc confirme ce qui partira en supervision. S'il y a un doute ici, revenez sur le parent, les enfants ou la preconisation."
              ),
              uiOutput("family_preview")
            )
          )
        ),
        column(
          width = 8,
          tabsetPanel(
            id = "edition_main_tabs",
            selected = "selection",
            
            tabPanel(
              title = "Selection",
              value = "selection",
              div(
                class = "tab-intro",
                span(class = "tab-intro-copy", "Selectionnez dans le referentiel les lignes a regrouper."),
                inline_info("Cette selection alimente ensuite les listes Parent et Enfants dans la zone de composition."),
                helper_details(
                  "Bon reflexe de depart",
                  p("Commencez par un filtre simple sur un mot metier, un code ou une famille proche."),
                  p("Ne gardez que les lignes qui doivent vraiment vivre ensemble pour eviter une famille trop large ou trop floue.")
                )
              ),
              DTOutput("table_ref")
            ),
            tabPanel(
              title = "Contrôle du stock",
              value = "stock",
              div(
                class = "tab-intro",
                span(class = "tab-intro-copy", "Contrôlez les familles déjà publiées avant de créer une nouvelle famille."),
                inline_info("Cet onglet sert de contrôle anti-doublon pendant la composition d'une nouvelle famille.")
              ),
              uiOutput("stock_families_notice"),
              br(),
              DTOutput("table_families"),
              br(),
              uiOutput("detail_stock_family_detail")
            ),
            tabPanel(
              title = "Propositions",
              value = "propositions",
              div(
                class = "tab-intro",
                span(class = "tab-intro-copy", "Retrouvez ici les propositions deja creees."),
                inline_info("Vous pouvez y relire le detail d'une proposition avant traitement ou supprimer une proposition si besoin.")
              ),
              div(
                class = "action-row",
                actionButton("delete_proposal", "Supprimer la proposition selectionnee", class = "btn-danger")
              ),
              br(),
              DTOutput("table_proposals"),
              br(),
              uiOutput("proposal_detail")
            ),
            tabPanel(
              title = "Détail famille existante",
              value = "detail_stock",
              div(
                class = "tab-intro",
                span(class = "tab-intro-copy", "Consultez le détail d'une famille déjà publiée depuis l'espace d'édition."),
                inline_info("Cette vue reste un contrôle ponctuel. Pour explorer et remettre en jeu les familles validées, utilisez Filiation > Familles validées OGRE.")
              ),
              DTOutput("table_families_detail"),
              br(),
              uiOutput("detail_stock_family_detail")
            )
          )
        )
      )
    )
  )
  
}