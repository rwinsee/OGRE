args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
script_dir <- if (length(file_arg) == 1L) {
  dirname(normalizePath(sub("^--file=", "", file_arg), winslash = "/", mustWork = TRUE))
} else {
  normalizePath(getwd(), winslash = "/", mustWork = TRUE)
}

delivery_root <- normalizePath(file.path(script_dir, ".."), winslash = "/", mustWork = TRUE)
agate_root <- file.path(delivery_root, "module_AGATE")
ogre_root <- file.path(delivery_root, "module_OGRE")

stopifnot(dir.exists(agate_root), dir.exists(ogre_root))

r_files <- unlist(lapply(c(agate_root, ogre_root), list.files,
  pattern = "[.]R$",
  recursive = TRUE,
  full.names = TRUE
), use.names = FALSE)

stopifnot(length(r_files) >= 20L)

parse_errors <- lapply(r_files, function(path) {
  tryCatch(
    {
      parse(file = path, keep.source = TRUE, encoding = "UTF-8")
      NULL
    },
    error = function(e) sprintf("%s : %s", path, conditionMessage(e))
  )
})
parse_errors <- Filter(Negate(is.null), parse_errors)

if (length(parse_errors) > 0L) {
  stop(paste(unlist(parse_errors), collapse = "\n"), call. = FALSE)
}

agate_files <- r_files[startsWith(normalizePath(r_files, winslash = "/"), normalizePath(agate_root, winslash = "/"))]
ogre_files <- r_files[startsWith(normalizePath(r_files, winslash = "/"), normalizePath(ogre_root, winslash = "/"))]

agate_text <- paste(
  unlist(lapply(agate_files, readLines, warn = FALSE, encoding = "UTF-8"), use.names = FALSE),
  collapse = "\n"
)

ogre_text <- paste(
  unlist(lapply(ogre_files, readLines, warn = FALSE, encoding = "UTF-8"), use.names = FALSE),
  collapse = "\n"
)

required_contracts <- c(
  "agate_edition_ui <- function",
  "agate_edition_server <- function",
  "agate_supervision_ui <- function",
  "agate_supervision_server <- function",
  "agate_validation_ui <- function",
  "agate_validation_server <- function",
  "agate_stock_valides_ui <- function",
  "agate_stock_valides_server <- function",
  "source_agate_modules <- function",
  "AGATE_S3_BASE <- \"travail/projet-edep-artemis/open_data/astra_agate\"",
  "origine_proposition = character()",
  "id_famille_rejouee = character()",
  "horodatage_rejeu = character()",
  "commentaire_rejeu = character()",
  "AGATE_SOURCE_NMCL_APET_KEY"
)

missing_contracts <- required_contracts[!vapply(
  required_contracts,
  grepl,
  logical(1),
  x = agate_text,
  fixed = TRUE
)]

if (length(missing_contracts) > 0L) {
  stop(
    paste("Contrats AGATE manquants :", paste(missing_contracts, collapse = ", ")),
    call. = FALSE
  )
}

forbidden_tokens <- c("ref_ogr", "source_ogre_workflow", "module_OGRE")
found_forbidden <- forbidden_tokens[vapply(
  forbidden_tokens,
  grepl,
  logical(1),
  x = agate_text,
  fixed = TRUE
)]

if (length(found_forbidden) > 0L) {
  stop(
    paste("Références OGRE résiduelles dans AGATE :", paste(found_forbidden, collapse = ", ")),
    call. = FALSE
  )
}

ogre_required_contracts <- c(
  "ogre_edition_ui <- function",
  "ogre_edition_server <- function",
  "ogre_validation_ui <- function",
  "ogre_validation_server <- function",
  "output$edition_workspace_metrics <- renderUI",
  "validation_agent_value <- reactive",
  "validation_reprise_idep_value <- reactive",
  "output$validation_agent_readonly <- renderText",
  "output$validation_reprise_idep_readonly <- renderText",
  "edition-hero",
  "edition-workspace"
)

missing_ogre_contracts <- ogre_required_contracts[!vapply(
  ogre_required_contracts,
  grepl,
  logical(1),
  x = ogre_text,
  fixed = TRUE
)]

if (length(missing_ogre_contracts) > 0L) {
  stop(
    paste("Contrats OGRE manquants :", paste(missing_ogre_contracts, collapse = ", ")),
    call. = FALSE
  )
}

validation_server_text <- paste(
  readLines(file.path(ogre_root, "validation", "server_validation.R"), warn = FALSE, encoding = "UTF-8"),
  collapse = "\n"
)

editable_idep_tokens <- c(
  "input$validation_agent",
  "input$validation_reprise_idep_agent"
)

found_editable_idep <- editable_idep_tokens[vapply(
  editable_idep_tokens,
  grepl,
  logical(1),
  x = validation_server_text,
  fixed = TRUE
)]

if (length(found_editable_idep) > 0L) {
  stop(
    paste("IDEP validation encore piloté par un champ éditable :", paste(found_editable_idep, collapse = ", ")),
    call. = FALSE
  )
}

message(sprintf(
  "OK - %d scripts analysés (%d AGATE, %d OGRE), contrats principaux présents.",
  length(r_files),
  length(agate_files),
  length(ogre_files)
))
