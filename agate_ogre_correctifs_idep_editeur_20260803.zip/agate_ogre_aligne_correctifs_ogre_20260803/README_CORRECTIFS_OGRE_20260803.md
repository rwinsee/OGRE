# Correctifs OGRE — 3 août 2026

## 1. Verrouillage de l’IDEP en validation MOA

La validation applique désormais le même principe que la supervision :

- détection de l’IDEP depuis la session, puis depuis les variables d’environnement de repli ;
- affichage en lecture seule avec un indicateur de verrouillage ;
- utilisation exclusive de cette valeur côté serveur pour la prise en charge, la mise en attente, la reprise, le rejet, la publication et la recréation d’une reprise d’édition ;
- blocage explicite de l’action si aucun IDEP n’est détecté.

Les anciens champs éditables `validation_agent` et `validation_reprise_idep_agent` ne pilotent plus aucun traitement.

## 2. Refonte visuelle de l’éditeur

L’éditeur dispose maintenant :

- d’un en-tête d’atelier qui explique immédiatement l’objectif ;
- d’un parcours visuel en trois étapes : sélectionner, composer, vérifier et envoyer ;
- de quatre indicateurs dynamiques : taille du référentiel, sélection active, parent et nombre d’enfants ;
- d’une carte de composition plus visible ;
- d’une action principale de création clairement distinguée des actions de contrôle et de réinitialisation ;
- d’un espace de travail à onglets modernisé ;
- d’un rendu responsive et d’un thème sombre cohérent.

La refonte ne change ni les identifiants Shiny, ni le moteur de composition, ni les contrôles de conflit, ni le workflow.

## 3. Fichiers modifiés

- `module_OGRE/edition/ui_edition.R`
- `module_OGRE/edition/server_edition.R`
- `module_OGRE/validation/ui_validation.R`
- `module_OGRE/validation/server_validation.R`

Les versions antérieures sont conservées dans `backup_OGRE_avant_correctifs_20260803`.
