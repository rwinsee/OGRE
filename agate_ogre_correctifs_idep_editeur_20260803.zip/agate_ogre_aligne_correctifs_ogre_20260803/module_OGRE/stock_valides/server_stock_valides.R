stock_valides_build_replay_draft <- function(family_row, idep_agent, commentaire_edition = "") {
  family_row <- normalize_family_row(family_row)
  child_codes <- split_pipe_values(family_row$codes_ogr_enfants[1])
  child_labels <- split_pipe_values(family_row$libelles_enfants[1])
  
  list(
    idep_agent = as.character(idep_agent),
    commentaire_edition = as.character(commentaire_edition),
    code_ogr_parent = as.character(family_row$code_ogr_parent[1]),
    code_rome_parent = as.character(family_row$code_rome_parent[1]),
    libelle_parent = as.character(family_row$libelle_parent[1]),
    child_codes = child_codes,
    child_labels = child_labels
  )
}

stock_valides_active_replay_conflicts <- function(family_row, active_proposals) {
  family_row <- normalize_family_row(family_row)
  active_proposals <- if (is.null(active_proposals)) {
    proposals_template()
  } else {
    normalize_proposals(active_proposals)
  }
  
  if (nrow(active_proposals) == 0) {
    return(active_proposals[0, , drop = FALSE])
  }
  
  family_id <- first_non_empty(family_row$id_famille[1], "")
  parent_code <- first_non_empty(family_row$code_ogr_parent[1], "")
  
  active_proposals %>%
    dplyr::filter(
      dplyr::if_any(
        dplyr::any_of(c("id_proposition", "base_famille_id", "code_ogr_parent")),
        ~ !is.na(.x)
      )
    ) %>%
    dplyr::filter(
      (nzchar(family_id) & base_famille_id == family_id) |
        (nzchar(parent_code) & code_ogr_parent == parent_code & type_operation == "modification")
    )
}

stock_valides_assert_replay_possible <- function(family_row, stock_families = NULL) {
  family_row <- normalize_family_row(family_row)
  family_id <- first_non_empty(family_row$id_famille[1], "")
  
  if (!nzchar(family_id)) {
    stop("Remise en jeu impossible : identifiant de famille manquant.", call. = FALSE)
  }
  
  # La remise en jeu n'est pas un brouillon persistant et ne depose rien en supervision.
  # Elle sert uniquement a precharger OGRE > Edition avec la famille validee.
  # On ne bloque donc pas la remise en jeu sur l'existence d'une proposition active,
  # ni sur un ancien contexte perdu suite a fermeture de session.
  # Les controles de conflits/doublons restent effectues au moment reel de creation
  # de la proposition dans le module Edition.
  
  invisible(TRUE)
}

stock_valides_replay_family <- function(family_row, idep_agent, commentaire_edition = "", stock_families = NULL) {
  family_row <- normalize_family_row(family_row)
  idep_agent <- toupper(trimws(first_non_empty(idep_agent, ogre_current_idep(""))))
  commentaire_edition <- first_non_empty(commentaire_edition, "")
  
  if (!nzchar(idep_agent)) {
    stop("Remise en jeu impossible : l'IDEP agent est obligatoire.", call. = FALSE)
  }
  
  stock_valides_assert_replay_possible(family_row, stock_families = stock_families)
  
  created_at <- now_chr()
  child_codes <- split_pipe_values(family_row$codes_ogr_enfants[1])
  child_labels <- split_pipe_values(family_row$libelles_enfants[1])
  nb_children <- length(child_labels)
  
  replay_comment <- paste(
    c(
      paste0("Remise en jeu depuis la famille stock ", family_row$id_famille[1]),
      commentaire_edition
    )[nzchar(c(
      paste0("Remise en jeu depuis la famille stock ", family_row$id_famille[1]),
      commentaire_edition
    ))],
    collapse = "\n"
  )
  
  file_stem <- build_proposal_file_stem(
    idep_agent = idep_agent,
    code_ogr_parent = family_row$code_ogr_parent[1],
    nb_enfants = nb_children,
    phase = "rejeu_stock",
    created_at = created_at
  )
  file_path <- next_workflow_proposal_path(
    file_stem = file_stem,
    phase = "supervision",
    statut = "a_superviser"
  )
  
  new_row <- data.frame(
    id_proposition = tools::file_path_sans_ext(basename(file_path)),
    id_lignee = tools::file_path_sans_ext(basename(file_path)),
    id_proposition_source = first_non_empty(family_row$id_proposition_source[1], family_row$id_famille[1]),
    fichier_source = first_non_empty(family_row$fichier_stockage[1], ""),
    phase_proposition = "supervision",
    statut_proposition = "a_superviser",
    type_operation = "modification",
    origine_proposition = "rejeu_stock_valide",
    mode_entree_edition = "remise_en_jeu_directe",
    id_famille_rejouee = as.character(family_row$id_famille[1]),
    fichier_famille_rejouee = first_non_empty(family_row$fichier_stockage[1], ""),
    horodatage_rejeu = created_at,
    idep_agent_rejeu = idep_agent,
    commentaire_rejeu = commentaire_edition,
    idep_agent_edition = idep_agent,
    horodatage_edition = created_at,
    commentaire_edition = replay_comment,
    code_ogr_parent_edition = as.character(family_row$code_ogr_parent[1]),
    code_rome_parent_edition = as.character(family_row$code_rome_parent[1]),
    libelle_parent_edition = as.character(family_row$libelle_parent[1]),
    codes_ogr_enfants_edition = paste(child_codes, collapse = " | "),
    libelles_enfants_edition = paste(child_labels, collapse = " | "),
    nb_enfants_edition = nb_children,
    base_famille_id = as.character(family_row$id_famille[1]),
    base_codes_ogr_enfants = paste(child_codes, collapse = " | "),
    delta_enfants_ajoutes_edition = "",
    delta_enfants_retires_edition = "",
    idep_agent_supervision = "",
    horodatage_prise_en_charge_supervision = "",
    horodatage_decision_supervision = "",
    decision_supervision = "",
    commentaire_supervision = "",
    code_ogr_parent_supervision = "",
    code_rome_parent_supervision = "",
    libelle_parent_supervision = "",
    codes_ogr_enfants_supervision = "",
    libelles_enfants_supervision = "",
    nb_enfants_supervision = 0L,
    delta_enfants_ajoutes_supervision = "",
    delta_enfants_retires_supervision = "",
    idep_agent_validation = "",
    horodatage_prise_en_charge_validation = "",
    horodatage_decision_validation = "",
    decision_validation = "",
    commentaire_validation = "",
    code_ogr_parent_validation = "",
    code_rome_parent_validation = "",
    codes_ogr_enfants_validation = "",
    libelle_parent_validation = "",
    libelles_enfants_validation = "",
    nb_enfants_validation = 0L,
    id_famille_stock_publiee = "",
    code_ogr_parent = as.character(family_row$code_ogr_parent[1]),
    code_rome_parent = as.character(family_row$code_rome_parent[1]),
    libelle_parent = as.character(family_row$libelle_parent[1]),
    codes_ogr_enfants = paste(child_codes, collapse = " | "),
    libelles_enfants = paste(child_labels, collapse = " | "),
    nb_enfants = nb_children,
    fichier_stockage = basename(file_path),
    stringsAsFactors = FALSE
  )
  
  new_row <- normalize_proposal_row(new_row)
  written_path <- write_proposal_file(new_row)
  
  res <- new_row$id_proposition[1]
  attr(res, "path_fichier") <- written_path
  invisible(res)
}

ogre_stock_valides_server <- function(input, output, session) {
  refresh_token <- reactiveVal(0L)
  selected_family_id <- reactiveVal("")
  selected_appellation_family_id <- reactiveVal("")
  replay_running <- reactiveVal(FALSE)
  
  bump_refresh <- function() {
    refresh_token(isolate(refresh_token()) + 1L)
  }
  
  empty_label <- function(x, fallback = "-") {
    x <- first_non_empty(x, "")
    if (nzchar(x)) x else fallback
  }
  
  coalesce_chr <- function(x, y = "") {
    x <- as.character(x)
    y <- as.character(y)
    len <- max(length(x), length(y))
    length(x) <- len
    length(y) <- len
    x[is.na(x) | !nzchar(x)] <- y[is.na(x) | !nzchar(x)]
    x[is.na(x)] <- ""
    x
  }
  
  ref_data <- reactive({
    refresh_token()
    ref <- get0("ref_ogr", ifnotfound = NULL, inherits = TRUE)
    if (is.null(ref) || nrow(ref) == 0) {
      ref <- ensure_reference_file()
    }
    normalize_reference(ref)
  })
  
  stock_families <- reactive({
    refresh_token()
    families <- tryCatch(
      load_families(),
      error = function(e) {
        showNotification(
          paste("Lecture du stock impossible :", conditionMessage(e)),
          type = "error",
          duration = 8
        )
        families_template()
      }
    )
    
    families <- normalize_families(families)
    if (nrow(families) == 0) {
      return(families)
    }
    
    families %>%
      dplyr::mutate(
        nb_enfants = pmax(
          nb_enfants,
          vapply(codes_ogr_enfants, function(x) length(split_pipe_values(x)), integer(1)),
          vapply(libelles_enfants, function(x) length(split_pipe_values(x)), integer(1))
        )
      )
  })
  
  family_matches_search <- function(families, search) {
    search <- trimws(tolower(search %||% ""))
    if (!nzchar(search) || nrow(families) == 0) {
      return(families)
    }
    
    haystack <- apply(
      families[, intersect(
        c(
          "id_famille", "code_ogr_parent", "code_rome_parent", "libelle_parent",
          "codes_ogr_enfants", "libelles_enfants", "idep_agent", "idep_agent_validation"
        ),
        names(families)
      ), drop = FALSE],
      1,
      function(row) paste(tolower(as.character(row)), collapse = " ")
    )
    
    families[grepl(search, haystack, fixed = TRUE), , drop = FALSE]
  }
  
  stock_table_data <- reactive({
    families <- family_matches_search(stock_families(), input$stock_valides_search)
    if (nrow(families) == 0) {
      return(data.frame(
        id_famille = character(),
        parent = character(),
        code_ogr_parent = character(),
        code_rome_parent = character(),
        nb_enfants = integer(),
        date_validation = character(),
        agent_validation = character(),
        fichier_stockage = character(),
        stringsAsFactors = FALSE
      ))
    }
    
    families %>%
      dplyr::transmute(
        id_famille,
        parent = libelle_parent,
        code_ogr_parent,
        code_rome_parent,
        nb_enfants,
        date_validation = coalesce_chr(date_validation, date_creation),
        agent_validation = coalesce_chr(idep_agent_validation, idep_agent),
        fichier_stockage
      ) %>%
      dplyr::arrange(parent, code_ogr_parent)
  })
  
  selected_family <- reactive({
    id <- selected_family_id()
    families <- stock_families()
    if (!nzchar(id) || nrow(families) == 0) {
      return(families_template()[0, , drop = FALSE])
    }
    families[families$id_famille == id, , drop = FALSE]
  })
  
  selected_appellation_family <- reactive({
    id <- first_non_empty(selected_appellation_family_id(), selected_family_id())
    families <- stock_families()
    if (!nzchar(id) || nrow(families) == 0) {
      return(families_template()[0, , drop = FALSE])
    }
    families[families$id_famille == id, , drop = FALSE]
  })
  
  family_detail_dt <- function(family) {
    if (is.null(family) || nrow(family) == 0) {
      return(data.frame(
        role = character(),
        code_ogr = character(),
        libelle = character(),
        code_rome = character(),
        libelle_rome = character(),
        grand_domaine = character(),
        domaine_professionnel = character(),
        classification = character(),
        stringsAsFactors = FALSE
      ))
    }
    
    family <- normalize_family_row(family)
    child_codes <- split_pipe_values(family$codes_ogr_enfants[1])
    child_labels <- split_pipe_values(family$libelles_enfants[1])
    n_child <- max(length(child_codes), length(child_labels))
    if (n_child > 0) {
      length(child_codes) <- n_child
      length(child_labels) <- n_child
    }
    
    rows <- dplyr::bind_rows(
      data.frame(
        role = "Parent principal",
        code_ogr = family$code_ogr_parent[1],
        libelle = family$libelle_parent[1],
        stringsAsFactors = FALSE
      ),
      if (n_child > 0) {
        data.frame(
          role = "Enfant",
          code_ogr = child_codes,
          libelle = child_labels,
          stringsAsFactors = FALSE
        )
      } else {
        data.frame(role = character(), code_ogr = character(), libelle = character(), stringsAsFactors = FALSE)
      }
    )
    
    ref <- ref_data() %>%
      dplyr::transmute(
        code_ogr,
        code_rome_ref = code_rome,
        libelle_rome = libelle_rome,
        grand_domaine = libelle_grand_domaine,
        domaine_professionnel = libelle_domaine_professionnel,
        classification,
        libelle_ref = libelle_appellation_metier
      ) %>%
      dplyr::distinct(code_ogr, .keep_all = TRUE)
    
    rows %>%
      dplyr::left_join(ref, by = "code_ogr") %>%
      dplyr::mutate(
        code_rome = dplyr::if_else(
          role == "Parent principal" & nzchar(family$code_rome_parent[1]),
          family$code_rome_parent[1],
          code_rome_ref %||% ""
        ),
        libelle = dplyr::coalesce(
          ifelse(nzchar(libelle), libelle, NA_character_),
          ifelse(nzchar(libelle_ref), libelle_ref, NA_character_),
          ""
        ),
        libelle_rome = dplyr::coalesce(libelle_rome, ""),
        grand_domaine = dplyr::coalesce(grand_domaine, ""),
        domaine_professionnel = dplyr::coalesce(domaine_professionnel, ""),
        classification = dplyr::coalesce(classification, "")
      ) %>%
      dplyr::select(
        role,
        code_ogr,
        libelle,
        code_rome,
        libelle_rome,
        grand_domaine,
        domaine_professionnel,
        classification
      )
  }
  
  output$stock_valides_kpi_panel <- renderUI({
    families <- stock_families()
    nb_families <- nrow(families)
    nb_children <- if (nb_families == 0) 0L else sum(families$nb_enfants, na.rm = TRUE)
    nb_parents <- if (nb_families == 0) 0L else dplyr::n_distinct(families$code_ogr_parent[nzchar(families$code_ogr_parent)])
    nb_rome <- if (nb_families == 0) 0L else dplyr::n_distinct(families$code_rome_parent[nzchar(families$code_rome_parent)])
    
    kpi <- function(label, value) {
      div(class = "stock-valides-kpi", span(class = "label", label), span(class = "value", value))
    }
    
    div(
      class = "stock-valides-kpis",
      kpi("Familles publiées", format(nb_families, big.mark = " ", scientific = FALSE)),
      kpi("Parents distincts", format(nb_parents, big.mark = " ", scientific = FALSE)),
      kpi("Enfants rattachés", format(nb_children, big.mark = " ", scientific = FALSE)),
      kpi("ROME parents", format(nb_rome, big.mark = " ", scientific = FALSE))
    )
  })
  
  output$table_stock_valides <- DT::renderDT({
    DT::datatable(
      stock_table_data(),
      rownames = FALSE,
      extensions = "Buttons",
      selection = "single",
      filter = "top",
      options = ogre_dt_options(
        page_length = 10,
        scroll_y = "50vh",
        dom = "Bfrtip",
        buttons = TRUE,
        order = list(list(1, "asc")),
        language = list(url = "//cdn.datatables.net/plug-ins/1.10.24/i18n/French.json")
      ),
      colnames = c(
        "Famille", "Parent", "Code OGR parent", "Code ROME parent",
        "Nb enfants", "Date validation", "Agent validation", "Fichier"
      )
    )
  }, server = FALSE)
  
  observeEvent(input$table_stock_valides_rows_selected, {
    idx <- input$table_stock_valides_rows_selected
    table_df <- stock_table_data()
    if (length(idx) == 0 || nrow(table_df) == 0 || idx < 1 || idx > nrow(table_df)) {
      selected_family_id("")
      return()
    }
    selected_family_id(table_df$id_famille[idx])
    selected_appellation_family_id(table_df$id_famille[idx])
  })
  
  output$stock_valides_selected_notice <- renderUI({
    family <- selected_family()
    if (nrow(family) == 0) {
      return(div(class = "stock-valides-warning", "Aucune famille sélectionnée. Sélectionner une ligne du stock pour afficher son détail."))
    }
    div(
      class = "stock-valides-success",
      tags$strong("Famille sélectionnée : "),
      family$id_famille[1],
      " — ",
      empty_label(family$libelle_parent[1])
    )
  })
  
  output$stock_valides_family_detail <- renderUI({
    family <- selected_family()
    if (nrow(family) == 0) {
      return(NULL)
    }
    
    box <- function(label, value) {
      div(
        class = "stock-valides-detail-box",
        span(class = "label", label),
        span(class = "value", empty_label(value))
      )
    }
    
    div(
      class = "stock-valides-card",
      div(
        class = "stock-valides-section-title",
        span("Résumé de la famille validée")
      ),
      div(
        class = "stock-valides-detail-grid",
        box("Identifiant famille", family$id_famille[1]),
        box("Parent", family$libelle_parent[1]),
        box("Code OGR parent", family$code_ogr_parent[1]),
        box("Code ROME parent", family$code_rome_parent[1]),
        box("Nombre d'enfants", family$nb_enfants[1]),
        box("Date validation", first_non_empty(family$date_validation[1], family$date_creation[1])),
        box("Agent édition", family$idep_agent[1]),
        box("Agent validation", family$idep_agent_validation[1]),
        box("Fichier", family$fichier_stockage[1])
      )
    )
  })
  
  output$table_stock_valides_children <- DT::renderDT({
    DT::datatable(
      family_detail_dt(selected_family()),
      rownames = FALSE,
      extensions = "Buttons",
      filter = "top",
      options = ogre_dt_options(
        page_length = 20,
        scroll_y = "50vh",
        dom = "Bfrtip",
        buttons = TRUE,
        language = list(url = "//cdn.datatables.net/plug-ins/1.10.24/i18n/French.json")
      ),
      colnames = c(
        "Rôle", "Code OGR", "Libellé", "Code ROME", "Libellé ROME",
        "Grand domaine", "Domaine professionnel", "Classification"
      )
    )
  }, server = FALSE)
  
  output$stock_valides_graph_container <- renderUI({
    if (!isTRUE(get0("has_plotly", ifnotfound = requireNamespace("plotly", quietly = TRUE), inherits = TRUE))) {
      return(div(class = "stock-valides-warning", "Le package plotly n'est pas disponible : le graphe ne peut pas être affiché."))
    }
    family <- selected_family()
    if (nrow(family) == 0) {
      return(div(class = "stock-valides-warning", "Sélectionner une famille validée pour afficher sa filiation graphique."))
    }
    plotly::plotlyOutput("stock_valides_graph", height = "620px")
  })
  
  if (requireNamespace("plotly", quietly = TRUE)) {
    output$stock_valides_graph <- plotly::renderPlotly({
      family <- selected_family()
      req(nrow(family) > 0)
      
      parent_label <- first_non_empty(family$libelle_parent[1], "Parent sans libellé")
      parent_code <- first_non_empty(family$code_ogr_parent[1], "")
      child_codes <- split_pipe_values(family$codes_ogr_enfants[1])
      child_labels <- split_pipe_values(family$libelles_enfants[1])
      family_title <- first_non_empty(family$id_famille[1], family$code_ogr_parent[1], "famille validée")
      
      max_len <- max(length(child_labels), length(child_codes))
      if (max_len > 30) {
        return(
          plotly::plot_ly() %>%
            plotly::layout(
              title = "Filiation graphique non affichée",
              xaxis = list(visible = FALSE),
              yaxis = list(visible = FALSE),
              paper_bgcolor = "#fffdf8",
              plot_bgcolor = "#fffdf8",
              margin = list(l = 20, r = 20, t = 60, b = 24),
              annotations = list(
                list(
                  x = 0.5,
                  y = 0.55,
                  xref = "paper",
                  yref = "paper",
                  text = paste0(
                    "La famille <b>", family_title, "</b> contient <b>", max_len,
                    "</b> enfants. Le graphe serait trop chargé ; utiliser le tableau de détail."
                  ),
                  showarrow = FALSE,
                  align = "center",
                  font = list(size = 14, color = "#52627c")
                )
              )
            )
        )
      }
      
      if (max_len == 0) {
        return(
          plotly::plot_ly() %>%
            plotly::layout(
              title = "Aucun enfant à afficher",
              xaxis = list(visible = FALSE),
              yaxis = list(visible = FALSE),
              paper_bgcolor = "#fffdf8",
              plot_bgcolor = "#fffdf8",
              margin = list(l = 20, r = 20, t = 60, b = 24),
              annotations = list(
                list(
                  x = 0.5,
                  y = 0.5,
                  xref = "paper",
                  yref = "paper",
                  text = paste0("La famille validée <b>", family_title, "</b> ne contient aucun enfant."),
                  showarrow = FALSE,
                  align = "center",
                  font = list(size = 14, color = "#52627c")
                )
              )
            )
        )
      }
      
      length(child_labels) <- max_len
      length(child_codes) <- max_len
      child_labels[is.na(child_labels) | !nzchar(child_labels)] <- paste0("Enfant ", seq_len(max_len))[is.na(child_labels) | !nzchar(child_labels)]
      child_codes[is.na(child_codes)] <- ""
      
      labels <- c(parent_label, child_labels)
      codes <- c(parent_code, child_codes)
      child_palette <- rep_len(
        c("#FF6B6B", "#FFD166", "#06D6A0", "#4D96FF", "#9B5DE5", "#F15BB5", "#00BBF9", "#F9844A"),
        length(child_labels)
      )
      rgba_fun <- get0("hex_to_rgba", ifnotfound = NULL, inherits = TRUE)
      if (!is.function(rgba_fun)) {
        rgba_fun <- function(color, alpha = 0.35) {
          rgb <- grDevices::col2rgb(color)
          paste0("rgba(", rgb[1, ], ", ", rgb[2, ], ", ", rgb[3, ], ", ", alpha, ")")
        }
      }
      node_colors <- c("#003049", child_palette)
      link_colors <- c("rgba(0, 48, 73, 0.55)", rgba_fun(child_palette, alpha = 0.42))
      custom_text <- c(
        paste0("<b>Parent</b><br>", parent_label, "<br>Code OGR : ", parent_code),
        paste0("<b>Enfant</b><br>", child_labels, "<br>Code OGR : ", child_codes)
      )
      node_x <- c(0.12, rep(0.84, length(child_labels)))
      node_y <- c(
        0.5,
        if (length(child_labels) == 1) {
          0.5
        } else {
          seq(0.08, 0.92, length.out = length(child_labels))
        }
      )
      
      plotly::plot_ly(
        type = "sankey",
        arrangement = "fixed",
        node = list(
          pad = 26,
          thickness = 28,
          line = list(color = "#ffffff", width = 2),
          label = labels,
          color = node_colors,
          x = node_x,
          y = node_y,
          customdata = custom_text,
          hovertemplate = "%{customdata}<extra></extra>"
        ),
        link = list(
          source = rep(0, length(child_labels)),
          target = seq_along(child_labels),
          value = rep(1, length(child_labels)),
          color = link_colors[-1],
          hovertemplate = paste0(
            "<b>Flux de filiation</b><br>",
            parent_label,
            " -> %{target.label}<extra></extra>"
          )
        )
      ) %>%
        plotly::layout(
          title = list(text = paste("Filiation graphique -", family_title)),
          font = list(family = "Arial", size = 14, color = "#17324d"),
          paper_bgcolor = "#fffdf8",
          plot_bgcolor = "#fffdf8",
          margin = list(l = 20, r = 20, t = 78, b = 24),
          annotations = list(
            list(
              x = 0.01,
              y = 1.12,
              xref = "paper",
              yref = "paper",
              text = paste0("Parent : <b>", parent_label, "</b>"),
              showarrow = FALSE,
              align = "left",
              font = list(size = 13, color = "#52627c")
            ),
            list(
              x = 0.01,
              y = 1.05,
              xref = "paper",
              yref = "paper",
              text = paste0("Enfants reliés : <b>", length(child_labels), "</b>"),
              showarrow = FALSE,
              align = "left",
              font = list(size = 12, color = "#7a5c00")
            )
          )
        )
    })
  }
  
  app_table_data <- reactive({
    families <- family_matches_search(stock_families(), input$stock_valides_search)
    if (nrow(families) == 0) {
      return(data.frame(
        id_famille = character(),
        code_ogr_parent = character(),
        appellation_principale = character(),
        code_rome_parent = character(),
        nb_enfants = integer(),
        enfants = character(),
        date_validation = character(),
        stringsAsFactors = FALSE
      ))
    }
    
    families %>%
      dplyr::transmute(
        id_famille,
        code_ogr_parent,
        appellation_principale = libelle_parent,
        code_rome_parent,
        nb_enfants,
        enfants = libelles_enfants,
        date_validation = coalesce_chr(date_validation, date_creation)
      ) %>%
      dplyr::arrange(appellation_principale, code_ogr_parent)
  })
  
  output$table_stock_valides_appellations <- DT::renderDT({
    DT::datatable(
      app_table_data(),
      rownames = FALSE,
      extensions = "Buttons",
      selection = "single",
      filter = "top",
      options = ogre_dt_options(
        page_length = 12,
        scroll_y = "50vh",
        dom = "Bfrtip",
        buttons = TRUE,
        order = list(list(2, "asc")),
        column_defs = list(list(targets = 5, render = DT::JS("function(data,type,row){ if(type === 'display' && data && data.length > 180){ return data.substr(0,180) + '…'; } return data; }"))),
        language = list(url = "//cdn.datatables.net/plug-ins/1.10.24/i18n/French.json")
      ),
      colnames = c(
        "Famille", "Code OGR principal", "Appellation principale",
        "Code ROME parent", "Nb enfants", "Enfants", "Date validation"
      )
    )
  }, server = FALSE)
  
  observeEvent(input$table_stock_valides_appellations_rows_selected, {
    idx <- input$table_stock_valides_appellations_rows_selected
    table_df <- app_table_data()
    if (length(idx) == 0 || nrow(table_df) == 0 || idx < 1 || idx > nrow(table_df)) {
      selected_appellation_family_id("")
      return()
    }
    selected_appellation_family_id(table_df$id_famille[idx])
    selected_family_id(table_df$id_famille[idx])
  })
  
  output$table_stock_valides_appellation_detail <- DT::renderDT({
    DT::datatable(
      family_detail_dt(selected_appellation_family()),
      rownames = FALSE,
      extensions = "Buttons",
      filter = "top",
      options = ogre_dt_options(
        page_length = 25,
        scroll_y = "50vh",
        dom = "Bfrtip",
        buttons = TRUE,
        language = list(url = "//cdn.datatables.net/plug-ins/1.10.24/i18n/French.json")
      ),
      colnames = c(
        "Rôle", "Code OGR", "Libellé", "Code ROME", "Libellé ROME",
        "Grand domaine", "Domaine professionnel", "Classification"
      )
    )
  }, server = FALSE)
  
  output$stock_valides_rejeu_panel <- renderUI({
    family <- selected_family()
    if (nrow(family) == 0) {
      return(div(class = "stock-valides-warning", "Sélectionner d'abord une famille validée dans l'onglet Familles validées."))
    }
    
    tagList(
      div(
        class = "stock-valides-detail-grid",
        div(class = "stock-valides-detail-box", span(class = "label", "Famille"), span(class = "value", family$id_famille[1])),
        div(class = "stock-valides-detail-box", span(class = "label", "Parent"), span(class = "value", family$libelle_parent[1])),
        div(class = "stock-valides-detail-box", span(class = "label", "Nb enfants"), span(class = "value", family$nb_enfants[1]))
      ),
      div(
        class = "stock-valides-warning",
        tags$strong("Effet de l'action : "),
        "la famille validée est copiée dans l'atelier OGRE > Édition. L'agent pourra l'ajuster à la marge ou repartir de zéro avant de créer une proposition de modification."
      ),
      div(
        class = "stock-valides-actions",
        actionButton("stock_valides_open_rejeu_modal", "Remettre en jeu dans l'édition", icon = icon("redo"), class = "btn-warning")
      )
    )
  })
  
  observeEvent(input$stock_valides_refresh, {
    bump_refresh()
    showNotification("Stock validé rafraîchi.", type = "message", duration = 3)
  })
  
  observeEvent(input$stock_valides_reset, {
    selected_family_id("")
    selected_appellation_family_id("")
    updateTextInput(session, "stock_valides_search", value = "")
    showNotification("Sélection réinitialisée.", type = "message", duration = 3)
  })
  
  observeEvent(input$stock_valides_rejouer, {
    family <- selected_family()
    if (nrow(family) == 0) {
      showModal(modalDialog(
        title = "Aucune famille sélectionnée",
        div(class = "stock-valides-warning", "Sélectionner une famille validée avant de demander une remise en jeu."),
        easyClose = TRUE,
        footer = modalButton("Fermer")
      ))
      return()
    }
    updateTabsetPanel(session, "stock_valides_tabs", selected = "Remise en jeu")
  })
  
  observeEvent(input$stock_valides_open_rejeu_modal, {
    family <- selected_family()
    if (nrow(family) == 0) {
      return()
    }
    
    detected_idep <- toupper(trimws(ogre_current_idep(Sys.info()[["user"]] %||% "")))
    
    showModal(modalDialog(
      title = "Remettre en jeu dans l'édition",
      div(
        class = "stock-valides-warning",
        tags$p(tags$strong("Famille : "), family$id_famille[1]),
        tags$p(tags$strong("Parent : "), family$libelle_parent[1]),
        tags$p("La famille sera copiée dans OGRE > Édition. Aucune proposition ne sera créée tant que l'agent n'aura pas validé la composition depuis l'atelier d'édition.")
      ),
      textInput("stock_valides_rejeu_idep", "IDEP agent", value = detected_idep),
      textAreaInput(
        "stock_valides_rejeu_commentaire",
        "Commentaire de remise en jeu",
        value = "",
        rows = 4,
        placeholder = "Motif de la remise en jeu, correction attendue, contexte métier"
      ),
      checkboxInput("stock_valides_rejeu_confirm", "Je confirme la remise en jeu de cette famille validée dans l'atelier d'édition", value = FALSE),
      easyClose = TRUE,
      footer = tagList(
        modalButton("Annuler"),
        actionButton("stock_valides_confirm_rejeu", "Ouvrir dans OGRE édition", icon = icon("arrow-right"), class = "btn-warning")
      )
    ))
  })
  
  observeEvent(input$stock_valides_confirm_rejeu, {
    if (isTRUE(replay_running())) {
      return()
    }
    
    family <- selected_family()
    if (nrow(family) == 0) {
      showNotification("Aucune famille sélectionnée.", type = "error", duration = 6)
      return()
    }
    
    if (!isTRUE(input$stock_valides_rejeu_confirm)) {
      showNotification("Cocher la confirmation avant d’ouvrir la famille dans l’édition.", type = "warning", duration = 6)
      return()
    }
    
    idep <- toupper(trimws(first_non_empty(input$stock_valides_rejeu_idep, "")))
    if (!nzchar(idep)) {
      showNotification("L'IDEP agent est obligatoire.", type = "error", duration = 6)
      return()
    }
    
    replay_running(TRUE)
    on.exit(replay_running(FALSE), add = TRUE)
    
    res <- tryCatch({
      stock_valides_assert_replay_possible(family, stock_families = stock_families())
      TRUE
    }, error = function(e) e)
    
    if (inherits(res, "error")) {
      showModal(modalDialog(
        title = "Remise en jeu impossible",
        div(class = "stock-valides-danger", conditionMessage(res)),
        easyClose = TRUE,
        footer = modalButton("Fermer")
      ))
      return()
    }
    
    child_codes <- split_pipe_values(family$codes_ogr_enfants[1])
    child_labels <- split_pipe_values(family$libelles_enfants[1])
    
    replay_comment <- paste(
      c(
        paste0("Remise en jeu de la famille validée ", family$id_famille[1], "."),
        first_non_empty(input$stock_valides_rejeu_commentaire, "")
      )[nzchar(c(
        paste0("Remise en jeu de la famille validée ", family$id_famille[1], "."),
        first_non_empty(input$stock_valides_rejeu_commentaire, "")
      ))],
      collapse = "
"
    )
    
    if (is.null(session$userData$ogre_replay_context)) {
      session$userData$ogre_replay_context <- reactiveVal(NULL)
    }
    
    active_same_family <- tryCatch(
      stock_valides_active_replay_conflicts(family, load_active_workflow_proposals()),
      error = function(e) proposals_template()
    )
    
    has_active_same_family <- !is.null(active_same_family) && nrow(active_same_family) > 0
    
    session$userData$ogre_replay_context(list(
      origine = "stock_valides",
      origine_proposition = "rejeu_stock_valide",
      mode_entree_edition = "remise_en_jeu",
      id_famille = as.character(family$id_famille[1]),
      id_famille_rejouee = as.character(family$id_famille[1]),
      id_proposition_source = first_non_empty(family$id_proposition_source[1], family$id_famille[1]),
      fichier_source = first_non_empty(family$fichier_stockage[1], ""),
      fichier_famille_rejouee = first_non_empty(family$fichier_stockage[1], ""),
      horodatage_rejeu = now_chr(),
      idep_agent = idep,
      idep_agent_rejeu = idep,
      commentaire_rejeu = first_non_empty(input$stock_valides_rejeu_commentaire, ""),
      commentaire_edition = replay_comment,
      code_ogr_parent = as.character(family$code_ogr_parent[1]),
      code_rome_parent = as.character(family$code_rome_parent[1]),
      libelle_parent = as.character(family$libelle_parent[1]),
      child_codes = child_codes,
      child_labels = child_labels,
      base_codes_ogr_enfants = paste(child_codes, collapse = " | ")
    ))
    
    removeModal()
    
    if (isTRUE(has_active_same_family)) {
      showNotification(
        "Famille copiée dans OGRE > Édition. Attention : une proposition active existe déjà sur cette famille ; le contrôle final se fera à la création de la proposition.",
        type = "warning",
        duration = 10
      )
    } else {
      showNotification(
        "Famille validée copiée dans OGRE > Édition. Ajustez la composition puis créez la proposition de modification.",
        type = "message",
        duration = 8
      )
    }
    
    try(updateNavbarPage(session, "tabs", selected = "filiation_ogre"), silent = TRUE)
  })
}
