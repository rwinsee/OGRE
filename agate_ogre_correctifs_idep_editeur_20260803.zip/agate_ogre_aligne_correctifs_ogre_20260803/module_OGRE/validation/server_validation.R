ogre_validation_server <- function(input, output, session) {
  source_ogre_workflow(environment())
  
  scalar_chr <- function(x, default = "") {
    if (is.null(x) || length(x) == 0) return(default)
    x <- as.character(x[[1]])
    if (is.na(x)) return(default)
    trimws(x)
  }
  
  vec_chr <- function(x) {
    if (is.null(x) || length(x) == 0) return(character(0))
    x <- trimws(as.character(x))
    x[!is.na(x) & nzchar(x)]
  }
  
  is_filled <- function(x) {
    nzchar(scalar_chr(x, default = ""))
  }

  get_detected_idep <- function() {
    candidates <- c(
      if (!is.null(session$userData$user_idep)) session$userData$user_idep else "",
      if (!is.null(session$userData$idep)) session$userData$idep else "",
      if (exists("user_idep", inherits = TRUE)) get("user_idep", inherits = TRUE) else "",
      Sys.getenv("USER_IDEP", unset = ""),
      Sys.getenv("IDEP", unset = "")
    )

    candidates <- trimws(as.character(candidates))
    candidates <- candidates[!is.na(candidates) & nzchar(candidates)]

    if (length(candidates) == 0) {
      return("")
    }

    candidates[1]
  }

  detected_idep <- reactive({
    get_detected_idep()
  })

  validation_agent_value <- reactive({
    detected_idep()
  })

  validation_reprise_idep_value <- reactive({
    detected_idep()
  })

  output$validation_agent_readonly <- renderText({
    value <- validation_agent_value()
    if (nzchar(value)) value else "IDEP non détecté"
  })

  output$validation_reprise_idep_readonly <- renderText({
    value <- validation_reprise_idep_value()
    if (nzchar(value)) value else "IDEP non détecté"
  })
  
  validation_server_inline_info <- function(text) {
    tags$span(
      class = "validation-inline-info",
      tabindex = "0",
      `data-tooltip` = text,
      `aria-label` = text,
      "i"
    )
  }
  
  section_title_with_info <- function(title, info_text) {
    tags$div(
      class = "validation-section-head",
      tags$div(class = "validation-section-title", title),
      validation_server_inline_info(info_text)
    )
  }
  if (is.null(session$userData$workflow_refresh)) {
    session$userData$workflow_refresh <- reactiveVal(0)
  }
  
  refresh_token <- session$userData$workflow_refresh
  
  bump_workflow_refresh <- function() {
    refresh_token(as.numeric(Sys.time()) + stats::runif(1, min = 0, max = 1e-06))
  }
  
  refresh_validation_views <- function(extra_rereads = 2L, delay_sec = 0.45) {
    bump_workflow_refresh()
    
    # Rejoue la lecture apres l'action pour absorber le delai de visibilite
    # des deplacements de fichiers du workflow OGRE.
    if (extra_rereads <= 0L || !requireNamespace("later", quietly = TRUE)) {
      return(invisible(NULL))
    }
    
    for (attempt in seq_len(extra_rereads)) {
      later::later(
        function() {
          try(bump_workflow_refresh(), silent = TRUE)
        },
        delay = attempt * delay_sec
      )
    }
    
    invisible(NULL)
  }
  
  validation_kpi_state <- reactive({
    refresh_token()
    
    list(
      validation = load_proposals("validation") %>%
        arrange(desc(horodatage_decision_supervision), desc(horodatage_edition), id_proposition),
      supervision = load_proposals("supervision") %>%
        arrange(desc(horodatage_edition), id_proposition),
      stock_families = load_families(),
      edep_reference = load_edep_reference(),
      edep_links = load_edep_links()
    )
  })
  
  validation_states <- reactive({
    validation_kpi_state()$validation
  })
  
  supervision_states <- reactive({
    validation_kpi_state()$supervision
  })
  
  supervision_queue <- reactive({
    supervision_states() %>%
      filter(statut_proposition == "a_superviser")
  })
  
  supervision_in_progress <- reactive({
    supervision_states() %>%
      filter(statut_proposition == "en_cours")
  })
  
  supervision_rejected <- reactive({
    supervision_states() %>%
      filter(statut_proposition == "rejetes")
  })
  
  validation_queue <- reactive({
    validation_states() %>%
      filter(statut_proposition == "a_valider")
  })
  
  validation_in_progress <- reactive({
    validation_states() %>%
      filter(statut_proposition == "en_cours")
  })
  
  validation_waiting <- reactive({
    validation_states() %>%
      filter(statut_proposition == "en_attente")
  })
  
  validation_rejected <- reactive({
    validation_states() %>%
      filter(statut_proposition == "rejetes")
  })
  
  validation_validated <- reactive({
    validation_states() %>%
      filter(statut_proposition == "valides")
  })
  
  validation_open_scope <- reactive({
    bind_rows(
      validation_queue(),
      validation_in_progress(),
      validation_waiting()
    ) %>%
      distinct(id_proposition, .keep_all = TRUE)
  })
  
  stock_families <- reactive({
    validation_kpi_state()$stock_families
  })
  
  workflow_active_proposals <- reactive({
    refresh_token()
    load_active_workflow_proposals() %>%
      arrange(desc(horodatage_edition), id_proposition)
  })
  
  edep_reference <- reactive({
    validation_kpi_state()$edep_reference
  })
  
  edep_links <- reactive({
    validation_kpi_state()$edep_links
  })
  
  selected_validation <- reactive({
    active_tab <- input$validation_status_tab
    
    if (is.null(active_tab) || identical(active_tab, "A valider")) {
      idx <- input$table_validation_queue_rows_selected
      df <- validation_queue()
    } else if (identical(active_tab, "En cours")) {
      idx <- input$table_validation_in_progress_rows_selected
      df <- validation_in_progress()
    } else if (identical(active_tab, "En attente")) {
      idx <- input$table_validation_waiting_rows_selected
      df <- validation_waiting()
    } else if (identical(active_tab, "Rejetes")) {
      idx <- input$table_validation_rejected_rows_selected
      df <- validation_rejected()
    } else if (identical(active_tab, "Validees")) {
      idx <- input$table_validation_validated_rows_selected
      df <- validation_validated()
    } else {
      return(NULL)
    }
    
    if (length(idx) != 1 || nrow(df) < idx) {
      return(NULL)
    }
    
    df[idx, , drop = FALSE]
  })
  
  show_family_conflict_modal <- function(title, checks, closing_copy) {
    showModal(modalDialog(
      title = title,
      build_family_conflict_modal_content(checks),
      tags$p(closing_copy),
      easyClose = TRUE,
      footer = modalButton("Fermer")
    ))
  }
  
  run_validation_transition <- function(action_fun, failure_prefix) {
    tryCatch(
      {
        action_fun()
        TRUE
      },
      error = function(e) {
        showNotification(
          paste(failure_prefix, conditionMessage(e)),
          type = "error",
          duration = 8
        )
        FALSE
      },
      finally = {
        refresh_validation_views()
      }
    )
  }
  
  validation_modification_compare <- reactive({
    proposal <- selected_validation()
    
    if (is.null(proposal)) {
      return(NULL)
    }
    
    build_modification_compare(proposal, stock_families())
  })
  
  normalize_validation_draft <- function(parent_code = "", child_codes = character(0)) {
    ref_df <- ref_ogr %>%
      distinct(code_ogr, .keep_all = TRUE)
    
    ref_codes <- vec_chr(ref_df$code_ogr)
    parent_code <- scalar_chr(parent_code)
    
    if (!is_filled(parent_code) || !(parent_code %in% ref_codes)) {
      parent_code <- ""
    }
    
    child_codes <- unique(vec_chr(child_codes))
    child_codes <- child_codes[child_codes %in% ref_codes]
    child_codes <- setdiff(child_codes, parent_code)
    
    parent_row <- ref_df[match(parent_code, ref_df$code_ogr), , drop = FALSE]
    if (!is_filled(parent_code) || nrow(parent_row) == 0 || is.na(parent_row$code_ogr[1])) {
      parent_row <- ref_df[0, , drop = FALSE]
    }
    
    child_idx <- match(child_codes, ref_df$code_ogr)
    child_idx <- child_idx[!is.na(child_idx)]
    child_rows <- ref_df[child_idx, , drop = FALSE]
    
    list(
      code_ogr_parent = parent_code,
      code_rome_parent = if (nrow(parent_row) == 0) "" else first_non_empty(parent_row$code_rome[1], ""),
      libelle_parent = if (nrow(parent_row) == 0) "" else first_non_empty(parent_row$libelle_appellation_metier[1], ""),
      child_codes = vec_chr(child_rows$code_ogr),
      child_labels = vec_chr(child_rows$libelle_appellation_metier)
    )
  }
  
  build_validation_draft_from_proposal <- function(proposal, clear = FALSE) {
    if (is.null(proposal) || isTRUE(clear)) {
      return(normalize_validation_draft("", character(0)))
    }
    
    normalize_validation_draft(
      parent_code = first_non_empty(proposal$code_ogr_parent[1], proposal$code_ogr_parent_supervision[1], proposal$code_ogr_parent_edition[1]),
      child_codes = split_pipe_values(first_non_empty(proposal$codes_ogr_enfants[1], proposal$codes_ogr_enfants_supervision[1], proposal$codes_ogr_enfants_edition[1]))
    )
  }
  
  validation_draft_state <- reactiveVal(NULL)
  validation_draft_key <- reactiveVal("")
  
  observe({
    proposal <- selected_validation()
    key <- if (is.null(proposal)) {
      ""
    } else {
      paste0(first_non_empty(proposal$id_proposition[1], ""), "::", first_non_empty(proposal$statut_proposition[1], ""))
    }
    
    if (!identical(key, validation_draft_key())) {
      validation_draft_key(key)
      validation_draft_state(build_validation_draft_from_proposal(proposal))
    }
  })
  
  validation_draft <- reactive({
    state <- validation_draft_state()
    
    if (!is.null(state)) {
      return(state)
    }
    
    build_validation_draft_from_proposal(selected_validation())
  })
  
  selected_validation_reference_codes <- reactive({
    idx <- input$table_validation_reference_source_rows_selected
    ref_df <- ref_ogr %>%
      distinct(code_ogr, .keep_all = TRUE)
    
    if (is.null(idx) || length(idx) == 0 || nrow(ref_df) == 0) {
      return(character(0))
    }
    
    idx <- idx[!is.na(idx) & idx >= 1 & idx <= nrow(ref_df)]
    if (length(idx) == 0) {
      return(character(0))
    }
    
    unique(vec_chr(ref_df$code_ogr[idx]))
  })
  
  set_validation_draft <- function(parent_code, child_codes) {
    validation_draft_state(normalize_validation_draft(parent_code, child_codes))
  }
  
  reset_validation_draft_from_current <- function() {
    validation_draft_state(build_validation_draft_from_proposal(selected_validation()))
  }
  
  apply_validation_draft_to_proposal <- function(proposal, draft) {
    new_row <- proposal
    
    new_row$code_ogr_parent_validation[1] <- draft$code_ogr_parent
    new_row$code_rome_parent_validation[1] <- draft$code_rome_parent
    new_row$libelle_parent_validation[1] <- draft$libelle_parent
    new_row$codes_ogr_enfants_validation[1] <- paste(draft$child_codes, collapse = " | ")
    new_row$libelles_enfants_validation[1] <- paste(draft$child_labels, collapse = " | ")
    new_row$nb_enfants_validation[1] <- length(draft$child_codes)
    
    new_row$code_ogr_parent[1] <- draft$code_ogr_parent
    new_row$code_rome_parent[1] <- draft$code_rome_parent
    new_row$libelle_parent[1] <- draft$libelle_parent
    new_row$codes_ogr_enfants[1] <- paste(draft$child_codes, collapse = " | ")
    new_row$libelles_enfants[1] <- paste(draft$child_labels, collapse = " | ")
    new_row$nb_enfants[1] <- length(draft$child_codes)
    
    new_row
  }
  
  observeEvent(input$validation_add_reference_children, {
    state <- validation_draft()
    codes <- selected_validation_reference_codes()
    
    if (length(codes) == 0) {
      showNotification("Selectionne une ou plusieurs lignes dans le referentiel source avant d'ajouter des enfants.", type = "warning")
      return()
    }
    
    codes <- setdiff(codes, state$code_ogr_parent)
    if (length(codes) == 0) {
      showNotification("La selection ne contient aucun enfant ajoutable : le parent courant est automatiquement exclu.", type = "warning")
      return()
    }
    
    set_validation_draft(
      parent_code = state$code_ogr_parent,
      child_codes = unique(c(state$child_codes, codes))
    )
  }, ignoreInit = TRUE)
  
  observeEvent(input$validation_set_reference_parent, {
    state <- validation_draft()
    codes <- selected_validation_reference_codes()
    
    if (length(codes) != 1) {
      showNotification("Selectionne exactement une ligne du referentiel source pour definir le parent.", type = "warning")
      return()
    }
    
    set_validation_draft(
      parent_code = codes[1],
      child_codes = setdiff(state$child_codes, codes[1])
    )
  }, ignoreInit = TRUE)
  
  observeEvent(input$validation_remove_selected_children, {
    state <- validation_draft()
    idx <- input$table_validation_children_work_rows_selected
    
    if (is.null(state) || length(state$child_codes) == 0) {
      showNotification("Aucun enfant a retirer dans la version MOA.", type = "warning")
      return()
    }
    
    if (is.null(idx) || length(idx) == 0) {
      showNotification("Selectionne un ou plusieurs enfants dans la table avant de les retirer.", type = "warning")
      return()
    }
    
    idx <- idx[!is.na(idx) & idx >= 1 & idx <= length(state$child_codes)]
    if (length(idx) == 0) {
      showNotification("Selection d'enfants invalide.", type = "warning")
      return()
    }
    
    set_validation_draft(
      parent_code = state$code_ogr_parent,
      child_codes = state$child_codes[-idx]
    )
  }, ignoreInit = TRUE)
  
  observeEvent(input$validation_reset_from_current, {
    reset_validation_draft_from_current()
    showNotification("Version MOA reinitialisee depuis la version courante transmise par la supervision.", type = "message", duration = 4)
  }, ignoreInit = TRUE)
  
  observeEvent(input$validation_clear_recomposition, {
    showModal(modalDialog(
      title = "Recomposition complete",
      tags$p("Cette action vide la version MOA courante : parent et enfants seront remis a zero."),
      tags$p(tags$strong("La version transmise par la supervision reste conservee en lecture seule dans le detail du dossier.")),
      easyClose = TRUE,
      footer = tagList(
        modalButton("Annuler"),
        actionButton("confirm_validation_clear_recomposition", "Vider la version MOA", class = "btn-danger")
      )
    ))
  }, ignoreInit = TRUE)
  
  observeEvent(input$confirm_validation_clear_recomposition, {
    removeModal()
    set_validation_draft("", character(0))
    showNotification("Version MOA videe. Reconstruis-la depuis le referentiel source.", type = "message", duration = 5)
  }, ignoreInit = TRUE)
  
  output$validation_current_parent_ui <- renderUI({
    state <- validation_draft()
    
    if (is.null(state) || !is_filled(state$code_ogr_parent)) {
      return(tags$div(
        class = "validation-current-parent is-empty",
        tags$strong("Parent MOA : "),
        "aucun parent defini"
      ))
    }
    
    tags$div(
      class = "validation-current-parent",
      tags$strong("Parent MOA : "),
      paste0(first_non_empty(state$libelle_parent, "Libelle non disponible"), " [", state$code_ogr_parent, "]")
    )
  })
  
  output$table_validation_children_work <- DT::renderDT({
    state <- validation_draft()
    
    if (is.null(state) || length(state$child_codes) == 0) {
      empty <- data.frame(
        `Code OGR` = character(0),
        `Libelle enfant` = character(0),
        check.names = FALSE
      )
      return(DT::datatable(
        empty,
        rownames = FALSE,
        selection = "multiple",
        class = "compact stripe hover",
        options = ogre_dt_options(
          page_length = 10,
          length_menu = list(c(10, 25, 50, 100, -1), c("10", "25", "50", "100", "Tous")),
          scroll_y = "36vh",
          dom = "lfrtip"
        )
      ))
    }
    
    children_df <- data.frame(
      `Code OGR` = state$child_codes,
      `Libelle enfant` = state$child_labels,
      check.names = FALSE,
      stringsAsFactors = FALSE
    )
    
    DT::datatable(
      children_df,
      rownames = FALSE,
      selection = "multiple",
      class = "compact stripe hover",
      options = ogre_dt_options(
        page_length = min(10L, nrow(children_df)),
        length_menu = list(c(10, 25, 50, 100, -1), c("10", "25", "50", "100", "Tous")),
        scroll_y = "36vh",
        dom = "lfrtip"
      )
    )
  })
  
  output$validation_edit_preview <- renderUI({
    draft <- validation_draft()
    
    if (is.null(draft) || !is_filled(draft$code_ogr_parent)) {
      return(tags$p(class = "validation-note", "Selectionne une proposition pour precharger la version MOA."))
    }
    
    tags$div(
      class = "validation-edit-preview",
      tags$div(
        class = "validation-edit-preview-row",
        tags$span("Parent :"),
        tags$strong(paste0(first_non_empty(draft$libelle_parent, "Libelle non disponible"), " [", draft$code_ogr_parent, "]"))
      ),
      tags$div(
        class = "validation-edit-preview-row",
        tags$span("Enfants :"),
        tags$strong(paste(length(draft$child_codes), "enfant(s)"))
      )
    )
  })
  
  output$validation_modification_workspace <- renderUI({
    proposal <- selected_validation()
    active_tab <- input$validation_status_tab
    
    if (is.null(proposal) || !identical(active_tab, "En cours") || !identical(proposal$statut_proposition[1], "en_cours")) {
      return(NULL)
    }
    
    mode <- scalar_chr(input$validation_modification_mode, default = "quick")
    if (!(mode %in% c("quick", "complete"))) {
      mode <- "quick"
    }
    
    mode_help <- if (identical(mode, "quick")) {
      tags$div(
        class = "validation-mode-help is-quick",
        tags$strong("Ajustement rapide : "),
        "pars de la version transmise par la supervision, retire les enfants en trop, ajoute les oublis ou change le parent sans reconstruire toute la famille."
      )
    } else {
      tags$div(
        class = "validation-mode-help is-complete",
        tags$strong("Recomposition complete : "),
        "vide volontairement la version MOA, puis reconstruis le parent et tous les enfants depuis le referentiel source."
      )
    }
    
    complete_mode_actions <- if (identical(mode, "complete")) {
      tags$div(
        class = "validation-recomposition-actions",
        actionButton(
          "validation_clear_recomposition",
          "Vider la version MOA",
          class = "btn-danger"
        )
      )
    } else {
      NULL
    }
    
    tags$div(
      class = "validation-card validation-modification-card",
      section_title_with_info(
        "Modification de publication",
        "Deux voies sont disponibles : ajuster rapidement la version transmise par la supervision, ou repartir d'une recomposition complete. Les boutons de decision restent dans le panneau de gauche : publier en l'etat, mettre en attente ou rejeter."
      ),
      tags$div(
        class = "validation-modification-warning",
        "La version courante reste consultable dans le detail au-dessus. Le bloc ci-dessous prepare uniquement une version MOA modifiee a publier dans le stock."
      ),
      tags$div(
        class = "validation-modification-layout",
        tags$div(
          class = "validation-modification-side",
          section_title_with_info(
            "Voie de modification",
            "Choisis Ajustement rapide pour corriger quelques elements, ou Recomposition complete pour reconstruire la famille depuis zero."
          ),
          radioButtons(
            inputId = "validation_modification_mode",
            label = NULL,
            choices = c(
              "Ajustement rapide" = "quick",
              "Recomposition complete" = "complete"
            ),
            selected = mode,
            inline = TRUE
          ),
          mode_help,
          tags$hr(),
          section_title_with_info(
            "Version MOA courante",
            "Cette version est celle qui sera publiee si tu utilises le bouton Publier la version modifiee dans le stock."
          ),
          uiOutput("validation_current_parent_ui"),
          tags$div(
            class = "validation-children-work-header",
            tags$strong("Enfants MOA"),
            tags$span(" - selectionne une ou plusieurs lignes pour les retirer a la volee.")
          ),
          div(class = "validation-dt validation-children-work-dt", DTOutput("table_validation_children_work")),
          tags$div(
            class = "validation-modification-actions",
            actionButton(
              "validation_remove_selected_children",
              "Retirer les enfants selectionnes",
              class = "btn-warning"
            ),
            actionButton(
              "validation_reset_from_current",
              "Reinitialiser depuis la version courante",
              class = "btn-default"
            )
          ),
          complete_mode_actions,
          uiOutput("validation_edit_preview"),
          tags$div(
            class = "validation-modification-actions validation-modification-submit",
            actionButton(
              "publish_validation_with_changes",
              "Publier la version modifiee dans le stock",
              class = "btn-primary"
            )
          )
        ),
        tags$div(
          class = "validation-modification-reference",
          section_title_with_info(
            "Referentiel source",
            "Filtre et selectionne les lignes utiles, puis utilise les boutons pour definir le parent ou ajouter des enfants a la version MOA."
          ),
          tags$div(
            class = "validation-reference-actions",
            actionButton(
              "validation_set_reference_parent",
              "Definir comme parent",
              class = "btn-info"
            ),
            actionButton(
              "validation_add_reference_children",
              "Ajouter comme enfant(s)",
              class = "btn-success"
            )
          ),
          tags$div(
            class = "validation-note",
            "La selection dans ce tableau n'ecrase rien automatiquement : elle alimente seulement les actions ci-dessus."
          ),
          div(class = "validation-dt", DTOutput("table_validation_reference_source"))
        )
      )
    )
  })
  
  output$validation_publish_workspace <- renderUI({
    proposal <- selected_validation()
    active_tab <- input$validation_status_tab
    
    if (is.null(proposal) || !(active_tab %in% c("En cours", "En attente", "Validees"))) {
      return(NULL)
    }
    
    tags$div(
      class = "validation-card",
      section_title_with_info(
        "Impact de publication",
        "Ce bloc aide a comprendre ce qui sera cree ou remplace dans le stock et dans le referentiel EDEP."
      ),
      uiOutput("validation_publish_preview")
    )
  })
  
  output$validation_kpi_panel <- renderUI({
    refresh_token()
    
    queue_n <- nrow(validation_queue())
    in_progress_n <- nrow(validation_in_progress())
    waiting_n <- nrow(validation_waiting())
    rejected_n <- nrow(validation_rejected())
    validated_n <- nrow(validation_validated())
    stock_n <- nrow(stock_families())
    
    oldest_pending_days <- if (queue_n == 0) {
      "0.0"
    } else {
      pending_times <- suppressWarnings(as.POSIXct(validation_queue()$horodatage_decision_supervision, format = "%Y-%m-%d %H:%M:%S", tz = ogre_workflow_tz()))
      pending_times <- pending_times[!is.na(pending_times)]
      if (length(pending_times) == 0) {
        "0.0"
      } else {
        sprintf("%.1f", as.numeric(difftime(Sys.time(), min(pending_times), units = "days")))
      }
    }
    
    card <- function(label, value, help) {
      tags$div(
        class = "validation-kpi",
        tags$div(class = "validation-kpi-label", label),
        tags$div(class = "validation-kpi-value", value),
        tags$div(class = "validation-kpi-help", help)
      )
    }
    
    tags$div(
      class = "validation-kpis",
      card("A valider", queue_n, paste("Backlog MOA, anciennete max", oldest_pending_days, "jour(s)")),
      card("En cours", in_progress_n, "Dossiers ouverts par la MOA"),
      card("En attente", waiting_n, "Dossiers temporises"),
      card("Rejetes", rejected_n, "Dossiers refuses cote MOA"),
      card("Publies", validated_n, "Propositions validees"),
      card("Stock familles", stock_n, "Familles publiees disponibles")
    )
  })
  
  make_validation_table <- function(df, mode = c("queue", "progress", "waiting", "rejected", "validated")) {
    mode <- match.arg(mode)
    
    displayed <- df %>%
      transmute(
        `ID proposition` = id_proposition,
        Operation = type_operation,
        `IDEP edition` = idep_agent_edition,
        `IDEP supervision` = idep_agent_supervision,
        `IDEP validation` = idep_agent_validation,
        `Code parent` = code_ogr_parent,
        Parent = libelle_parent,
        `Nb enfants` = nb_enfants,
        `Decision supervision` = decision_supervision,
        `Decision validation` = decision_validation,
        `Horodatage edition` = horodatage_edition,
        `Horodatage supervision` = horodatage_decision_supervision,
        `Horodatage validation` = horodatage_decision_validation
      )
    
    hidden_targets <- switch(
      mode,
      queue = c(4, 9, 12),
      progress = c(9, 12),
      waiting = c(9, 12),
      rejected = integer(0),
      validated = integer(0)
    )
    column_defs <- if (length(hidden_targets) == 0) {
      list()
    } else {
      list(list(visible = FALSE, targets = hidden_targets))
    }
    
    datatable(
      displayed,
      extensions = "Buttons",
      selection = "single",
      rownames = FALSE,
      options = ogre_dt_options(
        page_length = 8,
        scroll_y = "50vh",
        dom = "Bfrtip",
        buttons = TRUE,
        column_defs = column_defs
      )
    ) %>%
      formatStyle(
        "Operation",
        backgroundColor = styleEqual(c("creation", "modification"), c("#eef7ff", "#fff1d6")),
        color = styleEqual(c("creation", "modification"), c("#1f5f8b", "#a75f00")),
        fontWeight = styleEqual(c("creation", "modification"), c("700", "700"))
      ) %>%
      formatStyle(
        "Decision supervision",
        backgroundColor = styleEqual(c("valide_en_etat", "modifie_et_valide", "rejete"), c("#e9f7ef", "#eef7ff", "#fff1d6")),
        color = styleEqual(c("valide_en_etat", "modifie_et_valide", "rejete"), c("#1e8449", "#1f5f8b", "#b45f06")),
        fontWeight = styleEqual(c("valide_en_etat", "modifie_et_valide", "rejete"), c("700", "700", "700"))
      ) %>%
      formatStyle(
        "Decision validation",
        backgroundColor = styleEqual(c("validee", "rejetee"), c("#e9f7ef", "#ffe9ef")),
        color = styleEqual(c("validee", "rejetee"), c("#1e8449", "#a23b5a")),
        fontWeight = styleEqual(c("validee", "rejetee"), c("700", "700"))
      )
  }
  
  output$table_validation_queue <- renderDT({
    make_validation_table(validation_queue(), mode = "queue")
  })
  
  output$table_validation_in_progress <- renderDT({
    make_validation_table(validation_in_progress(), mode = "progress")
  })
  
  output$table_validation_waiting <- renderDT({
    make_validation_table(validation_waiting(), mode = "waiting")
  })
  
  output$table_validation_rejected <- renderDT({
    make_validation_table(validation_rejected(), mode = "rejected")
  })
  
  output$table_validation_validated <- renderDT({
    make_validation_table(validation_validated(), mode = "validated")
  })
  
  output$table_validation_stock <- renderDT({
    datatable(
      stock_families() %>%
        select(
          id_famille,
          id_proposition_source,
          date_validation,
          idep_agent_validation,
          code_ogr_parent,
          code_rome_parent,
          libelle_parent,
          nb_enfants,
          codes_ogr_enfants
        ),
      extensions = "Buttons",
      selection = "none",
      rownames = FALSE,
      filter = "top",
      options = ogre_dt_options(
        page_length = 10,
        scroll_y = "50vh",
        dom = "Bfrtip",
        buttons = TRUE
      )
    )
  })
  
  output$table_validation_reference_source <- renderDT({
    build_reference_source_datatable(
      ref_df = ref_ogr,
      selection = "multiple",
      page_length = 25L,
      length_menu = c(10, 25, 50, 100),
      scroll_y = "58vh",
      dom = "Blfrtip"
    )
  })
  
  output$table_validation_edep <- renderDT({
    datatable(
      edep_reference() %>%
        select(
          code_ogr,
          libelle_appellation_metier,
          code_rome,
          classification,
          role_edep,
          a_famille_edep,
          est_enfant_edep,
          nb_enfants_edep,
          codes_enfants_edep,
          codes_parents_amont_edep,
          libelle_grand_domaine,
          libelle_domaine_professionnel
        ),
      extensions = "Buttons",
      selection = "none",
      rownames = FALSE,
      filter = "top",
      options = ogre_dt_options(
        page_length = 10,
        scroll_y = "50vh",
        dom = "Bfrtip",
        buttons = TRUE
      )
    )
  })
  
  output$table_validation_edep_links <- renderDT({
    datatable(
      edep_links() %>%
        select(
          id_famille,
          id_proposition_source,
          date_validation,
          idep_agent_validation,
          code_ogr_parent,
          libelle_parent,
          code_ogr_enfant,
          libelle_enfant,
          rang_enfant,
          nb_enfants_famille
        ),
      extensions = "Buttons",
      selection = "none",
      rownames = FALSE,
      filter = "top",
      options = ogre_dt_options(
        page_length = 10,
        scroll_y = "50vh",
        dom = "Bfrtip",
        buttons = TRUE
      )
    )
  })
  
  output$validation_action_context <- renderUI({
    proposal <- selected_validation()
    
    if (is.null(proposal)) {
      return(tags$div(
        class = "validation-status-banner",
        tags$div(class = "validation-status-kicker", "Selection"),
        tags$div(class = "validation-status-title", "Choisis une proposition dans une file MOA"),
        tags$div(class = "validation-status-copy", "La MOA pilote maintenant la fin du cycle : prise en charge, attente, rejet ou publication dans le stock.")
      ))
    }
    
    status <- proposal$statut_proposition[1]
    owner <- first_non_empty(proposal$idep_agent_validation[1], "Aucun validateur")
    
    if (identical(status, "a_valider")) {
      return(tags$div(
        class = "validation-status-banner is-queue",
        tags$div(class = "validation-status-kicker", "Etape MOA 1"),
        tags$div(class = "validation-status-title", "Dossier en attente de prise en charge"),
        tags$div(class = "validation-status-copy", "La proposition arrive de supervision. Prochaine action : l'ouvrir pour instruire la decision MOA.")
      ))
    }
    
    if (identical(status, "en_cours")) {
      return(tags$div(
        class = "validation-status-banner is-progress",
        tags$div(class = "validation-status-kicker", "Etape MOA 2"),
        tags$div(class = "validation-status-title", paste("Instruction en cours par", owner)),
        tags$div(class = "validation-status-copy", "Tu peux publier dans le stock en l'etat, ajuster la version MOA dans le bloc de modification sous le detail, mettre en attente ou rejeter.")
      ))
    }
    
    if (identical(status, "en_attente")) {
      return(tags$div(
        class = "validation-status-banner is-waiting",
        tags$div(class = "validation-status-kicker", "Etape MOA 3"),
        tags$div(class = "validation-status-title", "Dossier en attente"),
        tags$div(class = "validation-status-copy", "Le dossier est suspendu. Tu peux le reprendre, le publier ou le rejeter.")
      ))
    }
    
    if (identical(status, "rejetes")) {
      return(tags$div(
        class = "validation-status-banner is-rejected",
        tags$div(class = "validation-status-kicker", "Etape MOA 4"),
        tags$div(class = "validation-status-title", "Dossier rejete par la MOA"),
        tags$div(class = "validation-status-copy", "Le rejet reste visible pour audit, relecture et recreation d'une reprise d'edition depuis le dossier rejete."))
      )
    }
    
    tags$div(
      class = "validation-status-banner is-published",
      tags$div(class = "validation-status-kicker", "Etape MOA 5"),
      tags$div(class = "validation-status-title", "Dossier publie"),
      tags$div(class = "validation-status-copy", "La famille est desormais dans le stock et dans le referentiel EDEP.")
    )
  })
  
  output$validation_action_panel <- renderUI({
    proposal <- selected_validation()
    
    if (is.null(proposal)) {
      return(tags$p(class = "validation-note", "Selectionne une ligne pour afficher l'action utile."))
    }
    
    status <- proposal$statut_proposition[1]
    
    if (identical(status, "a_valider")) {
      return(tags$div(
        class = "validation-actions",
        actionButton("take_in_charge_validation", "Prendre en charge", class = "btn-default")
      ))
    }
    
    if (identical(status, "en_cours")) {
      return(tags$div(
        class = "validation-actions",
        actionButton("set_validation_waiting", "Mettre en attente", class = "btn-warning"),
        actionButton("publish_validation", "Publier dans le stock", class = "btn-success"),
        actionButton("reject_validation", "Rejeter", class = "btn-danger")
      ))
    }
    
    if (identical(status, "en_attente")) {
      return(tags$div(
        class = "validation-actions",
        actionButton("resume_validation", "Reprendre la validation", class = "btn-default"),
        actionButton("publish_validation", "Publier dans le stock", class = "btn-success"),
        actionButton("reject_validation", "Rejeter", class = "btn-danger")
      ))
    }
    
    if (identical(status, "rejetes")) {
      return(tags$div(
        class = "validation-actions",
        actionButton("reintegrate_validation", "Creer une reprise d'edition", class = "btn-info")
      ))
    }
    
    tags$p(class = "validation-note", "Aucune action supplementaire n'est ouverte sur cet etat.")
  })
  
  output$validation_modification_compare <- DT::renderDT({
    compare <- validation_modification_compare()
    
    if (is.null(compare) || !isTRUE(compare$available)) {
      return(NULL)
    }
    
    make_modification_compare_datatable(compare$child_compare)
  })
  
  output$validation_detail_modification_compare <- DT::renderDT({
    compare <- validation_modification_compare()
    
    if (is.null(compare) || !isTRUE(compare$available)) {
      return(NULL)
    }
    
    make_modification_compare_datatable(compare$child_compare)
  })
  
  output$validation_publish_preview <- renderUI({
    proposal <- selected_validation()
    
    if (is.null(proposal)) {
      return(tags$p(class = "validation-impact", "Selectionne une proposition pour voir l'impact de publication sur le stock et le referentiel EDEP."))
    }
    
    compare <- validation_modification_compare()
    
    impact_text <- if (proposal$type_operation[1] == "modification" && nzchar(proposal$base_famille_id[1])) {
      paste("La publication remplacera la famille stock", proposal$base_famille_id[1], "par une nouvelle version alimentee depuis la validation.")
    } else {
      "La publication creera une nouvelle famille dans le stock."
    }
    
    tags$div(
      class = "validation-impact",
      tags$p(tags$strong("Operation : "), proposal$type_operation[1]),
      tags$p(tags$strong("Famille stock cible : "), first_non_empty(proposal$base_famille_id[1], "Aucune")),
      tags$p(tags$strong("Impact stock : "), impact_text),
      tags$p(tags$strong("Impact referentiel EDEP : "), paste("parent", proposal$code_ogr_parent[1], "avec", proposal$nb_enfants[1], "liens enfant a publier")),
      if (nzchar(proposal$id_famille_stock_publiee[1])) {
        tags$p(tags$strong("Famille publiee : "), proposal$id_famille_stock_publiee[1])
      },
      if (!is.null(compare) && isTRUE(compare$is_modification)) {
        tagList(
          tags$hr(),
          tags$h4("Comparatif avant / apres"),
          if (!isTRUE(compare$available)) {
            tags$p(class = "validation-note", compare$reason)
          } else {
            tagList(
              tags$p(tags$strong("Parent avant : "), compare$parent_before),
              tags$p(tags$strong("Parent apres : "), compare$parent_after),
              tags$p(
                tags$strong("Enfants avant / apres : "),
                paste(compare$before_child_count, "->", compare$after_child_count)
              ),
              if (nrow(compare$child_compare) == 0) {
                tags$p(class = "validation-note", "Aucun enfant a comparer entre l'avant et l'apres.")
              } else {
                DT::DTOutput("validation_modification_compare")
              }
            )
          }
        )
      }
    )
  })
  
  output$validation_detail <- renderUI({
    proposal <- selected_validation()
    
    if (is.null(proposal)) {
      return(tags$p("Selectionne une proposition dans une file validation."))
    }
    
    compare <- validation_modification_compare()
    
    child_df <- child_df_from_vectors(
      split_pipe_values(proposal$codes_ogr_enfants[1]),
      split_pipe_values(proposal$libelles_enfants[1])
    )
    
    box <- function(label, value) {
      tags$div(
        class = "validation-detail-box",
        tags$div(class = "validation-detail-label", label),
        tags$div(class = "validation-detail-value", ifelse(!is.na(value) & nzchar(value), value, ""))
      )
    }
    
    tagList(
      tags$div(
        class = "validation-detail-grid",
        box("ID proposition", proposal$id_proposition[1]),
        box("Lignee", proposal$id_lignee[1]),
        box("Phase courante", paste(proposal$phase_proposition[1], proposal$statut_proposition[1])),
        box("Operation", proposal$type_operation[1]),
        box("Edition", paste(proposal$idep_agent_edition[1], proposal$horodatage_edition[1])),
        box("Supervision", paste(first_non_empty(proposal$idep_agent_supervision[1], "NA"), first_non_empty(proposal$horodatage_decision_supervision[1], ""))),
        box("Validation", paste(first_non_empty(proposal$idep_agent_validation[1], "NA"), first_non_empty(proposal$horodatage_decision_validation[1], ""))),
        box("Decision supervision", first_non_empty(proposal$decision_supervision[1], "Aucune")),
        box("Decision validation", first_non_empty(proposal$decision_validation[1], "Aucune")),
        box("Commentaire validation", first_non_empty(proposal$commentaire_validation[1], "Aucun")),
        box("Parent courant", paste0(proposal$libelle_parent[1], " [", proposal$code_ogr_parent[1], "]")),
        box("Famille stock publiee", first_non_empty(proposal$id_famille_stock_publiee[1], "Pas encore publiee"))
      ),
      tags$hr(),
      tags$h4("Contenu courant"),
      if (nrow(child_df) == 0) {
        tags$p("Aucun enfant.")
      } else {
        tags$table(
          class = "table table-striped table-bordered",
          tags$thead(tags$tr(tags$th("Code OGR"), tags$th("Libelle"))),
          tags$tbody(lapply(seq_len(nrow(child_df)), function(i) {
            tags$tr(tags$td(child_df$code_ogr[i]), tags$td(child_df$libelle[i]))
          }))
        )
      },
      if (!is.null(compare) && isTRUE(compare$is_modification)) {
        tagList(
          tags$hr(),
          tags$h4("Comparatif avant / apres"),
          if (!isTRUE(compare$available)) {
            tags$p(class = "validation-note", compare$reason)
          } else {
            tagList(
              tags$div(
                class = "validation-detail-grid",
                box("Parent avant", compare$parent_before),
                box("Parent apres", compare$parent_after),
                box("Enfants avant", as.character(compare$before_child_count)),
                box("Enfants apres", as.character(compare$after_child_count))
              ),
              if (nrow(compare$child_compare) == 0) {
                tags$p(class = "validation-note", "Aucun enfant a comparer entre l'avant et l'apres.")
              } else {
                DT::DTOutput("validation_detail_modification_compare")
              }
            )
          }
        )
      }
    )
  })
  
  observeEvent(input$take_in_charge_validation, {
    proposal <- selected_validation()
    
    if (is.null(proposal) || !identical(proposal$statut_proposition[1], "a_valider")) {
      showNotification("Selectionne une proposition a valider pour la prendre en charge.", type = "warning")
      return()
    }
    
    if (!is_filled(validation_agent_value())) {
      showNotification("IDEP validation non détecté. Impossible de tracer la prise en charge.", type = "warning")
      return()
    }
    
    ok <- run_validation_transition(
      action_fun = function() take_in_charge_validation(proposal, validation_agent_value()),
      failure_prefix = "Prise en charge validation impossible :"
    )
    if (!isTRUE(ok)) {
      return()
    }
    
    updateTabsetPanel(session, "validation_status_tab", selected = "En cours")
    showNotification("Proposition prise en charge par la MOA.", type = "message", duration = 5)
  })
  
  observeEvent(input$set_validation_waiting, {
    proposal <- selected_validation()
    
    if (is.null(proposal) || !identical(proposal$statut_proposition[1], "en_cours")) {
      showNotification("Ouvre d'abord un dossier en validation pour le mettre en attente.", type = "warning")
      return()
    }
    
    if (!is_filled(validation_agent_value())) {
      showNotification("IDEP validation non détecté. Impossible de tracer la mise en attente.", type = "warning")
      return()
    }
    
    ok <- run_validation_transition(
      action_fun = function() set_validation_waiting(proposal, validation_agent_value(), input$validation_comment),
      failure_prefix = "Mise en attente impossible :"
    )
    if (!isTRUE(ok)) {
      return()
    }
    
    updateTabsetPanel(session, "validation_status_tab", selected = "En attente")
    showNotification("Dossier place en attente cote MOA.", type = "message", duration = 5)
  })
  
  observeEvent(input$resume_validation, {
    proposal <- selected_validation()
    
    if (is.null(proposal) || !identical(proposal$statut_proposition[1], "en_attente")) {
      showNotification("Selectionne un dossier en attente pour le reprendre.", type = "warning")
      return()
    }
    
    if (!is_filled(validation_agent_value())) {
      showNotification("IDEP validation non détecté. Impossible de tracer la reprise.", type = "warning")
      return()
    }
    
    ok <- run_validation_transition(
      action_fun = function() resume_validation_work(proposal, validation_agent_value(), input$validation_comment),
      failure_prefix = "Reprise validation impossible :"
    )
    if (!isTRUE(ok)) {
      return()
    }
    
    updateTabsetPanel(session, "validation_status_tab", selected = "En cours")
    showNotification("Dossier repris en validation MOA.", type = "message", duration = 5)
  })
  
  observeEvent(input$reject_validation, {
    proposal <- selected_validation()
    
    if (is.null(proposal) || !(proposal$statut_proposition[1] %in% c("en_cours", "en_attente"))) {
      showNotification("Le rejet MOA s'applique a un dossier en cours ou en attente.", type = "warning")
      return()
    }
    
    if (!is_filled(validation_agent_value())) {
      showNotification("IDEP validation non détecté. Impossible de tracer le rejet.", type = "warning")
      return()
    }
    
    ok <- run_validation_transition(
      action_fun = function() save_validation_decision(proposal, validation_agent_value(), input$validation_comment, decision = "rejetee"),
      failure_prefix = "Rejet validation impossible :"
    )
    if (!isTRUE(ok)) {
      return()
    }
    
    updateTabsetPanel(session, "validation_status_tab", selected = "Rejetes")
    showNotification("Proposition rejetee par la MOA.", type = "message", duration = 6)
  })
  
  observeEvent(input$publish_validation_with_changes, {
    proposal <- selected_validation()
    draft <- validation_draft()
    
    if (is.null(proposal) || !identical(proposal$statut_proposition[1], "en_cours")) {
      showNotification("Prends d'abord en charge une proposition avant de publier une version modifiee.", type = "warning")
      return()
    }
    
    if (!is_filled(validation_agent_value())) {
      showNotification("IDEP validation non détecté. Impossible de tracer la publication.", type = "warning")
      return()
    }
    
    if (is.null(draft) || !is_filled(draft$code_ogr_parent) || length(draft$child_codes) == 0) {
      showNotification("Definis un parent et au moins un enfant pour la version MOA.", type = "warning")
      showModal(modalDialog(
        title = "Version MOA incomplete",
        tags$p("Definis un parent et au moins un enfant avant de publier la version modifiee dans le stock."),
        easyClose = TRUE,
        footer = modalButton("Fermer")
      ))
      return()
    }
    
    modified_proposal <- apply_validation_draft_to_proposal(proposal, draft)
    
    workflow_checks <- build_family_conflict_checks(
      draft = proposal_row_to_draft(modified_proposal),
      stock_families = stock_families(),
      workflow_proposals = workflow_active_proposals(),
      current_proposal = proposal
    )
    
    if (has_blocking_family_conflicts(workflow_checks)) {
      show_family_conflict_modal(
        title = "Doublon ou chevauchement detecte",
        checks = workflow_checks,
        closing_copy = "Corrigez la version MOA avant publication dans le stock."
      )
      return()
    }
    
    ok <- run_validation_transition(
      action_fun = function() publish_validation_to_stock(modified_proposal, validation_agent_value(), input$validation_comment),
      failure_prefix = "Publication de la version modifiee impossible :"
    )
    if (!isTRUE(ok)) {
      return()
    }
    
    updateTabsetPanel(session, "validation_status_tab", selected = "Validees")
    showNotification("Version MOA modifiee publiee dans le stock et injectee dans le referentiel EDEP.", type = "message", duration = 7)
  })
  
  observeEvent(input$publish_validation, {
    proposal <- selected_validation()
    
    if (is.null(proposal) || !(proposal$statut_proposition[1] %in% c("en_cours", "en_attente"))) {
      showNotification("La publication MOA s'applique a un dossier en cours ou en attente.", type = "warning")
      return()
    }
    
    if (!is_filled(validation_agent_value())) {
      showNotification("IDEP validation non détecté. Impossible de tracer la publication.", type = "warning")
      return()
    }
    
    workflow_checks <- build_family_conflict_checks(
      draft = proposal_row_to_draft(proposal),
      stock_families = stock_families(),
      workflow_proposals = workflow_active_proposals(),
      current_proposal = proposal
    )
    
    if (has_blocking_family_conflicts(workflow_checks)) {
      show_family_conflict_modal(
        title = "Doublon ou chevauchement detecte",
        checks = workflow_checks,
        closing_copy = "Corrigez la proposition avant publication dans le stock."
      )
      return()
    }
    
    ok <- run_validation_transition(
      action_fun = function() publish_validation_to_stock(proposal, validation_agent_value(), input$validation_comment),
      failure_prefix = "Publication validation impossible :"
    )
    if (!isTRUE(ok)) {
      return()
    }
    
    updateTabsetPanel(session, "validation_status_tab", selected = "Validees")
    showNotification("Proposition publiee dans le stock et injectee dans le referentiel EDEP.", type = "message", duration = 7)
  })
  
  observeEvent(input$reintegrate_validation, {
    proposal <- selected_validation()
    
    if (is.null(proposal) || !identical(proposal$statut_proposition[1], "rejetes")) {
      showNotification("Selectionne un rejet validation pour creer une reprise.", type = "warning")
      return()
    }
    
    if (!is_filled(validation_reprise_idep_value())) {
      showNotification("IDEP reprise édition non détecté. Impossible de tracer la reprise.", type = "warning")
      return()
    }
    
    ok <- run_validation_transition(
      action_fun = function() {
        reintegrate_rejected_proposal(
          proposal_row = proposal,
          idep_agent_edition = validation_reprise_idep_value()
        )
      },
      failure_prefix = "Creation de la reprise impossible :"
    )
    if (!isTRUE(ok)) {
      return()
    }
    
    updateTabsetPanel(session, "validation_status_tab", selected = "Rejetes")
    showNotification("Une nouvelle reprise d'edition a ete creee a partir du rejet MOA.", type = "message", duration = 6)
  })
}
