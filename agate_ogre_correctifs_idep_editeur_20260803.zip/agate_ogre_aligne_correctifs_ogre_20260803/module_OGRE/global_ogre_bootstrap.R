source_ogre_workflow <- function(env = parent.frame()) {
  source(
    "modules/module_OGRE/edition/global_ogre_workflow.R",
    encoding = "UTF-8",
    local = env
  )
  invisible(TRUE)
}

source_ogre_stock_valides <- function(env = parent.frame()) {
  source(
    "modules/module_OGRE/stock_valides/ui_stock_valides.R",
    encoding = "UTF-8",
    local = env
  )
  source(
    "modules/module_OGRE/stock_valides/server_stock_valides.R",
    encoding = "UTF-8",
    local = env
  )
  invisible(TRUE)
}

source_ogre_modules <- function(env = parent.frame()) {
  source_ogre_workflow(env = env)
  
  source(
    "modules/module_OGRE/edition/ui_edition.R",
    encoding = "UTF-8",
    local = env
  )
  source(
    "modules/module_OGRE/edition/server_edition.R",
    encoding = "UTF-8",
    local = env
  )
  source(
    "modules/module_OGRE/supervision/ui_supervision.R",
    encoding = "UTF-8",
    local = env
  )
  source(
    "modules/module_OGRE/supervision/server_supervision.R",
    encoding = "UTF-8",
    local = env
  )
  source(
    "modules/module_OGRE/validation/ui_validation.R",
    encoding = "UTF-8",
    local = env
  )
  source(
    "modules/module_OGRE/validation/server_validation.R",
    encoding = "UTF-8",
    local = env
  )
  source_ogre_stock_valides(env = env)
  
  invisible(TRUE)
}
