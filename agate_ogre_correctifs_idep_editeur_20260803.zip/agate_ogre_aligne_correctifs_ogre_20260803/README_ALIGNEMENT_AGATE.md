# Alignement fonctionnel d’AGATE sur OGRE

Cette livraison conserve le contrat métier et le stockage existants d’AGATE, tout en intégrant les principales fonctions déjà présentes dans OGRE. La révision du 3 août 2026 ajoute deux correctifs ciblés côté OGRE, sans modifier son workflow ni ses formats de données.

## Révision OGRE du 3 août 2026

- l’IDEP de validation MOA et l’IDEP de reprise sont détectés automatiquement et affichés en lecture seule, comme en supervision ;
- chaque action de validation utilise la valeur détectée côté serveur et s’arrête explicitement si aucun IDEP n’est disponible ;
- l’éditeur OGRE devient un véritable atelier visuel : en-tête de parcours, progression en trois étapes, indicateurs dynamiques de sélection/composition, panneau de travail modernisé et action principale mieux hiérarchisée ;
- tous les identifiants Shiny, appels métier, chemins de stockage et schémas restent inchangés ;
- les quatre scripts OGRE antérieurs sont conservés dans `backup_OGRE_avant_correctifs_20260803`.

## Ce qui est ajouté à AGATE

- espace **Familles validées** : recherche, consultation du détail, filiation graphique, vue consolidée et remise en jeu ;
- remise en jeu d’une famille validée dans l’atelier d’édition, sans supprimer ni modifier le stock publié ;
- traçabilité du rejeu dans les propositions : origine, famille source, agent, date, fichier source et commentaire ;
- édition enrichie : sélection dans le référentiel, commentaire, contrôle du stock, préconisations facultatives, contrôle des conflits et protection contre la double création ;
- supervision enrichie : prise en charge, comparaison avant/après, recomposition depuis le référentiel APET, ajout/retrait d’enfants et visualisation de la filiation ;
- validation enrichie : recomposition MOA, publication en l’état ou avec modifications, mise en attente, reprise et rejet ;
- tableaux avancés avec filtres et choix des colonnes ;
- rafraîchissements différés après déplacement de fichiers afin d’absorber la latence de visibilité du stockage.

## Simplification UI/UX

- parcours numéroté dans l’édition, la supervision et la validation ;
- indicateurs de pilotage repliés par défaut ;
- préconisations et aides expertes placées dans des blocs facultatifs ;
- séparation visuelle entre les onglets de traitement et les onglets de consultation ;
- vocabulaire affiché adapté à AGATE : **APET**, **A88** et activités, tout en conservant les noms de colonnes techniques historiques pour ne pas casser les fichiers existants ;
- IDEP détecté automatiquement lorsque le contexte de session ou les variables d’environnement le permettent.

## Compatibilité préservée

- les points d’entrée existants restent disponibles : `agate_edition_ui/server`, `agate_supervision_ui/server` et `agate_validation_ui/server` ;
- les chemins S3 `astra_agate`, `supervision`, `validation`, `stock` et `referentiels` restent inchangés ;
- toutes les colonnes historiques des familles, propositions et référentiels sont conservées ;
- sept colonnes de traçabilité du rejeu sont ajoutées aux propositions ;
- la source APET existante et le repli vers `nomenclature_apet.parquet` sont conservés ;
- l’écriture Parquet conserve la compatibilité avec les deux interfaces S3 déjà gérées par AGATE.
- le chargement complet utilise un environnement privé et n’écrase pas les helpers génériques d’OGRE lorsque les deux modules cohabitent.

## Scripts AGATE concernés

- `module_AGATE/global_agate_bootstrap.R`
- `module_AGATE/edition/global_agate_workflow.R`
- `module_AGATE/edition/ui_edition.R`
- `module_AGATE/edition/server_edition.R`
- `module_AGATE/supervision/ui_supervision.R`
- `module_AGATE/supervision/server_supervision.R`
- `module_AGATE/validation/ui_validation.R`
- `module_AGATE/validation/server_validation.R`
- ajout de `module_AGATE/stock_valides/ui_stock_valides.R`
- ajout de `module_AGATE/stock_valides/server_stock_valides.R`

Les scripts d’origine sont conservés dans `backup_AGATE_avant_alignement_20260731`.

## Chargement

Le bootstrap complet charge désormais le workflow, l’édition, la supervision, la validation et le stock validé :

```r
source("modules/module_AGATE/global_agate_bootstrap.R", encoding = "UTF-8")
source_agate_modules()
```

Pour exposer le nouvel espace dans la navigation de l’application, utiliser `agate_stock_valides_ui()` et appeler `agate_stock_valides_server(input, output, session)` dans le serveur, selon la structure actuelle de l’application.

## Contrôle rapide

Depuis la racine extraite du ZIP :

```bash
Rscript tests/01_parse_and_contracts.R
```

Le contrôle vérifie la syntaxe de tous les scripts AGATE et les principaux contrats de compatibilité sans accéder au stockage.
